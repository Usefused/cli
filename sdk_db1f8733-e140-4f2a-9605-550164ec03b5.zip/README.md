# Generated SDK 1.0.0

Auto-generated SDK for Plunk and Stripe APIs. Provides a unified, type-safe interface for sending transactional emails and managing payments.

## Installation

```bash
npm install generated-sdk@1.0.0
```

## Quick Start

### Plunk – Send a transactional email

```typescript
import { PlunkClient } from 'generated-sdk';

const client = new PlunkClient();
client.setAuth({ token: 'your-plunk-api-token' });

const response = await client.send.sendTransactionalEmail({
  to: 'user@example.com',
  subject: 'Welcome!',
  body: '<h1>Hello</h1>'
});

if (!response.ok) {
  console.error('Error:', response.error);
} else {
  console.log('Success:', response.data);
}
```

### Stripe – List PaymentIntents

```typescript
import { StripeClient } from 'generated-sdk';

const client = new StripeClient();
client.setAuth({ token: 'sk_live_...' });

const response = await client.paymentIntents.getPaymentIntents({ limit: 10 });

if (!response.ok) {
  console.error('Error:', response.error);
} else {
  console.log('Payment Intents:', response.data.data);
}
```

## Authentication

Every client must be authenticated by calling `setAuth(credentials)`. The credentials object differs per integration.

### Plunk

Provide an API token:

```typescript
client.setAuth({ token: 'plunk_api_token' });
```

### Stripe

Stripe supports either basic authentication (username/password) or bearer token (usually a secret key):

```typescript
// Using Bearer token (recommended)
client.setAuth({ token: 'sk_live_...' });

// Using Basic auth (not common for Stripe)
client.setAuth({ username: '...', password: '...' });
```

> **Note:** Only one authentication method is used at a time. If both `token` and `username`/`password` are provided, `token` takes precedence.

## Configuration

Both client constructors accept an optional configuration object:

```typescript
interface SDKConfig {
  baseUrl?: string;      // Override the default API endpoint (useful for staging/test environments)
  headers?: Record<string, string>;  // Global headers added to every request
  timeoutMs?: number;    // Request timeout (default 30000)
  debug?: boolean;       // Log requests / responses (default false)
}
```

Example – override base URL:

```typescript
const client = new StripeClient({ baseUrl: 'https://api.stripe.com/v1' });
```

## Response Pattern

All SDK methods return a **discriminated union**:

```typescript
type ApiResponse<Success, Error> =
  | { ok: true; status: number; data: Success; error: null }
  | { ok: false; status: number; data: null; error: Error };
```

**Always check `if (!response.ok)`** rather than using try/catch. Successful responses have `ok: true` and `data` populated; failures have `ok: false` and `error` populated with a structured error object.

## API Reference

---

### PlunkClient

#### `send.sendTransactionalEmail(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/send`

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `to` | `string` | Yes | Recipient email address |
| `subject` | `string` | Yes | Email subject line |
| `body` | `string` | Yes | Email body (can be HTML) |
| `headers` | `Record<string, string>` | No | Additional email headers |

**Response `data` on success:**

```typescript
{
  data?: Record<string, any>;
  success?: boolean;
}
```

**Response `error` on failure:**

```typescript
{
  error: {
    code: string;
    message: string;
  };
  success: boolean;
}
```

---

### StripeClient

#### `paymentLinks.getPaymentLinks(options?)`

- **HTTP Method:** `GET`
- **Path:** `/v1/payment_links`

**Query Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `active` | `string` | No | Filter by active status |
| `ending_before` | `string` | No | Cursor for pagination |
| `expand` | `string` | No | Fields to expand |
| `limit` | `number` | No | Number of results to return |
| `starting_after` | `string` | No | Cursor for pagination |
| `headers` | `Record<string, string>` | No | Additional request headers |

**Response `data` on success:**

```typescript
{
  data: payment_link[];
  has_more: boolean;
  object: string;
  url: string;
}
```

**Response `error` on failure:**

```typescript
{
  error: {
    error: api_errors;
  };
}
```

---

#### `invoices.postInvoicesInvoicePay(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/invoices/{invoice}/pay`
- **Path Parameter:** `invoice` (required) – the invoice ID

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `invoice` | `string` | Yes | Invoice ID |
| `headers` | `Record<string, string>` | No | Additional request headers |

**Response `data` on success:**

```typescript
type invoice = { /* Stripe Invoice object */ };
```

**Response `error` on failure:**

```typescript
type error = { error: api_errors };
```

---

#### `invoices.postInvoicesInvoiceSend(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/invoices/{invoice}/send`
- **Path Parameter:** `invoice` (required)

**Parameters:** same as above.

**Response:** same pattern.

---

#### `treasury.postTreasuryOutboundPayments(options?)`

- **HTTP Method:** `POST`
- **Path:** `/v1/treasury/outbound_payments`

**Parameters:** Only `headers` (optional).

**Response `data` on success:**

```typescript
type treasury.outbound_payment = { /* Stripe OutboundPayment object */ };
```

---

#### `paymentIntents.postPaymentIntentsIntentConfirm(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/payment_intents/{intent}/confirm`
- **Path Parameter:** `intent` (required) – the PaymentIntent ID

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `intent` | `string` | Yes | PaymentIntent ID |
| `headers` | `Record<string, string>` | No | Additional request headers |

**Response `data`:** `payment_intent` object.

---

#### `paymentIntents.postPaymentIntents(options?)`

- **HTTP Method:** `POST`
- **Path:** `/v1/payment_intents`

Creates a new PaymentIntent. No request body is sent in this auto-generated version; in practice the real Stripe API requires parameters, but this SDK does not expose them. (This is a limitation of the generated code.)

---

#### `paymentIntents.getPaymentIntents(options?)`

- **HTTP Method:** `GET`
- **Path:** `/v1/payment_intents`

**Query Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `created` | `string` | No | Filter by created date |
| `customer` | `string` | No | Filter by customer ID |
| `customer_account` | `string` | No | Filter by customer account |
| `ending_before` | `string` | No | Pagination cursor |
| `expand` | `string` | No | Fields to expand |
| `limit` | `number` | No | Number of results |
| `starting_after` | `string` | No | Pagination cursor |
| `headers` | `Record<string, string>` | No | Additional headers |

**Response `data`:** `{ data: payment_intent[], has_more, object, url }`

---

#### `terminal.postTerminalReadersReaderConfirmPaymentIntent(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/terminal/readers/{reader}/confirm_payment_intent`
- **Path Parameter:** `reader` (required)

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `reader` | `string` | Yes | Reader ID |
| `headers` | `Record<string, string>` | No | Additional headers |

**Response `data`:** `terminal.reader` object.

---

#### `paymentMethods.getPaymentMethods(options?)`

- **HTTP Method:** `GET`
- **Path:** `/v1/payment_methods`

**Query Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `allow_redisplay` | `string` | No | Filter |
| `customer` | `string` | No | Filter by customer |
| `customer_account` | `string` | No | Filter by account |
| `ending_before` | `string` | No | Pagination |
| `expand` | `string` | No | Expand fields |
| `limit` | `number` | No | Limit |
| `starting_after` | `string` | No | Pagination |
| `type` | `string` | No | Filter by payment method type |
| `headers` | `Record<string, string>` | No | Additional headers |

**Response `data`:** `{ data: payment_method[], has_more, object, url }`

---

#### `invoicePayments.getInvoicePayments(options?)`

- **HTTP Method:** `GET`
- **Path:** `/v1/invoice_payments`

**Query Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `created` | `string` | No | Filter by date |
| `ending_before` | `string` | No | Pagination |
| `expand` | `string` | No | Expand fields |
| `invoice` | `string` | No | Filter by invoice ID |
| `limit` | `number` | No | Limit |
| `payment` | `string` | No | Filter by payment ID |
| `starting_after` | `string` | No | Pagination |
| `status` | `string` | No | Filter by status |
| `headers` | `Record<string, string>` | No | Additional headers |

**Response `data`:** `{ data: invoice_payment[], has_more, object, url }`

---

#### `radar.postRadarPaymentEvaluations(options?)`

- **HTTP Method:** `POST`
- **Path:** `/v1/radar/payment_evaluations`

**Parameters:** Only `headers` (optional).

**Response `data`:** `radar.payment_evaluation` object.

---

#### `testHelpers.postTestHelpersTreasuryOutboundPaymentsIdPost(options)`

- **HTTP Method:** `POST`
- **Path:** `/v1/test_helpers/treasury/outbound_payments/{id}/post`
- **Path Parameter:** `id` (required) – OutboundPayment ID

**Parameters:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | `string` | Yes | OutboundPayment ID |
| `headers` | `Record<string, string>` | No | Additional headers |

**Response `data`:** `treasury.outbound_payment` object.

---

## Error Handling

All errors are returned in the response object – they are not thrown. Always check the `ok` flag.

```typescript
const response = await client.paymentIntents.getPaymentIntents();
if (!response.ok) {
  // response.error contains:
  // {
  //   error: {
  //     code: string;      // Stripe error code
  //     message: string;   // Human-readable message
  //     type: string;      // e.g. 'invalid_request_error'
  //   }
  // }
  console.error(response.error);
} else {
  console.log(response.data);
}
```

## TypeScript Types

The SDK exports all relevant TypeScript types. You can import them directly:

```typescript
import { StripeClient, PlunkClient } from 'generated-sdk';
import type { SendTransactionalEmailOptions, SendTransactionalEmailResponse } from 'generated-sdk';
```