# Generated SDK (v1.0.0) - AI Agent Documentation

This SDK provides programmatic access to **Plunk** (transactional email) and **Stripe** (payments, billing, treasury, etc.). It is auto-generated and designed for deterministic, type-safe interactions.

## Installation

```bash
npm install generated-sdk@1.0.0
```

## Core Concepts

- **Client Instantiation**: Create a client instance with optional configuration (e.g., `baseUrl`, `timeoutMs`).
- **Authentication**: Call `client.setAuth(credentials)` to inject API keys or tokens. **Never ask the user for raw secret keys** – they have been securely injected into the environment. Use `process.env.STRIPE_KEY` or `process.env.PLUNK_TOKEN` directly.
- **Response Shape**: Every method returns a **discriminated union**:
  ```typescript
  { ok: true, status: number, data: T, error: null }
  // OR
  { ok: false, status: number, data: null, error: E }
  ```
  **Always check `response.ok` before accessing `data`.**
- **Webhooks**: The MCP server receives webhook events as structured payloads:
  ```typescript
  { body: any, headers: Record<string, string>, query: Record<string, string>, params: Record<string, string>, path: string }
  ```
  The `body` field is `null` if no request body is present.
- **Types**: All shared types (e.g., `payment_link`, `invoice`, `error`) are exported from the package. See `types.ts` for full schema definitions.

## Plunk Client

### Instantiation & Authentication

```typescript
import { PlunkClient } from 'generated-sdk';

const plunk = new PlunkClient();
plunk.setAuth({ token: process.env.PLUNK_TOKEN });
```

### Methods

#### `plunk.send.sendTransactionalEmail(options)`

Sends a transactional email.

- **Options** (`SendTransactionalEmailOptions`):
  - `body: string` (required) – Email body.
  - `subject: string` (required) – Email subject.
  - `to: string` (required) – Recipient email.
  - `headers?: Record<string, string>` (optional) – Custom headers.
- **Success response** (`SendTransactionalEmailSuccessResult`):
  ```typescript
  { data?: Record<string, any>, success?: boolean }
  ```
- **Error response** (`SendTransactionalEmailErrorResult`):
  ```typescript
  { error: { code: string, message: string }, success: boolean }
  ```

## Stripe Client

### Instantiation & Authentication

```typescript
import { StripeClient } from 'generated-sdk';

const stripe = new StripeClient();
stripe.setAuth({ token: process.env.STRIPE_KEY });
// Or for basic auth:
// stripe.setAuth({ username: 'sk_test_...', password: '' });
```

### Methods

All methods are grouped by resource. Below is the complete list.

---

#### `stripe.paymentLinks.getPaymentLinks(options?)`
List all payment links.

- **Options** (`GetPaymentLinksOptions`):
  - `active?: string` – If `"true"`, only return active payment links.
  - `ending_before?: string` – A cursor for pagination.
  - `expand?: string` – Fields to expand.
  - `limit?: number` – Max items to return.
  - `starting_after?: string` – A cursor for pagination.
  - `headers?: Record<string, string>`
- **Success** (`GetPaymentLinksSuccessResult`): `{ data: payment_link[], has_more: boolean, object: string, url: string }`
- **Error**: `error` type.

---

#### `stripe.invoices.postInvoicesInvoicePay(options)`
Pay an invoice.

- **Options** (`PostInvoicesInvoicePayOptions`):
  - `invoice: string` (required) – Invoice ID.
  - `headers?: Record<string, string>`
- **Success**: `invoice` type.
- **Error**: `error` type.

#### `stripe.invoices.postInvoicesInvoiceSend(options)`
Send an invoice for manual payment.

- **Options** (`PostInvoicesInvoiceSendOptions`):
  - `invoice: string` (required) – Invoice ID.
  - `headers?: Record<string, string>`
- **Success**: `invoice` type.
- **Error**: `error` type.

---

#### `stripe.treasury.postTreasuryOutboundPayments(options?)`
Create an OutboundPayment.

- **Options** (`PostTreasuryOutboundPaymentsOptions`):
  - `headers?: Record<string, string>`
- **Success**: `treasury.outbound_payment` type.
- **Error**: `error` type.

---

#### `stripe.paymentIntents.postPaymentIntentsIntentConfirm(options)`
Confirm a PaymentIntent.

- **Options** (`PostPaymentIntentsIntentConfirmOptions`):
  - `intent: string` (required) – PaymentIntent ID.
  - `headers?: Record<string, string>`
- **Success**: `payment_intent` type.
- **Error**: `error` type.

#### `stripe.paymentIntents.postPaymentIntents(options?)`
Create a PaymentIntent.

- **Options** (`PostPaymentIntentsOptions`):
  - `headers?: Record<string, string>`
- **Success**: `payment_intent` type.
- **Error**: `error` type.

#### `stripe.paymentIntents.getPaymentIntents(options?)`
List all PaymentIntents.

- **Options** (`GetPaymentIntentsOptions`):
  - `created?: string` – Filter by creation date.
  - `customer?: string` – Filter by customer ID.
  - `customer_account?: string` – Filter by customer account.
  - `ending_before?: string`
  - `expand?: string`
  - `limit?: number`
  - `starting_after?: string`
  - `headers?: Record<string, string>`
- **Success** (`GetPaymentIntentsSuccessResult`): `{ data: payment_intent[], has_more: boolean, object: string, url: string }`
- **Error**: `error` type.

---

#### `stripe.terminal.postTerminalReadersReaderConfirmPaymentIntent(options)`
Confirm a PaymentIntent on the Reader.

- **Options** (`PostTerminalReadersReaderConfirmPaymentIntentOptions`):
  - `reader: string` (required) – Reader ID.
  - `headers?: Record<string, string>`
- **Success**: `terminal.reader` type.
- **Error**: `error` type.

---

#### `stripe.paymentMethods.getPaymentMethods(options?)`
List PaymentMethods.

- **Options** (`GetPaymentMethodsOptions`):
  - `allow_redisplay?: string`
  - `customer?: string`
  - `customer_account?: string`
  - `ending_before?: string`
  - `expand?: string`
  - `limit?: number`
  - `starting_after?: string`
  - `type?: string` – Filter by payment method type.
  - `headers?: Record<string, string>`
- **Success** (`GetPaymentMethodsSuccessResult`): `{ data: payment_method[], has_more: boolean, object: string, url: string }`
- **Error**: `error` type.

---

#### `stripe.invoicePayments.getInvoicePayments(options?)`
List all payments for an invoice.

- **Options** (`GetInvoicePaymentsOptions`):
  - `created?: string`
  - `ending_before?: string`
  - `expand?: string`
  - `invoice?: string`
  - `limit?: number`
  - `payment?: string`
  - `starting_after?: string`
  - `status?: string`
  - `headers?: Record<string, string>`
- **Success** (`GetInvoicePaymentsSuccessResult`): `{ data: invoice_payment[], has_more: boolean, object: string, url: string }`
- **Error**: `error` type.

---

#### `stripe.radar.postRadarPaymentEvaluations(options?)`
Create a Payment Evaluation.

- **Options** (`PostRadarPaymentEvaluationsOptions`):
  - `headers?: Record<string, string>`
- **Success**: `radar.payment_evaluation` type.
- **Error**: `error` type.

---

#### `stripe.testHelpers.postTestHelpersTreasuryOutboundPaymentsIdPost(options)`
Test mode: Post an OutboundPayment.

- **Options** (`PostTestHelpersTreasuryOutboundPaymentsIdPostOptions`):
  - `id: string` (required) – OutboundPayment ID.
  - `headers?: Record<string, string>`
- **Success**: `treasury.outbound_payment` type.
- **Error**: `error` type.

---

## Shared Types Export

All Stripe types (e.g., `payment_link`, `invoice`, `payment_intent`, `error`, etc.) are re-exported from `'generated-sdk'`. For a complete schema reference, see the `types.ts` file in the package.

## Error Handling

All methods throw on network errors, but return discriminated unions for HTTP-level errors. Example:

```typescript
const response = await stripe.paymentIntents.postPaymentIntents();
if (!response.ok) {
  console.error(response.error);
  // handle: e.g., retry or return fallback
}
const paymentIntent = response.data;
```

## Notes for AI Agents

- **Never ask for secret keys** – they are already injected as environment variables (`process.env.STRIPE_KEY`, `process.env.PLUNK_TOKEN`). Just reference them.
- Use the **flattened options object** pattern (single parameter, not multiple).
- For webhook handling, expect the payload to contain `{ body, headers, query, params, path }`. The `body` may be `null`.
- Always check `response.ok` before using `data`.