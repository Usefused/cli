// Auto-generated Core File. Do not edit manually.
// Powered by Fused - API integration infrastructure for teams that want control.
// Custom SDKs, native webhooks, and MCP servers from APIs you use.
// Learn more at: https://usefused.com

import fetch from 'node-fetch';
import { trace, SpanStatusCode } from '@opentelemetry/api';


// --- types/service.ts ---
export interface Service {
  id?: string;
  name: string; // e.g. "stripe-payments" — unique, used as credential key
  description?: string;
  base_url: string; // e.g. "https://api.stripe.com/v1"
  auth_configs: AuthConfig[];
  rate_limit?: RateLimitConfig;
  retry_config?: RetryConfig;
  default_headers?: Record<string, string>;
  endpoints?: IntegrationObject[];
  webhooks?: WebhookObject[];
  components?: Record<string, Schema>;
}

export interface WebhookObject {
  id?: string;
  name: string;
  description?: string;
  method: string;
  request_body?: Schema;
}

export interface AuthConfig {
  type: string; // 'apiKey', 'http', 'mutualTLS', 'oauth2', 'openIdConnect'
  scheme?: string; // 'bearer', 'basic', etc
  location?: string; // 'header' | 'query' | 'cookie'
  key_name?: string; // header or query param name e.g. "Authorization", "api_key"
  token_url?: string; // for oauth2
  authorization_url?: string; // for oauth2
  open_id_connect_url?: string; // for oidc
  scopes?: string[]; // for oauth2
}

export interface RateLimitConfig {
  strategy?: string; // 'token_bucket' | 'sliding_window' | 'none'
  requests_per_second?: number;
  requests_per_minute?: number;
  burst_limit?: number;
}

export interface RetryConfig {
  strategy?: string; // 'exponential_backoff' | 'linear_backoff' | 'none'
  max_retries: number;
  backoff_ms: number;
  max_delay_ms?: number;
  retry_on: number[]; // HTTP status codes e.g. [429, 500, 502, 503, 504]
}

export interface IntegrationObject {
  id?: string;
  name: string; // e.g. "create_payment_intent"
  description: string;
  resource?: string; // e.g. "payments"
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | string;
  path: string; // e.g. "/payment_intents"
  parameters?: Parameter[];
  request_body?: Schema;
  responses?: Record<string, Schema>;
  graphql_query?: string;
}

export interface Parameter {
  name: string;
  in: 'path' | 'query' | 'header' | string;
  required: boolean;
  type: string;
  description?: string;
}

export interface Schema {
  $ref?: string;
  type: string;
  format?: string; // e.g. "binary" for file downloads
  properties?: Record<string, SchemaProperty>;
  required?: string[];
  example?: unknown;
  items?: SchemaProperty;
}

export interface SchemaProperty {
  $ref?: string;
  type: string;
  description?: string;
  enum?: string[];
  items?: SchemaProperty;
  properties?: Record<string, SchemaProperty>;
}


// --- types/sdk_config.ts ---
export interface SDKConfig {
  baseUrl?: string;                 // Override the default API URL
  headers?: Record<string, string>; // SDK-wide global headers
  timeoutMs?: number;               // default 30000
  debug?: boolean;                  // log requests/responses
}




// --- types/http_types.ts ---
export interface HttpRequest {
  method: string;
  url: string;
  headers: Record<string, string>;
  body?: unknown;
  timeoutMs: number;
  responseType?: 'json' | 'arraybuffer' | 'sse'; // 'arraybuffer' for binary file downloads, 'sse' for streaming
  retryAttempt?: number;
}


export interface HttpResponse<T = unknown> {
  status: number;
  headers: Record<string, string>;
  body: T;
  ok: boolean;
}

export class IntegrationError extends Error {
  constructor(
    public readonly integration: string,
    public readonly endpoint: string,
    public readonly statusCode: number,
    public readonly responseBody: unknown,
    message: string
  ) {
    super(message);
    this.name = 'IntegrationError';
  }
}

export class RateLimitError extends IntegrationError {
  public readonly retryAfterMs?: number;
  constructor(integration: string, endpoint: string, retryAfterMs?: number) {
    super(integration, endpoint, 429, null, `Rate limit exceeded for ${integration}`);
    this.name = 'RateLimitError';
    this.retryAfterMs = retryAfterMs;
  }
}

export class AuthError extends IntegrationError {
  constructor(integration: string, endpoint: string) {
    super(integration, endpoint, 401, null, `Authentication failed for ${integration}`);
    this.name = 'AuthError';
  }
}


// --- http/base_client.ts ---

// Auto-generated. Do not edit manually.
// Powered by Fused - API integration infrastructure for teams that want control.
// Custom SDKs, native webhooks, and MCP servers from APIs you use.
// Learn more at: https://usefused.com

async function readResponseBody(response: any, req: HttpRequest, contentType: string): Promise<any> {
  // Condition: Return a streaming iterable for SSE endpoints without buffering.
  if (req.responseType === 'sse') {
    return createSSEIterable(response.body);
  }
  // Condition: Use arraybuffer() for binary responses so we get a Buffer, not text.
  if (req.responseType === 'arraybuffer') {
    const arrayBuf = await response.arrayBuffer();
    return Buffer.from(arrayBuf);
  }
  // Condition: Attempt JSON parse for application/json content, fallback to raw text.
  const text = await response.text();
  if (contentType.includes('application/json') && text) {
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }
  return text;
}

export class BaseClient {
  constructor(
    private readonly integrationName: string,
    private readonly baseUrl: string,
    private readonly timeoutMs: number,
    private readonly debug: boolean,
    private readonly defaultHeaders?: Record<string, string>
  ) {
    this.baseUrl = this.baseUrl.replace(/\/+$/, '');
  }

  async request<T>(req: HttpRequest): Promise<HttpResponse<T>> {
    const tracer = trace.getTracer('fused-sdk');
    const spanName = `HTTP ${req.method} ${this.integrationName}`;

    return tracer.startActiveSpan(spanName, async (span) => {
      const url = `${this.baseUrl}${req.url.startsWith('/') ? req.url : '/' + req.url}`;
      span.setAttribute('http.method', req.method);
      span.setAttribute('http.url', url);
      span.setAttribute('peer.service', this.integrationName);
      if (req.retryAttempt !== undefined) {
        span.setAttribute('http.retry_count', req.retryAttempt);
      }

      const startTime = Date.now();

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), req.timeoutMs || this.timeoutMs);

      try {
        const response = await fetch(url, {
          method: req.method,
          headers: { ...this.defaultHeaders, ...req.headers },
          body: req.body !== undefined ? JSON.stringify(req.body) : undefined,
          signal: controller.signal as any
        });

        const contentType = response.headers.get('content-type') || '';
        const body = await readResponseBody(response, req, contentType);

        const duration = Date.now() - startTime;
        if (this.debug) {
          console.log(`[${this.integrationName}] ${req.method} ${url} → ${response.status} (${duration}ms)`);
        }

        const headers: Record<string, string> = {};
        response.headers.forEach((value, key) => {
          headers[key] = value;
        });

        span.setAttribute('http.status_code', response.status);
        if (!response.ok) {
          span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP Error: ${response.status}` });
        } else {
          span.setStatus({ code: SpanStatusCode.OK });
        }

        return {
          status: response.status,
          headers,
          body: body as T,
          ok: response.ok
        };
      } catch (err: any) {
        span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
        span.recordException(err);
        throw err;
      } finally {
        clearTimeout(timeout);
        span.end();
      }
    });
  }
}


export function buildGraphQLSelection(fieldMap: Record<string, string>, fields?: string[]): string {
  if (fields && fields.length > 0) {
    return fields.map(f => fieldMap[f]).filter(Boolean).join('\n');
  }
  return Object.values(fieldMap).join('\n');
}


// --- http/error_normaliser.ts ---

export function normaliseError(integration: string, endpoint: string, response: HttpResponse): never {
  if (response.status === 401 || response.status === 403) {
    throw new AuthError(integration, endpoint);
  }
  
  if (response.status === 429) {
    let retryAfterMs: number | undefined;
    const headers = response.headers || {};
    // Check case-insensitive
    const retryAfterKey = Object.keys(headers).find(k => k.toLowerCase() === 'retry-after');
    if (retryAfterKey) {
      const retryAfter = headers[retryAfterKey];
      const parsed = parseInt(retryAfter, 10);
      if (!isNaN(parsed)) {
        retryAfterMs = parsed * 1000;
      }
    }
    throw new RateLimitError(integration, endpoint, retryAfterMs);
  }
  
  throw new IntegrationError(
    integration, 
    endpoint, 
    response.status, 
    response.body, 
    `Integration ${integration} returned ${response.status} for ${endpoint}`
  );
}


// --- http/response_parser.ts ---

export function parseResponse<T>(response: HttpResponse, schema: Schema): T {
  if (schema.type === 'object' && schema.required && typeof response.body === 'object' && response.body !== null) {
    const bodyObj = response.body as Record<string, unknown>;
    for (const reqField of schema.required) {
      if (!(reqField in bodyObj)) {
        throw new Error(`Response validation failed: missing required field "${reqField}"`);
      }
    }
  }
  return response.body as T;
}


// --- http/sse_parser.ts ---

// Auto-generated. Do not edit manually.
// Powered by Fused - API integration infrastructure for teams that want control.
// Custom SDKs, native webhooks, and MCP servers from APIs you use.
// Learn more at: https://usefused.com

export async function* createSSEIterable<T>(stream: NodeJS.ReadableStream): AsyncGenerator<T> {
  let buffer = '';
  // Loop: Consume each chunk as it arrives from the open socket.
  for await (const chunk of stream) {
    buffer += chunk.toString();
    const events = buffer.split('\n\n');
    // Ternary condition: Keep any incomplete trailing frame in the buffer.
    buffer = events.pop() ?? '';
    // Loop: Process each fully delimited SSE event.
    for (const event of events) {
      const dataLine = event.split('\n').find(l => l.startsWith('data:'));
      // Condition: Skip keep-alive or comment-only frames that carry no data line.
      if (!dataLine) continue;
      const raw = dataLine.slice(5).trim();
      // Condition: OpenAI-style stream terminator signals end of stream.
      if (raw === '[DONE]') return;
      try { yield JSON.parse(raw) as T; } catch { /* non-JSON frame, skip */ }
    }
  }
}


// --- auth/auth_provider.ts ---

export interface AuthProvider {
  apply(req: HttpRequest): Promise<HttpRequest>;
}


// --- auth/http_provider.ts ---

export class HttpProvider implements AuthProvider {
  constructor(
    private readonly scheme: string,
    private readonly tokenOrCredentials: string
  ) {}

  async apply(req: HttpRequest): Promise<HttpRequest> {
    const updated = { ...req };
    const authHeader = `${this.scheme.charAt(0).toUpperCase() + this.scheme.slice(1)} ${this.tokenOrCredentials}`;
    updated.headers = { ...updated.headers, 'Authorization': authHeader };
    return updated;
  }
}


// --- retry/no_retry.ts ---

export class NoRetry {
  async execute<T>(fn: (attempt: number) => Promise<HttpResponse<T>>): Promise<HttpResponse<T>> {
    return fn(0);
  }
}


// --- rate_limit/no_rate_limit.ts ---
export class NoRateLimit {
  async acquire(): Promise<void> {
    return Promise.resolve();
  }
}

