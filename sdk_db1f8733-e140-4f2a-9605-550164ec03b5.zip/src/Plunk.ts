// Auto-generated. Do not edit manually.
// Powered by Fused - API integration infrastructure for teams that want control.
// Custom SDKs, native webhooks, and MCP servers from APIs you use.
// Learn more at: https://usefused.com

import { NoRetry } from './core';
import { NoRateLimit } from './core';
import { BaseClient } from './core';
import { normaliseError, buildGraphQLSelection } from './core';
// Auth providers are imported as values (they are instantiated with `new`).
import { HttpProvider } from './core';
import type { SDKConfig, AuthProvider, HttpRequest } from './core';



export interface SendTransactionalEmailOptions {
  'body': string;
  'subject': string;
  'to': string;
  headers?: Record<string, string>;
}
export interface SendTransactionalEmailSuccessResult {
  'data'?: Record<string, any>;
  'success'?: boolean;
}
export type SendTransactionalEmailErrorResult = {
    'error': {
      'code': string;
      'message': string;
    };
    'success': boolean;
  };
export type SendTransactionalEmailResponse =
  | { ok: true; status: number; data: SendTransactionalEmailSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: SendTransactionalEmailErrorResult };

export interface PlunkIntegrationAuth {
  token?: string;
}
export interface PlunkIntegrationConfig extends SDKConfig {

}

export class PlunkClient {
  private _auths: AuthProvider[] = [];
  
  private readonly _retry: NoRetry;
  private readonly _rateLimit: NoRateLimit;
  private readonly _http: BaseClient;
  private readonly _timeoutMs: number;

  constructor(config: PlunkIntegrationConfig = {}) {
    
    this._retry = new NoRetry();
    this._rateLimit = new NoRateLimit();
    this._http = new BaseClient('Plunk', config.baseUrl || 'https://next-api.useplunk.com', config.timeoutMs ?? 30000, config.debug ?? false, { ...{}, ...config.headers });
    this._timeoutMs = config.timeoutMs ?? 30000;
  }

  public setAuth(credentials: PlunkIntegrationAuth) {
    this._auths = [];
    if (credentials.token) { this._auths.push(new HttpProvider('bearer', credentials.token)); }
  }


  private _buildUrl(path: string, pathParams: Record<string, any>, queryParams: Record<string, any>): string {
    let url = path;
    const qs = new URLSearchParams();
    
    // Loop: Replace path params safely
    for (const [key, value] of Object.entries(pathParams)) {
      // Condition: Ignore undefined keys
      if (value !== undefined) {
        url = url.replace(`{${key}}`, encodeURIComponent(String(value)));
      }
    }
    
    // Loop: Populate query params
    for (const [key, value] of Object.entries(queryParams)) {
      // Condition: Ignore undefined query items
      if (value !== undefined) {
        qs.append(key, String(value));
      }
    }
    
    const qsStr = qs.toString();
    // Condition: Append querystring safely
    if (qsStr) {
      // Ternary: Determine if '?' or '&' should be appended
      url += (url.includes('?') ? '&' : '?') + qsStr;
    }
    
    return url;
  }
  




  public readonly send = {

  /**
   * Send transactional email
   */
  sendTransactionalEmail: async (options: SendTransactionalEmailOptions): Promise<SendTransactionalEmailResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'headers': _headers, ...body } = opts;

    const url = this._buildUrl('/v1/send', {}, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: body,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Plunk', 'sendTransactionalEmail', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as SendTransactionalEmailSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as SendTransactionalEmailErrorResult };
    }
  }
  };
}
