
// Re-export shared config and HTTP types from core for consumers who need them.
export type { SDKConfig } from './core';
export type { HttpRequest, HttpResponse } from './core';


// Shared Components
export type StripeEvent = {
  'account'?: string;
  'api_version'?: string;
  'context'?: string;
  'created': number;
  'data': StripeEventData;
  'id': string;
  'livemode': boolean;
  'object': Record<string, any>;
  'pending_webhooks': number;
  'request'?: Record<string, any>;
  'type': string;
};

export type StripeEventData = {
  'object': Record<string, any>;
  'previous_attributes'?: Record<string, any>;
};

export type StripeEventRequest = {
  'id'?: string;
  'idempotency_key'?: string;
};

export type account = {
  'business_profile'?: Record<string, any>;
  'business_type'?: string;
  'capabilities'?: account_capabilities;
  'charges_enabled'?: boolean;
  'company'?: legal_entity_company;
  'controller'?: account_unification_account_controller;
  'country'?: string;
  'created'?: number;
  'default_currency'?: string;
  'details_submitted'?: boolean;
  'email'?: string;
  'external_accounts'?: {
    'data': Record<string, any>[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'future_requirements'?: account_future_requirements;
  'groups'?: Record<string, any>;
  'id': string;
  'individual'?: person;
  'metadata'?: Record<string, any>;
  'object': string;
  'payouts_enabled'?: boolean;
  'requirements'?: account_requirements;
  'settings'?: Record<string, any>;
  'tos_acceptance'?: account_tos_acceptance;
  'type'?: string;
};

export type account_annual_revenue = {
  'amount'?: number;
  'currency'?: string;
  'fiscal_year_end'?: string;
};

export type account_bacs_debit_payments_settings = {
  'display_name'?: string;
  'service_user_number'?: string;
};

export type account_branding_settings = {
  'icon'?: Record<string, any>;
  'logo'?: Record<string, any>;
  'primary_color'?: string;
  'secondary_color'?: string;
};

export type account_business_profile = {
  'annual_revenue'?: Record<string, any>;
  'estimated_worker_count'?: number;
  'mcc'?: string;
  'minority_owned_business_designation'?: string[];
  'monthly_estimated_revenue'?: account_monthly_estimated_revenue;
  'name'?: string;
  'product_description'?: string;
  'support_address'?: Record<string, any>;
  'support_email'?: string;
  'support_phone'?: string;
  'support_url'?: string;
  'url'?: string;
};

export type account_capabilities = {
  'acss_debit_payments'?: string;
  'affirm_payments'?: string;
  'afterpay_clearpay_payments'?: string;
  'alma_payments'?: string;
  'amazon_pay_payments'?: string;
  'app_distribution'?: string;
  'au_becs_debit_payments'?: string;
  'bacs_debit_payments'?: string;
  'bancontact_payments'?: string;
  'bank_transfer_payments'?: string;
  'billie_payments'?: string;
  'bizum_payments'?: string;
  'blik_payments'?: string;
  'boleto_payments'?: string;
  'card_issuing'?: string;
  'card_payments'?: string;
  'cartes_bancaires_payments'?: string;
  'cashapp_payments'?: string;
  'crypto_payments'?: string;
  'eps_payments'?: string;
  'fpx_payments'?: string;
  'gb_bank_transfer_payments'?: string;
  'giropay_payments'?: string;
  'grabpay_payments'?: string;
  'ideal_payments'?: string;
  'india_international_payments'?: string;
  'jcb_payments'?: string;
  'jp_bank_transfer_payments'?: string;
  'kakao_pay_payments'?: string;
  'klarna_payments'?: string;
  'konbini_payments'?: string;
  'kr_card_payments'?: string;
  'legacy_payments'?: string;
  'link_payments'?: string;
  'mb_way_payments'?: string;
  'mobilepay_payments'?: string;
  'multibanco_payments'?: string;
  'mx_bank_transfer_payments'?: string;
  'naver_pay_payments'?: string;
  'nz_bank_account_becs_debit_payments'?: string;
  'oxxo_payments'?: string;
  'p24_payments'?: string;
  'pay_by_bank_payments'?: string;
  'payco_payments'?: string;
  'paynow_payments'?: string;
  'payto_payments'?: string;
  'pix_payments'?: string;
  'promptpay_payments'?: string;
  'revolut_pay_payments'?: string;
  'samsung_pay_payments'?: string;
  'satispay_payments'?: string;
  'scalapay_payments'?: string;
  'sepa_bank_transfer_payments'?: string;
  'sepa_debit_payments'?: string;
  'sofort_payments'?: string;
  'sunbit_payments'?: string;
  'swish_payments'?: string;
  'tax_reporting_us_1099_k'?: string;
  'tax_reporting_us_1099_misc'?: string;
  'transfers'?: string;
  'treasury'?: string;
  'twint_payments'?: string;
  'upi_payments'?: string;
  'us_bank_account_ach_payments'?: string;
  'us_bank_transfer_payments'?: string;
  'zip_payments'?: string;
};

export type account_capability_future_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'current_deadline'?: number;
  'currently_due': string[];
  'disabled_reason'?: string;
  'errors': account_requirements_error[];
  'eventually_due': string[];
  'past_due': string[];
  'pending_verification': string[];
};

export type account_capability_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'current_deadline'?: number;
  'currently_due': string[];
  'disabled_reason'?: string;
  'errors': account_requirements_error[];
  'eventually_due': string[];
  'past_due': string[];
  'pending_verification': string[];
};

export type account_card_issuing_settings = {
  'tos_acceptance'?: card_issuing_account_terms_of_service;
};

export type account_card_payments_settings = {
  'decline_on'?: account_decline_charge_on;
  'statement_descriptor_prefix'?: string;
  'statement_descriptor_prefix_kana'?: string;
  'statement_descriptor_prefix_kanji'?: string;
};

export type account_dashboard_settings = {
  'display_name'?: string;
  'timezone'?: string;
};

export type account_decline_charge_on = {
  'avs_failure': boolean;
  'cvc_failure': boolean;
};

export type account_future_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'current_deadline'?: number;
  'currently_due'?: string[];
  'disabled_reason'?: string;
  'errors'?: account_requirements_error[];
  'eventually_due'?: string[];
  'past_due'?: string[];
  'pending_verification'?: string[];
};

export type account_group_membership = {
  'payments_pricing'?: string;
};

export type account_invoices_settings = {
  'default_account_tax_ids'?: Record<string, any>[];
  'hosted_payment_method_save'?: string;
};

export type account_link = {
  'created': number;
  'expires_at': number;
  'object': string;
  'url': string;
};

export type account_monthly_estimated_revenue = {
  'amount': number;
  'currency': string;
};

export type account_payments_settings = {
  'statement_descriptor'?: string;
  'statement_descriptor_kana'?: string;
  'statement_descriptor_kanji'?: string;
};

export type account_payout_settings = {
  'debit_negative_balances': boolean;
  'schedule': transfer_schedule;
  'statement_descriptor'?: string;
};

export type account_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'current_deadline'?: number;
  'currently_due'?: string[];
  'disabled_reason'?: string;
  'errors'?: account_requirements_error[];
  'eventually_due'?: string[];
  'past_due'?: string[];
  'pending_verification'?: string[];
};

export type account_requirements_alternative = {
  'alternative_fields_due': string[];
  'original_fields_due': string[];
};

export type account_requirements_error = {
  'code': string;
  'reason': string;
  'requirement': string;
};

export type account_sepa_debit_payments_settings = {
  'creditor_id'?: string;
};

export type account_session = {
  'account': string;
  'client_secret': string;
  'components': connect_embedded_account_session_create_components;
  'expires_at': number;
  'livemode': boolean;
  'object': string;
};

export type account_settings = {
  'bacs_debit_payments'?: account_bacs_debit_payments_settings;
  'branding': account_branding_settings;
  'card_issuing'?: account_card_issuing_settings;
  'card_payments': account_card_payments_settings;
  'dashboard': account_dashboard_settings;
  'invoices'?: account_invoices_settings;
  'payments': account_payments_settings;
  'payouts'?: account_payout_settings;
  'sepa_debit_payments'?: account_sepa_debit_payments_settings;
  'treasury'?: account_treasury_settings;
};

export type account_terms_of_service = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type account_tos_acceptance = {
  'date'?: number;
  'ip'?: string;
  'service_agreement'?: string;
  'user_agent'?: string;
};

export type account_treasury_settings = {
  'tos_acceptance'?: account_terms_of_service;
};

export type account_unification_account_controller = {
  'fees'?: account_unification_account_controller_fees;
  'is_controller'?: boolean;
  'losses'?: account_unification_account_controller_losses;
  'requirement_collection'?: string;
  'stripe_dashboard'?: account_unification_account_controller_stripe_dashboard;
  'type': string;
};

export type account_unification_account_controller_fees = {
  'payer': string;
};

export type account_unification_account_controller_losses = {
  'payments': string;
};

export type account_unification_account_controller_stripe_dashboard = {
  'type': string;
};

export type address = {
  'city'?: string;
  'country'?: string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
};

export type alma_installments = {
  'count': number;
};

export type amazon_pay_underlying_payment_method_funding_details = {
  'card'?: payment_method_details_passthrough_card;
  'type'?: string;
};

export type api_errors = {
  'advice_code'?: string;
  'charge'?: string;
  'code'?: string;
  'decline_code'?: string;
  'doc_url'?: string;
  'message'?: string;
  'network_advice_code'?: string;
  'network_decline_code'?: string;
  'param'?: string;
  'payment_intent'?: payment_intent;
  'payment_method'?: payment_method;
  'payment_method_type'?: string;
  'request_log_url'?: string;
  'setup_intent'?: setup_intent;
  'source'?: Record<string, any>;
  'type': string;
};

export type apple_pay_domain = {
  'created': number;
  'domain_name': string;
  'id': string;
  'livemode': boolean;
  'object': string;
};

export type application = {
  'id': string;
  'name'?: string;
  'object': string;
};

export type application_fee = {
  'account': Record<string, any>;
  'amount': number;
  'amount_refunded': number;
  'application': Record<string, any>;
  'balance_transaction'?: Record<string, any>;
  'charge': Record<string, any>;
  'created': number;
  'currency': string;
  'fee_source'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'object': string;
  'originating_transaction'?: Record<string, any>;
  'refunded': boolean;
  'refunds': {
    'data': fee_refund[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
};

export type apps.secret = {
  'created': number;
  'deleted'?: boolean;
  'expires_at'?: number;
  'id': string;
  'livemode': boolean;
  'name': string;
  'object': string;
  'payload'?: string;
  'scope': secret_service_resource_scope;
};

export type automatic_tax = {
  'disabled_reason'?: string;
  'enabled': boolean;
  'liability'?: Record<string, any>;
  'provider'?: string;
  'status'?: string;
};

export type balance = {
  'available': balance_amount[];
  'connect_reserved'?: balance_amount[];
  'instant_available'?: balance_amount_net[];
  'issuing'?: balance_detail;
  'livemode': boolean;
  'object': string;
  'pending': balance_amount[];
  'refund_and_dispute_prefunding'?: balance_detail_ungated;
};

export type balance_amount = {
  'amount': number;
  'currency': string;
  'source_types'?: balance_amount_by_source_type;
};

export type balance_amount_by_source_type = {
  'bank_account'?: number;
  'card'?: number;
  'fpx'?: number;
};

export type balance_amount_net = {
  'amount': number;
  'currency': string;
  'net_available'?: balance_net_available[];
  'source_types'?: balance_amount_by_source_type;
};

export type balance_detail = {
  'available': balance_amount[];
};

export type balance_detail_ungated = {
  'available': balance_amount[];
  'pending': balance_amount[];
};

export type balance_net_available = {
  'amount': number;
  'destination': string;
  'source_types'?: balance_amount_by_source_type;
};

export type balance_settings = {
  'object': string;
  'payments': balance_settings_resource_payments;
};

export type balance_settings_resource_automatic_transfer_rule = {
  'payout_method': string;
  'transfer_up_to_amount'?: number;
  'type': string;
};

export type balance_settings_resource_payments = {
  'debit_negative_balances'?: boolean;
  'payouts'?: Record<string, any>;
  'settlement_timing': balance_settings_resource_settlement_timing;
};

export type balance_settings_resource_payout_schedule = {
  'interval'?: string;
  'monthly_payout_days'?: number[];
  'weekly_payout_days'?: string[];
};

export type balance_settings_resource_payouts = {
  'automatic_transfer_rules_by_currency'?: Record<string, any>;
  'minimum_balance_by_currency'?: Record<string, any>;
  'schedule'?: Record<string, any>;
  'statement_descriptor'?: string;
  'status': string;
};

export type balance_settings_resource_settlement_timing = {
  'delay_days': number;
  'delay_days_override'?: number;
  'start_of_day'?: Record<string, any>;
};

export type balance_settings_resource_start_of_day = {
  'hour': number;
  'minutes': number;
  'timezone': string;
};

export type balance_transaction = {
  'amount': number;
  'available_on': number;
  'balance_type': string;
  'created': number;
  'currency': string;
  'description'?: string;
  'exchange_rate'?: number;
  'fee': number;
  'fee_details': fee[];
  'id': string;
  'net': number;
  'object': string;
  'reporting_category': string;
  'source'?: Record<string, any>;
  'status': string;
  'type': string;
};

export type bank_account = {
  'account'?: Record<string, any>;
  'account_holder_name'?: string;
  'account_holder_type'?: string;
  'account_type'?: string;
  'available_payout_methods'?: string[];
  'bank_name'?: string;
  'country': string;
  'currency': string;
  'customer'?: Record<string, any>;
  'default_for_currency'?: boolean;
  'fingerprint'?: string;
  'future_requirements'?: Record<string, any>;
  'id': string;
  'last4': string;
  'metadata'?: Record<string, any>;
  'object': string;
  'requirements'?: Record<string, any>;
  'routing_number'?: string;
  'status': string;
};

export type bank_connections_resource_account_number_details = {
  'expected_expiry_date'?: number;
  'identifier_type': string;
  'status': string;
  'supported_networks': string[];
};

export type bank_connections_resource_accountholder = {
  'account'?: Record<string, any>;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'type': string;
};

export type bank_connections_resource_balance = {
  'as_of': number;
  'cash'?: bank_connections_resource_balance_api_resource_cash_balance;
  'credit'?: bank_connections_resource_balance_api_resource_credit_balance;
  'current': Record<string, any>;
  'type': string;
};

export type bank_connections_resource_balance_api_resource_cash_balance = {
  'available'?: Record<string, any>;
};

export type bank_connections_resource_balance_api_resource_credit_balance = {
  'used'?: Record<string, any>;
};

export type bank_connections_resource_balance_refresh = {
  'last_attempted_at': number;
  'next_refresh_available_at'?: number;
  'status': string;
};

export type bank_connections_resource_link_account_session_filters = {
  'account_subcategories'?: string[];
  'countries'?: string[];
};

export type bank_connections_resource_ownership_refresh = {
  'last_attempted_at': number;
  'next_refresh_available_at'?: number;
  'status': string;
};

export type bank_connections_resource_transaction_refresh = {
  'id': string;
  'last_attempted_at': number;
  'next_refresh_available_at'?: number;
  'status': string;
};

export type bank_connections_resource_transaction_resource_status_transitions = {
  'posted_at'?: number;
  'void_at'?: number;
};

export type billing.alert = {
  'alert_type': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status'?: string;
  'title': string;
  'usage_threshold'?: Record<string, any>;
};

export type billing.credit_balance_summary = {
  'balances': credit_balance[];
  'customer': Record<string, any>;
  'customer_account'?: string;
  'livemode': boolean;
  'object': string;
};

export type billing.credit_balance_transaction = {
  'created': number;
  'credit'?: Record<string, any>;
  'credit_grant': Record<string, any>;
  'debit'?: Record<string, any>;
  'effective_at': number;
  'id': string;
  'livemode': boolean;
  'object': string;
  'test_clock'?: Record<string, any>;
  'type'?: string;
};

export type billing.credit_grant = {
  'amount': billing_credit_grants_resource_amount;
  'applicability_config': billing_credit_grants_resource_applicability_config;
  'category': string;
  'created': number;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'effective_at'?: number;
  'expires_at'?: number;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'name'?: string;
  'object': string;
  'priority'?: number;
  'test_clock'?: Record<string, any>;
  'updated': number;
  'voided_at'?: number;
};

export type billing.meter = {
  'created': number;
  'customer_mapping': billing_meter_resource_customer_mapping_settings;
  'default_aggregation': billing_meter_resource_aggregation_settings;
  'display_name': string;
  'event_name': string;
  'event_time_window'?: string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status': string;
  'status_transitions': billing_meter_resource_billing_meter_status_transitions;
  'updated': number;
  'value_settings': billing_meter_resource_billing_meter_value;
};

export type billing.meter_event = {
  'created': number;
  'event_name': string;
  'identifier': string;
  'livemode': boolean;
  'object': string;
  'payload': Record<string, any>;
  'timestamp': number;
};

export type billing.meter_event_adjustment = {
  'cancel'?: Record<string, any>;
  'event_name': string;
  'livemode': boolean;
  'object': string;
  'status': string;
  'type': string;
};

export type billing.meter_event_summary = {
  'aggregated_value': number;
  'end_time': number;
  'id': string;
  'livemode': boolean;
  'meter': string;
  'object': string;
  'start_time': number;
};

export type billing_bill_resource_invoice_item_parents_invoice_item_parent = {
  'subscription_details'?: Record<string, any>;
  'type': string;
};

export type billing_bill_resource_invoice_item_parents_invoice_item_subscription_parent = {
  'subscription': string;
  'subscription_item'?: string;
};

export type billing_bill_resource_invoicing_lines_common_credited_items = {
  'invoice': string;
  'invoice_line_items': string[];
};

export type billing_bill_resource_invoicing_lines_common_proration_details = {
  'credited_items'?: Record<string, any>;
};

export type billing_bill_resource_invoicing_lines_parents_invoice_line_item_invoice_item_parent = {
  'invoice_item': string;
  'proration': boolean;
  'proration_details'?: Record<string, any>;
  'subscription'?: string;
};

export type billing_bill_resource_invoicing_lines_parents_invoice_line_item_parent = {
  'invoice_item_details'?: Record<string, any>;
  'subscription_item_details'?: Record<string, any>;
  'type': string;
};

export type billing_bill_resource_invoicing_lines_parents_invoice_line_item_subscription_item_parent = {
  'invoice_item'?: string;
  'proration': boolean;
  'proration_details'?: Record<string, any>;
  'subscription'?: string;
  'subscription_item': string;
};

export type billing_bill_resource_invoicing_parents_invoice_parent = {
  'quote_details'?: Record<string, any>;
  'subscription_details'?: Record<string, any>;
  'type': string;
};

export type billing_bill_resource_invoicing_parents_invoice_quote_parent = {
  'quote': string;
};

export type billing_bill_resource_invoicing_parents_invoice_subscription_parent = {
  'metadata'?: Record<string, any>;
  'subscription': Record<string, any>;
  'subscription_proration_date'?: number;
};

export type billing_bill_resource_invoicing_pricing_pricing = {
  'price_details'?: billing_bill_resource_invoicing_pricing_pricing_price_details;
  'type': string;
  'unit_amount_decimal'?: string;
};

export type billing_bill_resource_invoicing_pricing_pricing_price_details = {
  'price': Record<string, any>;
  'product': string;
};

export type billing_bill_resource_invoicing_taxes_tax = {
  'amount': number;
  'tax_behavior': string;
  'tax_rate_details'?: Record<string, any>;
  'taxability_reason': string;
  'taxable_amount'?: number;
  'type': string;
};

export type billing_bill_resource_invoicing_taxes_tax_rate_details = {
  'tax_rate': Record<string, any>;
};

export type billing_clocks_resource_status_details_advancing_status_details = {
  'target_frozen_time': number;
};

export type billing_clocks_resource_status_details_status_details = {
  'advancing'?: billing_clocks_resource_status_details_advancing_status_details;
};

export type billing_credit_grants_resource_amount = {
  'monetary'?: Record<string, any>;
  'type': string;
};

export type billing_credit_grants_resource_applicability_config = {
  'scope': billing_credit_grants_resource_scope;
};

export type billing_credit_grants_resource_applicable_price = {
  'id'?: string;
};

export type billing_credit_grants_resource_balance_credit = {
  'amount': billing_credit_grants_resource_amount;
  'credits_application_invoice_voided'?: Record<string, any>;
  'type': string;
};

export type billing_credit_grants_resource_balance_credits_application_invoice_voided = {
  'invoice': Record<string, any>;
  'invoice_line_item': string;
};

export type billing_credit_grants_resource_balance_credits_applied = {
  'invoice': Record<string, any>;
  'invoice_line_item': string;
};

export type billing_credit_grants_resource_balance_debit = {
  'amount': billing_credit_grants_resource_amount;
  'credits_applied'?: Record<string, any>;
  'type': string;
};

export type billing_credit_grants_resource_monetary_amount = {
  'currency': string;
  'value': number;
};

export type billing_credit_grants_resource_scope = {
  'price_type'?: string;
  'prices'?: billing_credit_grants_resource_applicable_price[];
};

export type billing_details = {
  'address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
  'tax_id'?: string;
};

export type billing_meter_resource_aggregation_settings = {
  'formula': string;
};

export type billing_meter_resource_billing_meter_event_adjustment_cancel = {
  'identifier'?: string;
};

export type billing_meter_resource_billing_meter_status_transitions = {
  'deactivated_at'?: number;
};

export type billing_meter_resource_billing_meter_value = {
  'event_payload_key': string;
};

export type billing_meter_resource_customer_mapping_settings = {
  'event_payload_key': string;
  'type': string;
};

export type billing_portal.configuration = {
  'active': boolean;
  'application'?: Record<string, any>;
  'business_profile': portal_business_profile;
  'created': number;
  'default_return_url'?: string;
  'features': portal_features;
  'id': string;
  'is_default': boolean;
  'livemode': boolean;
  'login_page': portal_login_page;
  'metadata'?: Record<string, any>;
  'name'?: string;
  'object': string;
  'updated': number;
};

export type billing_portal.session = {
  'configuration': Record<string, any>;
  'created': number;
  'customer': string;
  'customer_account'?: string;
  'flow'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'locale'?: string;
  'object': string;
  'on_behalf_of'?: string;
  'return_url'?: string;
  'url': string;
};

export type cancellation_details = {
  'comment'?: string;
  'feedback'?: string;
  'reason'?: string;
};

export type capability = {
  'account': Record<string, any>;
  'future_requirements'?: account_capability_future_requirements;
  'id': string;
  'object': string;
  'requested': boolean;
  'requested_at'?: number;
  'requirements'?: account_capability_requirements;
  'status': string;
};

export type card = {
  'account'?: Record<string, any>;
  'address_city'?: string;
  'address_country'?: string;
  'address_line1'?: string;
  'address_line1_check'?: string;
  'address_line2'?: string;
  'address_state'?: string;
  'address_zip'?: string;
  'address_zip_check'?: string;
  'allow_redisplay'?: string;
  'available_payout_methods'?: string[];
  'brand': string;
  'country'?: string;
  'currency'?: string;
  'customer'?: Record<string, any>;
  'cvc_check'?: string;
  'default_for_currency'?: boolean;
  'dynamic_last4'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding': string;
  'id': string;
  'iin'?: string;
  'last4': string;
  'metadata'?: Record<string, any>;
  'name'?: string;
  'networks'?: token_card_networks;
  'object': string;
  'regulated_status'?: string;
  'status'?: string;
  'tokenization_method'?: string;
};

export type card_generated_from_payment_method_details = {
  'card_present'?: payment_method_details_card_present;
  'type': string;
};

export type card_issuing_account_terms_of_service = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type card_mandate_payment_method_details = Record<string, any>;

export type cash_balance = {
  'available'?: Record<string, any>;
  'customer': string;
  'customer_account'?: string;
  'livemode': boolean;
  'object': string;
  'settings': customer_balance_customer_balance_settings;
};

export type charge = {
  'amount': number;
  'amount_captured': number;
  'amount_refunded': number;
  'application'?: Record<string, any>;
  'application_fee'?: Record<string, any>;
  'application_fee_amount'?: number;
  'balance_transaction'?: Record<string, any>;
  'billing_details': billing_details;
  'calculated_statement_descriptor'?: string;
  'captured': boolean;
  'created': number;
  'currency': string;
  'customer'?: Record<string, any>;
  'description'?: string;
  'disputed': boolean;
  'failure_balance_transaction'?: Record<string, any>;
  'failure_code'?: string;
  'failure_message'?: string;
  'fraud_details'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'outcome'?: Record<string, any>;
  'paid': boolean;
  'payment_intent'?: Record<string, any>;
  'payment_method'?: string;
  'payment_method_details'?: Record<string, any>;
  'presentment_details'?: payment_flows_payment_intent_presentment_details;
  'radar_options'?: radar_radar_options;
  'receipt_email'?: string;
  'receipt_number'?: string;
  'receipt_url'?: string;
  'refunded': boolean;
  'refunds'?: {
    'data': refund[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'review'?: Record<string, any>;
  'shipping'?: Record<string, any>;
  'source_transfer'?: Record<string, any>;
  'statement_descriptor'?: string;
  'statement_descriptor_suffix'?: string;
  'status': string;
  'transfer'?: Record<string, any>;
  'transfer_data'?: Record<string, any>;
  'transfer_group'?: string;
};

export type charge_fraud_details = {
  'stripe_report'?: string;
  'user_report'?: string;
};

export type charge_outcome = {
  'advice_code'?: string;
  'network_advice_code'?: string;
  'network_decline_code'?: string;
  'network_status'?: string;
  'reason'?: string;
  'risk_level'?: string;
  'risk_score'?: number;
  'rule'?: Record<string, any>;
  'seller_message'?: string;
  'type': string;
};

export type charge_transfer_data = {
  'amount'?: number;
  'destination': Record<string, any>;
};

export type checkout.session = {
  'adaptive_pricing'?: Record<string, any>;
  'after_expiration'?: Record<string, any>;
  'allow_promotion_codes'?: boolean;
  'amount_subtotal'?: number;
  'amount_total'?: number;
  'automatic_tax': payment_pages_checkout_session_automatic_tax;
  'billing_address_collection'?: string;
  'branding_settings'?: payment_pages_checkout_session_branding_settings;
  'cancel_url'?: string;
  'client_reference_id'?: string;
  'client_secret'?: string;
  'collected_information'?: Record<string, any>;
  'consent'?: Record<string, any>;
  'consent_collection'?: Record<string, any>;
  'created': number;
  'currency'?: string;
  'currency_conversion'?: Record<string, any>;
  'custom_fields': payment_pages_checkout_session_custom_fields[];
  'custom_text': payment_pages_checkout_session_custom_text;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'customer_creation'?: string;
  'customer_details'?: Record<string, any>;
  'customer_email'?: string;
  'discounts'?: payment_pages_checkout_session_discount[];
  'excluded_payment_method_types'?: string[];
  'expires_at': number;
  'id': string;
  'integration_identifier'?: string;
  'invoice'?: Record<string, any>;
  'invoice_creation'?: Record<string, any>;
  'line_items'?: {
    'data': item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'locale'?: string;
  'managed_payments'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'mode': string;
  'name_collection'?: payment_pages_checkout_session_name_collection;
  'object': string;
  'optional_items'?: payment_pages_checkout_session_optional_item[];
  'origin_context'?: string;
  'payment_intent'?: Record<string, any>;
  'payment_link'?: Record<string, any>;
  'payment_method_collection'?: string;
  'payment_method_configuration_details'?: Record<string, any>;
  'payment_method_options'?: Record<string, any>;
  'payment_method_types': string[];
  'payment_status': string;
  'permissions'?: Record<string, any>;
  'phone_number_collection'?: payment_pages_checkout_session_phone_number_collection;
  'presentment_details'?: payment_flows_payment_intent_presentment_details;
  'recovered_from'?: string;
  'redirect_on_completion'?: string;
  'return_url'?: string;
  'saved_payment_method_options'?: Record<string, any>;
  'setup_intent'?: Record<string, any>;
  'shipping_address_collection'?: Record<string, any>;
  'shipping_cost'?: Record<string, any>;
  'shipping_options': payment_pages_checkout_session_shipping_option[];
  'status'?: string;
  'submit_type'?: string;
  'subscription'?: Record<string, any>;
  'success_url'?: string;
  'tax_id_collection'?: payment_pages_checkout_session_tax_id_collection;
  'total_details'?: Record<string, any>;
  'ui_mode'?: string;
  'url'?: string;
  'wallet_options'?: Record<string, any>;
};

export type checkout_acss_debit_mandate_options = {
  'custom_mandate_url'?: string;
  'default_for'?: string[];
  'interval_description'?: string;
  'payment_schedule'?: string;
  'transaction_type'?: string;
};

export type checkout_acss_debit_payment_method_options = {
  'currency'?: string;
  'mandate_options'?: checkout_acss_debit_mandate_options;
  'setup_future_usage'?: string;
  'target_date'?: string;
  'verification_method'?: string;
};

export type checkout_affirm_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_afterpay_clearpay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_alipay_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_alma_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_amazon_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_au_becs_debit_payment_method_options = {
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type checkout_bacs_debit_payment_method_options = {
  'mandate_options'?: checkout_payment_method_options_mandate_options_bacs_debit;
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type checkout_bancontact_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_billie_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_boleto_payment_method_options = {
  'expires_after_days': number;
  'setup_future_usage'?: string;
};

export type checkout_card_installments_options = {
  'enabled'?: boolean;
};

export type checkout_card_payment_method_options = {
  'capture_method'?: string;
  'installments'?: checkout_card_installments_options;
  'request_extended_authorization'?: string;
  'request_incremental_authorization'?: string;
  'request_multicapture'?: string;
  'request_overcapture'?: string;
  'request_three_d_secure': string;
  'restrictions'?: payment_pages_private_card_payment_method_options_resource_restrictions;
  'setup_future_usage'?: string;
  'statement_descriptor_suffix_kana'?: string;
  'statement_descriptor_suffix_kanji'?: string;
};

export type checkout_cashapp_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_customer_balance_bank_transfer_payment_method_options = {
  'eu_bank_transfer'?: payment_method_options_customer_balance_eu_bank_account;
  'requested_address_types'?: string[];
  'type'?: string;
};

export type checkout_customer_balance_payment_method_options = {
  'bank_transfer'?: checkout_customer_balance_bank_transfer_payment_method_options;
  'funding_type'?: string;
  'setup_future_usage'?: string;
};

export type checkout_eps_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_fpx_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_giropay_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_grab_pay_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_ideal_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_kakao_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_klarna_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_konbini_payment_method_options = {
  'expires_after_days'?: number;
  'setup_future_usage'?: string;
};

export type checkout_kr_card_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_link_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_link_wallet_options = {
  'display'?: string;
};

export type checkout_mobilepay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_multibanco_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_naver_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_oxxo_payment_method_options = {
  'expires_after_days': number;
  'setup_future_usage'?: string;
};

export type checkout_p24_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_payco_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_payment_method_options_mandate_options_bacs_debit = {
  'reference_prefix'?: string;
};

export type checkout_payment_method_options_mandate_options_sepa_debit = {
  'reference_prefix'?: string;
};

export type checkout_paynow_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_paypal_payment_method_options = {
  'capture_method'?: string;
  'preferred_locale'?: string;
  'reference'?: string;
  'setup_future_usage'?: string;
};

export type checkout_payto_payment_method_options = {
  'mandate_options'?: mandate_options_payto;
  'setup_future_usage'?: string;
};

export type checkout_pix_payment_method_options = {
  'amount_includes_iof'?: string;
  'expires_after_seconds'?: number;
  'mandate_options'?: payment_method_options_mandate_options_pix;
  'setup_future_usage'?: string;
};

export type checkout_revolut_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type checkout_samsung_pay_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_satispay_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_scalapay_payment_method_options = {
  'capture_method'?: string;
};

export type checkout_sepa_debit_payment_method_options = {
  'mandate_options'?: checkout_payment_method_options_mandate_options_sepa_debit;
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type checkout_session_payment_method_options = {
  'acss_debit'?: checkout_acss_debit_payment_method_options;
  'affirm'?: checkout_affirm_payment_method_options;
  'afterpay_clearpay'?: checkout_afterpay_clearpay_payment_method_options;
  'alipay'?: checkout_alipay_payment_method_options;
  'alma'?: checkout_alma_payment_method_options;
  'amazon_pay'?: checkout_amazon_pay_payment_method_options;
  'au_becs_debit'?: checkout_au_becs_debit_payment_method_options;
  'bacs_debit'?: checkout_bacs_debit_payment_method_options;
  'bancontact'?: checkout_bancontact_payment_method_options;
  'billie'?: checkout_billie_payment_method_options;
  'boleto'?: checkout_boleto_payment_method_options;
  'card'?: checkout_card_payment_method_options;
  'cashapp'?: checkout_cashapp_payment_method_options;
  'customer_balance'?: checkout_customer_balance_payment_method_options;
  'eps'?: checkout_eps_payment_method_options;
  'fpx'?: checkout_fpx_payment_method_options;
  'giropay'?: checkout_giropay_payment_method_options;
  'grabpay'?: checkout_grab_pay_payment_method_options;
  'ideal'?: checkout_ideal_payment_method_options;
  'kakao_pay'?: checkout_kakao_pay_payment_method_options;
  'klarna'?: checkout_klarna_payment_method_options;
  'konbini'?: checkout_konbini_payment_method_options;
  'kr_card'?: checkout_kr_card_payment_method_options;
  'link'?: checkout_link_payment_method_options;
  'mobilepay'?: checkout_mobilepay_payment_method_options;
  'multibanco'?: checkout_multibanco_payment_method_options;
  'naver_pay'?: checkout_naver_pay_payment_method_options;
  'oxxo'?: checkout_oxxo_payment_method_options;
  'p24'?: checkout_p24_payment_method_options;
  'payco'?: checkout_payco_payment_method_options;
  'paynow'?: checkout_paynow_payment_method_options;
  'paypal'?: checkout_paypal_payment_method_options;
  'payto'?: checkout_payto_payment_method_options;
  'pix'?: checkout_pix_payment_method_options;
  'revolut_pay'?: checkout_revolut_pay_payment_method_options;
  'samsung_pay'?: checkout_samsung_pay_payment_method_options;
  'satispay'?: checkout_satispay_payment_method_options;
  'scalapay'?: checkout_scalapay_payment_method_options;
  'sepa_debit'?: checkout_sepa_debit_payment_method_options;
  'sofort'?: checkout_sofort_payment_method_options;
  'swish'?: checkout_swish_payment_method_options;
  'twint'?: checkout_twint_payment_method_options;
  'upi'?: checkout_upi_payment_method_options;
  'us_bank_account'?: checkout_us_bank_account_payment_method_options;
};

export type checkout_session_wallet_options = {
  'link'?: checkout_link_wallet_options;
};

export type checkout_sofort_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_swish_payment_method_options = {
  'reference'?: string;
};

export type checkout_twint_payment_method_options = {
  'setup_future_usage'?: string;
};

export type checkout_upi_payment_method_options = {
  'mandate_options'?: mandate_options_upi;
  'setup_future_usage'?: string;
};

export type checkout_us_bank_account_payment_method_options = {
  'financial_connections'?: linked_account_options_common;
  'setup_future_usage'?: string;
  'target_date'?: string;
  'verification_method'?: string;
};

export type climate.order = {
  'amount_fees': number;
  'amount_subtotal': number;
  'amount_total': number;
  'beneficiary'?: climate_removals_beneficiary;
  'canceled_at'?: number;
  'cancellation_reason'?: string;
  'certificate'?: string;
  'confirmed_at'?: number;
  'created': number;
  'currency': string;
  'delayed_at'?: number;
  'delivered_at'?: number;
  'delivery_details': climate_removals_order_deliveries[];
  'expected_delivery_year': number;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'metric_tons': string;
  'object': string;
  'product': Record<string, any>;
  'product_substituted_at'?: number;
  'status': string;
};

export type climate.product = {
  'created': number;
  'current_prices_per_metric_ton': Record<string, any>;
  'delivery_year'?: number;
  'id': string;
  'livemode': boolean;
  'metric_tons_available': string;
  'name': string;
  'object': string;
  'suppliers': climate.supplier[];
};

export type climate.supplier = {
  'id': string;
  'info_url': string;
  'livemode': boolean;
  'locations': climate_removals_location[];
  'name': string;
  'object': string;
  'removal_pathway': string;
};

export type climate_removals_beneficiary = {
  'public_name': string;
};

export type climate_removals_location = {
  'city'?: string;
  'country': string;
  'latitude'?: number;
  'longitude'?: number;
  'region'?: string;
};

export type climate_removals_order_deliveries = {
  'delivered_at': number;
  'location'?: Record<string, any>;
  'metric_tons': string;
  'registry_url'?: string;
  'supplier': climate.supplier;
};

export type climate_removals_products_price = {
  'amount_fees': number;
  'amount_subtotal': number;
  'amount_total': number;
};

export type confirmation_token = {
  'created': number;
  'expires_at'?: number;
  'id': string;
  'livemode': boolean;
  'mandate_data'?: Record<string, any>;
  'object': string;
  'payment_intent'?: string;
  'payment_method_options'?: Record<string, any>;
  'payment_method_preview'?: Record<string, any>;
  'return_url'?: string;
  'setup_future_usage'?: string;
  'setup_intent'?: string;
  'shipping'?: Record<string, any>;
  'use_stripe_sdk': boolean;
};

export type confirmation_tokens_resource_mandate_data = {
  'customer_acceptance': confirmation_tokens_resource_mandate_data_resource_customer_acceptance;
};

export type confirmation_tokens_resource_mandate_data_resource_customer_acceptance = {
  'online'?: Record<string, any>;
  'type': string;
};

export type confirmation_tokens_resource_mandate_data_resource_customer_acceptance_resource_online = {
  'ip_address'?: string;
  'user_agent'?: string;
};

export type confirmation_tokens_resource_payment_method_options = {
  'card'?: Record<string, any>;
};

export type confirmation_tokens_resource_payment_method_options_resource_card = {
  'cvc_token'?: string;
  'installments'?: confirmation_tokens_resource_payment_method_options_resource_card_resource_installment;
};

export type confirmation_tokens_resource_payment_method_options_resource_card_resource_installment = {
  'plan'?: payment_method_details_card_installments_plan;
};

export type confirmation_tokens_resource_payment_method_preview = {
  'acss_debit'?: payment_method_acss_debit;
  'affirm'?: payment_method_affirm;
  'afterpay_clearpay'?: payment_method_afterpay_clearpay;
  'alipay'?: payment_flows_private_payment_methods_alipay;
  'allow_redisplay'?: string;
  'alma'?: payment_method_alma;
  'amazon_pay'?: payment_method_amazon_pay;
  'au_becs_debit'?: payment_method_au_becs_debit;
  'bacs_debit'?: payment_method_bacs_debit;
  'bancontact'?: payment_method_bancontact;
  'billie'?: payment_method_billie;
  'billing_details': billing_details;
  'bizum'?: payment_method_bizum;
  'blik'?: payment_method_blik;
  'boleto'?: payment_method_boleto;
  'card'?: payment_method_card;
  'card_present'?: payment_method_card_present;
  'cashapp'?: payment_method_cashapp;
  'crypto'?: payment_method_crypto;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'customer_balance'?: payment_method_customer_balance;
  'eps'?: payment_method_eps;
  'fpx'?: payment_method_fpx;
  'giropay'?: payment_method_giropay;
  'grabpay'?: payment_method_grabpay;
  'ideal'?: payment_method_ideal;
  'interac_present'?: payment_method_interac_present;
  'kakao_pay'?: payment_method_kakao_pay;
  'klarna'?: payment_method_klarna;
  'konbini'?: payment_method_konbini;
  'kr_card'?: payment_method_kr_card;
  'link'?: payment_method_link;
  'mb_way'?: payment_method_mb_way;
  'mobilepay'?: payment_method_mobilepay;
  'multibanco'?: payment_method_multibanco;
  'naver_pay'?: payment_method_naver_pay;
  'nz_bank_account'?: payment_method_nz_bank_account;
  'oxxo'?: payment_method_oxxo;
  'p24'?: payment_method_p24;
  'pay_by_bank'?: payment_method_pay_by_bank;
  'payco'?: payment_method_payco;
  'paynow'?: payment_method_paynow;
  'paypal'?: payment_method_paypal;
  'payto'?: payment_method_payto;
  'pix'?: payment_method_pix;
  'promptpay'?: payment_method_promptpay;
  'revolut_pay'?: payment_method_revolut_pay;
  'samsung_pay'?: payment_method_samsung_pay;
  'satispay'?: payment_method_satispay;
  'scalapay'?: payment_method_scalapay;
  'sepa_debit'?: payment_method_sepa_debit;
  'sofort'?: payment_method_sofort;
  'sunbit'?: payment_method_sunbit;
  'swish'?: payment_method_swish;
  'twint'?: payment_method_twint;
  'type': string;
  'upi'?: payment_method_upi;
  'us_bank_account'?: payment_method_us_bank_account;
  'wechat_pay'?: payment_method_wechat_pay;
  'zip'?: payment_method_zip;
};

export type confirmation_tokens_resource_shipping = {
  'address': address;
  'name': string;
  'phone'?: string;
};

export type connect_account_reference = {
  'account'?: Record<string, any>;
  'type': string;
};

export type connect_collection_transfer = {
  'amount': number;
  'currency': string;
  'destination': Record<string, any>;
  'id': string;
  'livemode': boolean;
  'object': string;
};

export type connect_embedded_account_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_account_features_claim;
};

export type connect_embedded_account_features_claim = {
  'disable_stripe_user_authentication': boolean;
  'external_account_collection': boolean;
};

export type connect_embedded_account_session_create_components = {
  'account_management': connect_embedded_account_config_claim;
  'account_onboarding': connect_embedded_account_config_claim;
  'balance_report': connect_embedded_base_config_claim;
  'balances': connect_embedded_payouts_config;
  'disputes_list': connect_embedded_disputes_list_config;
  'documents': connect_embedded_base_config_claim;
  'financial_account': connect_embedded_financial_account_config_claim;
  'financial_account_transactions': connect_embedded_financial_account_transactions_config_claim;
  'instant_payouts_promotion': connect_embedded_instant_payouts_promotion_config;
  'issuing_card': connect_embedded_issuing_card_config_claim;
  'issuing_cards_list': connect_embedded_issuing_cards_list_config_claim;
  'notification_banner': connect_embedded_account_config_claim;
  'payment_details': connect_embedded_payments_config_claim;
  'payment_disputes': connect_embedded_payment_disputes_config;
  'payments': connect_embedded_payments_config_claim;
  'payout_details': connect_embedded_base_config_claim;
  'payout_reconciliation_report': connect_embedded_base_config_claim;
  'payouts': connect_embedded_payouts_config;
  'payouts_list': connect_embedded_base_config_claim;
  'tax_registrations': connect_embedded_base_config_claim;
  'tax_settings': connect_embedded_base_config_claim;
};

export type connect_embedded_base_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_base_features;
};

export type connect_embedded_base_features = Record<string, any>;

export type connect_embedded_disputes_list_config = {
  'enabled': boolean;
  'features': connect_embedded_disputes_list_features;
};

export type connect_embedded_disputes_list_features = {
  'capture_payments': boolean;
  'destination_on_behalf_of_charge_management': boolean;
  'dispute_management': boolean;
  'refund_management': boolean;
};

export type connect_embedded_financial_account_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_financial_account_features;
};

export type connect_embedded_financial_account_features = {
  'disable_stripe_user_authentication': boolean;
  'external_account_collection': boolean;
  'send_money': boolean;
  'transfer_balance': boolean;
};

export type connect_embedded_financial_account_transactions_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_financial_account_transactions_features;
};

export type connect_embedded_financial_account_transactions_features = {
  'card_spend_dispute_management': boolean;
};

export type connect_embedded_instant_payouts_promotion_config = {
  'enabled': boolean;
  'features': connect_embedded_instant_payouts_promotion_features;
};

export type connect_embedded_instant_payouts_promotion_features = {
  'disable_stripe_user_authentication': boolean;
  'external_account_collection': boolean;
  'instant_payouts': boolean;
};

export type connect_embedded_issuing_card_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_issuing_card_features;
};

export type connect_embedded_issuing_card_features = {
  'card_management': boolean;
  'card_spend_dispute_management': boolean;
  'cardholder_management': boolean;
  'spend_control_management': boolean;
};

export type connect_embedded_issuing_cards_list_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_issuing_cards_list_features;
};

export type connect_embedded_issuing_cards_list_features = {
  'card_management': boolean;
  'card_spend_dispute_management': boolean;
  'cardholder_management': boolean;
  'disable_stripe_user_authentication': boolean;
  'spend_control_management': boolean;
};

export type connect_embedded_payment_disputes_config = {
  'enabled': boolean;
  'features': connect_embedded_payment_disputes_features;
};

export type connect_embedded_payment_disputes_features = {
  'destination_on_behalf_of_charge_management': boolean;
  'dispute_management': boolean;
  'refund_management': boolean;
};

export type connect_embedded_payments_config_claim = {
  'enabled': boolean;
  'features': connect_embedded_payments_features;
};

export type connect_embedded_payments_features = {
  'capture_payments': boolean;
  'destination_on_behalf_of_charge_management': boolean;
  'dispute_management': boolean;
  'refund_management': boolean;
};

export type connect_embedded_payouts_config = {
  'enabled': boolean;
  'features': connect_embedded_payouts_features;
};

export type connect_embedded_payouts_features = {
  'disable_stripe_user_authentication': boolean;
  'edit_payout_schedule': boolean;
  'external_account_collection': boolean;
  'instant_payouts': boolean;
  'standard_payouts': boolean;
};

export type country_spec = {
  'default_currency': string;
  'id': string;
  'object': string;
  'supported_bank_account_currencies': Record<string, any>;
  'supported_payment_currencies': string[];
  'supported_payment_methods': string[];
  'supported_transfer_countries': string[];
  'verification_fields': country_spec_verification_fields;
};

export type country_spec_verification_field_details = {
  'additional': string[];
  'minimum': string[];
};

export type country_spec_verification_fields = {
  'company': country_spec_verification_field_details;
  'individual': country_spec_verification_field_details;
};

export type coupon = {
  'amount_off'?: number;
  'applies_to'?: coupon_applies_to;
  'created': number;
  'currency'?: string;
  'currency_options'?: Record<string, any>;
  'duration': string;
  'duration_in_months'?: number;
  'id': string;
  'livemode': boolean;
  'max_redemptions'?: number;
  'metadata'?: Record<string, any>;
  'name'?: string;
  'object': string;
  'percent_off'?: number;
  'redeem_by'?: number;
  'times_redeemed': number;
  'valid': boolean;
};

export type coupon_applies_to = {
  'products': string[];
};

export type coupon_currency_option = {
  'amount_off': number;
};

export type credit_balance = {
  'available_balance': billing_credit_grants_resource_amount;
  'ledger_balance': billing_credit_grants_resource_amount;
};

export type credit_note = {
  'amount': number;
  'amount_shipping': number;
  'created': number;
  'currency': string;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'customer_balance_transaction'?: Record<string, any>;
  'discount_amount': number;
  'discount_amounts': discounts_resource_discount_amount[];
  'effective_at'?: number;
  'id': string;
  'invoice': Record<string, any>;
  'lines': {
    'data': credit_note_line_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'memo'?: string;
  'metadata'?: Record<string, any>;
  'number': string;
  'object': string;
  'out_of_band_amount'?: number;
  'pdf': string;
  'post_payment_amount': number;
  'pre_payment_amount': number;
  'pretax_credit_amounts': credit_notes_pretax_credit_amount[];
  'reason'?: string;
  'refunds': credit_note_refund[];
  'shipping_cost'?: Record<string, any>;
  'status': string;
  'subtotal': number;
  'subtotal_excluding_tax'?: number;
  'total': number;
  'total_excluding_tax'?: number;
  'total_taxes'?: billing_bill_resource_invoicing_taxes_tax[];
  'type': string;
  'voided_at'?: number;
};

export type credit_note_line_item = {
  'amount': number;
  'description'?: string;
  'discount_amount': number;
  'discount_amounts': discounts_resource_discount_amount[];
  'id': string;
  'invoice_line_item'?: string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'pretax_credit_amounts': credit_notes_pretax_credit_amount[];
  'quantity'?: number;
  'tax_rates': tax_rate[];
  'taxes'?: billing_bill_resource_invoicing_taxes_tax[];
  'type': string;
  'unit_amount'?: number;
  'unit_amount_decimal'?: string;
};

export type credit_note_refund = {
  'amount_refunded': number;
  'payment_record_refund'?: Record<string, any>;
  'refund': Record<string, any>;
  'type'?: string;
};

export type credit_notes_payment_record_refund = {
  'payment_record': string;
  'refund_group': string;
};

export type credit_notes_pretax_credit_amount = {
  'amount': number;
  'credit_balance_transaction'?: Record<string, any>;
  'discount'?: Record<string, any>;
  'type': string;
};

export type credited_items_invoice_line_items = {
  'invoice': string;
  'invoice_line_items': string[];
};

export type currency_option = {
  'custom_unit_amount'?: Record<string, any>;
  'tax_behavior'?: string;
  'tiers'?: price_tier[];
  'unit_amount'?: number;
  'unit_amount_decimal'?: string;
};

export type custom_logo = {
  'content_type'?: string;
  'url': string;
};

export type custom_unit_amount = {
  'maximum'?: number;
  'minimum'?: number;
  'preset'?: number;
};

export type customer = {
  'address'?: Record<string, any>;
  'balance'?: number;
  'business_name'?: string;
  'cash_balance'?: Record<string, any>;
  'created': number;
  'currency'?: string;
  'customer_account'?: string;
  'default_source'?: Record<string, any>;
  'delinquent'?: boolean;
  'description'?: string;
  'discount'?: Record<string, any>;
  'email'?: string;
  'id': string;
  'individual_name'?: string;
  'invoice_credit_balance'?: Record<string, any>;
  'invoice_prefix'?: string;
  'invoice_settings'?: invoice_setting_customer_setting;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'name'?: string;
  'next_invoice_sequence'?: number;
  'object': string;
  'phone'?: string;
  'preferred_locales'?: string[];
  'shipping'?: Record<string, any>;
  'sources'?: {
    'data': Record<string, any>[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'subscriptions'?: {
    'data': subscription[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'tax'?: customer_tax;
  'tax_exempt'?: string;
  'tax_ids'?: {
    'data': tax_id[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'test_clock'?: Record<string, any>;
};

export type customer_acceptance = {
  'accepted_at'?: number;
  'offline'?: offline_acceptance;
  'online'?: online_acceptance;
  'type': string;
};

export type customer_balance_customer_balance_settings = {
  'reconciliation_mode': string;
  'using_merchant_default': boolean;
};

export type customer_balance_resource_cash_balance_transaction_resource_adjusted_for_overdraft = {
  'balance_transaction': Record<string, any>;
  'linked_transaction': Record<string, any>;
};

export type customer_balance_resource_cash_balance_transaction_resource_applied_to_payment_transaction = {
  'payment_intent': Record<string, any>;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction = {
  'bank_transfer': customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer = {
  'eu_bank_transfer'?: customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_eu_bank_transfer;
  'gb_bank_transfer'?: customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_gb_bank_transfer;
  'jp_bank_transfer'?: customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_jp_bank_transfer;
  'reference'?: string;
  'type': string;
  'us_bank_transfer'?: customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_us_bank_transfer;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_eu_bank_transfer = {
  'bic'?: string;
  'iban_last4'?: string;
  'sender_name'?: string;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_gb_bank_transfer = {
  'account_number_last4'?: string;
  'sender_name'?: string;
  'sort_code'?: string;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_jp_bank_transfer = {
  'sender_bank'?: string;
  'sender_branch'?: string;
  'sender_name'?: string;
};

export type customer_balance_resource_cash_balance_transaction_resource_funded_transaction_resource_bank_transfer_resource_us_bank_transfer = {
  'network'?: string;
  'sender_name'?: string;
};

export type customer_balance_resource_cash_balance_transaction_resource_refunded_from_payment_transaction = {
  'refund': Record<string, any>;
};

export type customer_balance_resource_cash_balance_transaction_resource_transferred_to_balance = {
  'balance_transaction': Record<string, any>;
};

export type customer_balance_resource_cash_balance_transaction_resource_unapplied_from_payment_transaction = {
  'payment_intent': Record<string, any>;
};

export type customer_balance_transaction = {
  'amount': number;
  'checkout_session'?: Record<string, any>;
  'created': number;
  'credit_note'?: Record<string, any>;
  'currency': string;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'description'?: string;
  'ending_balance': number;
  'id': string;
  'invoice'?: Record<string, any>;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'type': string;
};

export type customer_cash_balance_transaction = {
  'adjusted_for_overdraft'?: customer_balance_resource_cash_balance_transaction_resource_adjusted_for_overdraft;
  'applied_to_payment'?: customer_balance_resource_cash_balance_transaction_resource_applied_to_payment_transaction;
  'created': number;
  'currency': string;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'ending_balance': number;
  'funded'?: customer_balance_resource_cash_balance_transaction_resource_funded_transaction;
  'id': string;
  'livemode': boolean;
  'net_amount': number;
  'object': string;
  'refunded_from_payment'?: customer_balance_resource_cash_balance_transaction_resource_refunded_from_payment_transaction;
  'transferred_to_balance'?: customer_balance_resource_cash_balance_transaction_resource_transferred_to_balance;
  'type': string;
  'unapplied_from_payment'?: customer_balance_resource_cash_balance_transaction_resource_unapplied_from_payment_transaction;
};

export type customer_session = {
  'client_secret': string;
  'components'?: customer_session_resource_components;
  'created': number;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'expires_at': number;
  'livemode': boolean;
  'object': string;
};

export type customer_session_resource_components = {
  'buy_button': customer_session_resource_components_resource_buy_button;
  'customer_sheet': customer_session_resource_components_resource_customer_sheet;
  'mobile_payment_element': customer_session_resource_components_resource_mobile_payment_element;
  'payment_element': customer_session_resource_components_resource_payment_element;
  'pricing_table': customer_session_resource_components_resource_pricing_table;
};

export type customer_session_resource_components_resource_buy_button = {
  'enabled': boolean;
};

export type customer_session_resource_components_resource_customer_sheet = {
  'enabled': boolean;
  'features'?: Record<string, any>;
};

export type customer_session_resource_components_resource_customer_sheet_resource_features = {
  'payment_method_allow_redisplay_filters'?: string[];
  'payment_method_remove'?: string;
};

export type customer_session_resource_components_resource_mobile_payment_element = {
  'enabled': boolean;
  'features'?: Record<string, any>;
};

export type customer_session_resource_components_resource_mobile_payment_element_resource_features = {
  'payment_method_allow_redisplay_filters'?: string[];
  'payment_method_redisplay'?: string;
  'payment_method_remove'?: string;
  'payment_method_save'?: string;
  'payment_method_save_allow_redisplay_override'?: string;
};

export type customer_session_resource_components_resource_payment_element = {
  'enabled': boolean;
  'features'?: Record<string, any>;
};

export type customer_session_resource_components_resource_payment_element_resource_features = {
  'payment_method_allow_redisplay_filters': string[];
  'payment_method_redisplay': string;
  'payment_method_redisplay_limit'?: number;
  'payment_method_remove': string;
  'payment_method_save': string;
  'payment_method_save_usage'?: string;
};

export type customer_session_resource_components_resource_pricing_table = {
  'enabled': boolean;
};

export type customer_tax = {
  'automatic_tax': string;
  'ip_address'?: string;
  'location'?: Record<string, any>;
  'provider': string;
};

export type customer_tax_location = {
  'country': string;
  'source': string;
  'state'?: string;
};

export type deleted_account = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_apple_pay_domain = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_application = {
  'deleted': boolean;
  'id': string;
  'name'?: string;
  'object': string;
};

export type deleted_bank_account = {
  'currency'?: string;
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_card = {
  'currency'?: string;
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_coupon = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_customer = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_discount = {
  'checkout_session'?: string;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'deleted': boolean;
  'id': string;
  'invoice'?: string;
  'invoice_item'?: string;
  'object': string;
  'promotion_code'?: Record<string, any>;
  'source': discount_source;
  'start': number;
  'subscription'?: string;
  'subscription_item'?: string;
};

export type deleted_external_account = Record<string, any>;

export type deleted_invoice = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_invoiceitem = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_payment_source = Record<string, any>;

export type deleted_person = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_plan = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_price = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_product = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_product_feature = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_radar.value_list = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_radar.value_list_item = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_subscription_item = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_tax_id = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_terminal.configuration = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_terminal.location = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_terminal.reader = {
  'deleted': boolean;
  'device_type': string;
  'id': string;
  'object': string;
  'serial_number': string;
};

export type deleted_test_helpers.test_clock = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type deleted_webhook_endpoint = {
  'deleted': boolean;
  'id': string;
  'object': string;
};

export type destination_details_unimplemented = Record<string, any>;

export type discount = {
  'checkout_session'?: string;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'end'?: number;
  'id': string;
  'invoice'?: string;
  'invoice_item'?: string;
  'object': string;
  'promotion_code'?: Record<string, any>;
  'source': discount_source;
  'start': number;
  'subscription'?: string;
  'subscription_item'?: string;
};

export type discount_source = {
  'coupon'?: Record<string, any>;
  'type': string;
};

export type discounts_resource_discount_amount = {
  'amount': number;
  'discount': Record<string, any>;
};

export type discounts_resource_stackable_discount_with_discount_end = {
  'coupon'?: Record<string, any>;
  'discount'?: Record<string, any>;
  'promotion_code'?: Record<string, any>;
};

export type dispute = {
  'amount': number;
  'balance_transactions': balance_transaction[];
  'charge': Record<string, any>;
  'created': number;
  'currency': string;
  'enhanced_eligibility_types': string[];
  'evidence': dispute_evidence;
  'evidence_details': dispute_evidence_details;
  'id': string;
  'is_charge_refundable': boolean;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'payment_intent'?: Record<string, any>;
  'payment_method_details'?: dispute_payment_method_details;
  'reason': string;
  'status': string;
};

export type dispute_enhanced_eligibility = {
  'visa_compelling_evidence_3'?: dispute_enhanced_eligibility_visa_compelling_evidence3;
  'visa_compliance'?: dispute_enhanced_eligibility_visa_compliance;
};

export type dispute_enhanced_eligibility_visa_compelling_evidence3 = {
  'required_actions': string[];
  'status': string;
};

export type dispute_enhanced_eligibility_visa_compliance = {
  'status': string;
};

export type dispute_enhanced_evidence = {
  'visa_compelling_evidence_3'?: dispute_enhanced_evidence_visa_compelling_evidence3;
  'visa_compliance'?: dispute_enhanced_evidence_visa_compliance;
};

export type dispute_enhanced_evidence_visa_compelling_evidence3 = {
  'disputed_transaction'?: Record<string, any>;
  'prior_undisputed_transactions': dispute_visa_compelling_evidence3_prior_undisputed_transaction[];
};

export type dispute_enhanced_evidence_visa_compliance = {
  'fee_acknowledged': boolean;
};

export type dispute_evidence = {
  'access_activity_log'?: string;
  'billing_address'?: string;
  'cancellation_policy'?: Record<string, any>;
  'cancellation_policy_disclosure'?: string;
  'cancellation_rebuttal'?: string;
  'customer_communication'?: Record<string, any>;
  'customer_email_address'?: string;
  'customer_name'?: string;
  'customer_purchase_ip'?: string;
  'customer_signature'?: Record<string, any>;
  'duplicate_charge_documentation'?: Record<string, any>;
  'duplicate_charge_explanation'?: string;
  'duplicate_charge_id'?: string;
  'enhanced_evidence': dispute_enhanced_evidence;
  'product_description'?: string;
  'receipt'?: Record<string, any>;
  'refund_policy'?: Record<string, any>;
  'refund_policy_disclosure'?: string;
  'refund_refusal_explanation'?: string;
  'service_date'?: string;
  'service_documentation'?: Record<string, any>;
  'shipping_address'?: string;
  'shipping_carrier'?: string;
  'shipping_date'?: string;
  'shipping_documentation'?: Record<string, any>;
  'shipping_tracking_number'?: string;
  'uncategorized_file'?: Record<string, any>;
  'uncategorized_text'?: string;
};

export type dispute_evidence_details = {
  'due_by'?: number;
  'enhanced_eligibility': dispute_enhanced_eligibility;
  'has_evidence': boolean;
  'past_due': boolean;
  'submission_count': number;
};

export type dispute_payment_method_details = {
  'amazon_pay'?: dispute_payment_method_details_amazon_pay;
  'card'?: dispute_payment_method_details_card;
  'klarna'?: dispute_payment_method_details_klarna;
  'paypal'?: dispute_payment_method_details_paypal;
  'type': string;
};

export type dispute_payment_method_details_amazon_pay = {
  'dispute_type'?: string;
};

export type dispute_payment_method_details_card = {
  'brand': string;
  'case_type': string;
  'network_reason_code'?: string;
};

export type dispute_payment_method_details_klarna = {
  'chargeback_loss_reason_code'?: string;
  'reason_code'?: string;
};

export type dispute_payment_method_details_paypal = {
  'case_id'?: string;
  'reason_code'?: string;
};

export type dispute_transaction_shipping_address = {
  'city'?: string;
  'country'?: string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
};

export type dispute_visa_compelling_evidence3_disputed_transaction = {
  'customer_account_id'?: string;
  'customer_device_fingerprint'?: string;
  'customer_device_id'?: string;
  'customer_email_address'?: string;
  'customer_purchase_ip'?: string;
  'merchandise_or_services'?: string;
  'product_description'?: string;
  'shipping_address'?: Record<string, any>;
};

export type dispute_visa_compelling_evidence3_prior_undisputed_transaction = {
  'charge': string;
  'customer_account_id'?: string;
  'customer_device_fingerprint'?: string;
  'customer_device_id'?: string;
  'customer_email_address'?: string;
  'customer_purchase_ip'?: string;
  'product_description'?: string;
  'shipping_address'?: Record<string, any>;
};

export type email_sent = {
  'email_sent_at': number;
  'email_sent_to': string;
};

export type entitlements.active_entitlement = {
  'feature': Record<string, any>;
  'id': string;
  'livemode': boolean;
  'lookup_key': string;
  'object': string;
};

export type entitlements.feature = {
  'active': boolean;
  'id': string;
  'livemode': boolean;
  'lookup_key': string;
  'metadata': Record<string, any>;
  'name': string;
  'object': string;
};

export type ephemeral_key = {
  'created': number;
  'expires': number;
  'id': string;
  'livemode': boolean;
  'object': string;
  'secret'?: string;
};

export type error = {
  'error': api_errors;
};

export type event = {
  'account'?: string;
  'api_version'?: string;
  'context'?: string;
  'created': number;
  'data': notification_event_data;
  'id': string;
  'livemode': boolean;
  'object': string;
  'pending_webhooks': number;
  'request'?: Record<string, any>;
  'type': string;
};

export type exchange_rate = {
  'id': string;
  'object': string;
  'rates': Record<string, any>;
};

export type external_account = Record<string, any>;

export type external_account_requirements = {
  'currently_due'?: string[];
  'errors'?: account_requirements_error[];
  'past_due'?: string[];
  'pending_verification'?: string[];
};

export type fee = {
  'amount': number;
  'application'?: string;
  'currency': string;
  'description'?: string;
  'type': string;
};

export type fee_refund = {
  'amount': number;
  'balance_transaction'?: Record<string, any>;
  'created': number;
  'currency': string;
  'fee': Record<string, any>;
  'id': string;
  'metadata'?: Record<string, any>;
  'object': string;
};

export type file = {
  'created': number;
  'expires_at'?: number;
  'filename'?: string;
  'id': string;
  'links'?: {
    'data': file_link[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'object': string;
  'purpose': string;
  'size': number;
  'title'?: string;
  'type'?: string;
  'url'?: string;
};

export type file_link = {
  'created': number;
  'expired': boolean;
  'expires_at'?: number;
  'file': Record<string, any>;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'url'?: string;
};

export type financial_connections.account = {
  'account_holder'?: Record<string, any>;
  'account_numbers'?: bank_connections_resource_account_number_details[];
  'balance'?: Record<string, any>;
  'balance_refresh'?: Record<string, any>;
  'category': string;
  'created': number;
  'display_name'?: string;
  'id': string;
  'institution_name': string;
  'last4'?: string;
  'livemode': boolean;
  'object': string;
  'ownership'?: Record<string, any>;
  'ownership_refresh'?: Record<string, any>;
  'permissions'?: string[];
  'status': string;
  'subcategory': string;
  'subscriptions'?: string[];
  'supported_payment_method_types': string[];
  'transaction_refresh'?: Record<string, any>;
};

export type financial_connections.account_owner = {
  'email'?: string;
  'id': string;
  'name': string;
  'object': string;
  'ownership': string;
  'phone'?: string;
  'raw_address'?: string;
  'refreshed_at'?: number;
};

export type financial_connections.account_ownership = {
  'created': number;
  'id': string;
  'object': string;
  'owners': {
    'data': financial_connections.account_owner[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
};

export type financial_connections.session = {
  'account_holder'?: Record<string, any>;
  'accounts': {
    'data': financial_connections.account[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'client_secret'?: string;
  'filters'?: bank_connections_resource_link_account_session_filters;
  'id': string;
  'livemode': boolean;
  'object': string;
  'permissions': string[];
  'prefetch'?: string[];
  'return_url'?: string;
};

export type financial_connections.transaction = {
  'account': string;
  'amount': number;
  'currency': string;
  'description': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status': string;
  'status_transitions': bank_connections_resource_transaction_resource_status_transitions;
  'transacted_at': number;
  'transaction_refresh': string;
  'updated': number;
};

export type financial_reporting_finance_report_run_run_parameters = {
  'columns'?: string[];
  'connected_account'?: string;
  'currency'?: string;
  'interval_end'?: number;
  'interval_start'?: number;
  'payout'?: string;
  'reporting_category'?: string;
  'timezone'?: string;
};

export type forwarded_request_context = {
  'destination_duration': number;
  'destination_ip_address': string;
};

export type forwarded_request_details = {
  'body': string;
  'headers': forwarded_request_header[];
  'http_method': string;
};

export type forwarded_request_header = {
  'name': string;
  'value': string;
};

export type forwarded_response_details = {
  'body': string;
  'headers': forwarded_request_header[];
  'status': number;
};

export type forwarding.request = {
  'created': number;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'payment_method': string;
  'replacements': string[];
  'request_context'?: Record<string, any>;
  'request_details'?: Record<string, any>;
  'response_details'?: Record<string, any>;
  'url'?: string;
};

export type funding_instructions = {
  'bank_transfer': funding_instructions_bank_transfer;
  'currency': string;
  'funding_type': string;
  'livemode': boolean;
  'object': string;
};

export type funding_instructions_bank_transfer = {
  'country': string;
  'financial_addresses': funding_instructions_bank_transfer_financial_address[];
  'type': string;
};

export type funding_instructions_bank_transfer_aba_record = {
  'account_holder_address': address;
  'account_holder_name': string;
  'account_number': string;
  'account_type': string;
  'bank_address': address;
  'bank_name': string;
  'routing_number': string;
};

export type funding_instructions_bank_transfer_financial_address = {
  'aba'?: funding_instructions_bank_transfer_aba_record;
  'iban'?: funding_instructions_bank_transfer_iban_record;
  'sort_code'?: funding_instructions_bank_transfer_sort_code_record;
  'spei'?: funding_instructions_bank_transfer_spei_record;
  'supported_networks'?: string[];
  'swift'?: funding_instructions_bank_transfer_swift_record;
  'type': string;
  'zengin'?: funding_instructions_bank_transfer_zengin_record;
};

export type funding_instructions_bank_transfer_iban_record = {
  'account_holder_address': address;
  'account_holder_name': string;
  'bank_address': address;
  'bic': string;
  'country': string;
  'iban': string;
};

export type funding_instructions_bank_transfer_sort_code_record = {
  'account_holder_address': address;
  'account_holder_name': string;
  'account_number': string;
  'bank_address': address;
  'sort_code': string;
};

export type funding_instructions_bank_transfer_spei_record = {
  'account_holder_address': address;
  'account_holder_name': string;
  'bank_address': address;
  'bank_code': string;
  'bank_name': string;
  'clabe': string;
};

export type funding_instructions_bank_transfer_swift_record = {
  'account_holder_address': address;
  'account_holder_name': string;
  'account_number': string;
  'account_type': string;
  'bank_address': address;
  'bank_name': string;
  'swift_code': string;
};

export type funding_instructions_bank_transfer_zengin_record = {
  'account_holder_address': address;
  'account_holder_name'?: string;
  'account_number'?: string;
  'account_type'?: string;
  'bank_address': address;
  'bank_code'?: string;
  'bank_name'?: string;
  'branch_code'?: string;
  'branch_name'?: string;
};

export type gelato_data_document_report_date_of_birth = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type gelato_data_document_report_expiration_date = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type gelato_data_document_report_issued_date = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type gelato_data_id_number_report_date = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type gelato_data_verified_outputs_date = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type gelato_document_report = {
  'address'?: Record<string, any>;
  'dob'?: Record<string, any>;
  'error'?: Record<string, any>;
  'expiration_date'?: Record<string, any>;
  'files'?: string[];
  'first_name'?: string;
  'issued_date'?: Record<string, any>;
  'issuing_country'?: string;
  'last_name'?: string;
  'number'?: string;
  'sex'?: string;
  'status': string;
  'type'?: string;
  'unparsed_place_of_birth'?: string;
  'unparsed_sex'?: string;
};

export type gelato_document_report_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_email_report = {
  'email'?: string;
  'error'?: Record<string, any>;
  'status': string;
};

export type gelato_email_report_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_id_number_report = {
  'dob'?: Record<string, any>;
  'error'?: Record<string, any>;
  'first_name'?: string;
  'id_number'?: string;
  'id_number_type'?: string;
  'last_name'?: string;
  'status': string;
};

export type gelato_id_number_report_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_phone_report = {
  'error'?: Record<string, any>;
  'phone'?: string;
  'status': string;
};

export type gelato_phone_report_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_provided_details = {
  'email'?: string;
  'phone'?: string;
};

export type gelato_related_person = {
  'account': string;
  'person': string;
};

export type gelato_report_document_options = {
  'allowed_types'?: string[];
  'require_id_number'?: boolean;
  'require_live_capture'?: boolean;
  'require_matching_selfie'?: boolean;
};

export type gelato_report_id_number_options = Record<string, any>;

export type gelato_selfie_report = {
  'document'?: string;
  'error'?: Record<string, any>;
  'selfie'?: string;
  'status': string;
};

export type gelato_selfie_report_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_session_document_options = {
  'allowed_types'?: string[];
  'require_id_number'?: boolean;
  'require_live_capture'?: boolean;
  'require_matching_selfie'?: boolean;
};

export type gelato_session_email_options = {
  'require_verification'?: boolean;
};

export type gelato_session_id_number_options = Record<string, any>;

export type gelato_session_last_error = {
  'code'?: string;
  'reason'?: string;
};

export type gelato_session_matching_options = {
  'dob'?: string;
  'name'?: string;
};

export type gelato_session_phone_options = {
  'require_verification'?: boolean;
};

export type gelato_verification_report_options = {
  'document'?: gelato_report_document_options;
  'id_number'?: gelato_report_id_number_options;
};

export type gelato_verification_session_options = {
  'document'?: gelato_session_document_options;
  'email'?: gelato_session_email_options;
  'id_number'?: gelato_session_id_number_options;
  'matching'?: gelato_session_matching_options;
  'phone'?: gelato_session_phone_options;
};

export type gelato_verified_outputs = {
  'address'?: Record<string, any>;
  'dob'?: Record<string, any>;
  'email'?: string;
  'first_name'?: string;
  'id_number'?: string;
  'id_number_type'?: string;
  'last_name'?: string;
  'phone'?: string;
  'sex'?: string;
  'unparsed_place_of_birth'?: string;
  'unparsed_sex'?: string;
};

export type identity.verification_report = {
  'client_reference_id'?: string;
  'created': number;
  'document'?: gelato_document_report;
  'email'?: gelato_email_report;
  'id': string;
  'id_number'?: gelato_id_number_report;
  'livemode': boolean;
  'object': string;
  'options'?: gelato_verification_report_options;
  'phone'?: gelato_phone_report;
  'selfie'?: gelato_selfie_report;
  'type': string;
  'verification_flow'?: string;
  'verification_session'?: string;
};

export type identity.verification_session = {
  'client_reference_id'?: string;
  'client_secret'?: string;
  'created': number;
  'id': string;
  'last_error'?: Record<string, any>;
  'last_verification_report'?: Record<string, any>;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'options'?: Record<string, any>;
  'provided_details'?: Record<string, any>;
  'redaction'?: Record<string, any>;
  'related_customer'?: string;
  'related_customer_account'?: string;
  'related_person'?: gelato_related_person;
  'status': string;
  'type': string;
  'url'?: string;
  'verification_flow'?: string;
  'verified_outputs'?: Record<string, any>;
};

export type inbound_transfers = {
  'billing_details': treasury_shared_resource_billing_details;
  'type': string;
  'us_bank_account'?: inbound_transfers_payment_method_details_us_bank_account;
};

export type inbound_transfers_payment_method_details_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: Record<string, any>;
  'network': string;
  'routing_number'?: string;
};

export type insights_resources_payment_evaluation_address = {
  'city'?: string;
  'country'?: string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
};

export type insights_resources_payment_evaluation_billing_details = {
  'address': insights_resources_payment_evaluation_address;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
};

export type insights_resources_payment_evaluation_client_device_metadata = {
  'radar_session': string;
};

export type insights_resources_payment_evaluation_customer_details = {
  'customer'?: string;
  'customer_account'?: string;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
};

export type insights_resources_payment_evaluation_dispute_opened = {
  'amount': number;
  'currency': string;
  'reason': string;
};

export type insights_resources_payment_evaluation_early_fraud_warning_received = {
  'fraud_type': string;
};

export type insights_resources_payment_evaluation_event = {
  'dispute_opened'?: insights_resources_payment_evaluation_dispute_opened;
  'early_fraud_warning_received'?: insights_resources_payment_evaluation_early_fraud_warning_received;
  'occurred_at': number;
  'refunded'?: insights_resources_payment_evaluation_refunded;
  'type': string;
  'user_intervention_raised'?: insights_resources_payment_evaluation_user_intervention_raised;
  'user_intervention_resolved'?: insights_resources_payment_evaluation_user_intervention_resolved;
};

export type insights_resources_payment_evaluation_merchant_blocked = {
  'reason': string;
};

export type insights_resources_payment_evaluation_money_movement_card = {
  'customer_presence'?: string;
  'payment_type'?: string;
};

export type insights_resources_payment_evaluation_money_movement_details = {
  'card'?: Record<string, any>;
  'money_movement_type': string;
};

export type insights_resources_payment_evaluation_outcome = {
  'merchant_blocked'?: insights_resources_payment_evaluation_merchant_blocked;
  'payment_intent_id'?: string;
  'rejected'?: insights_resources_payment_evaluation_rejected;
  'succeeded'?: insights_resources_payment_evaluation_succeeded;
  'type': string;
};

export type insights_resources_payment_evaluation_payment_details = {
  'amount': number;
  'currency': string;
  'description'?: string;
  'money_movement_details'?: Record<string, any>;
  'payment_method_details'?: Record<string, any>;
  'shipping_details'?: Record<string, any>;
  'statement_descriptor'?: string;
};

export type insights_resources_payment_evaluation_payment_method_details = {
  'billing_details'?: Record<string, any>;
  'payment_method': Record<string, any>;
};

export type insights_resources_payment_evaluation_refunded = {
  'amount': number;
  'currency': string;
  'reason': string;
};

export type insights_resources_payment_evaluation_rejected = {
  'card'?: insights_resources_payment_evaluation_rejected_card;
};

export type insights_resources_payment_evaluation_rejected_card = {
  'address_line1_check': string;
  'address_postal_code_check': string;
  'cvc_check': string;
  'reason': string;
};

export type insights_resources_payment_evaluation_shipping = {
  'address': insights_resources_payment_evaluation_address;
  'name'?: string;
  'phone'?: string;
};

export type insights_resources_payment_evaluation_signal_v2 = {
  'evaluated_at': number;
  'risk_level': string;
  'score': number;
};

export type insights_resources_payment_evaluation_signals = {
  'fraudulent_payment': insights_resources_payment_evaluation_signal_v2;
};

export type insights_resources_payment_evaluation_succeeded = {
  'card'?: insights_resources_payment_evaluation_succeeded_card;
};

export type insights_resources_payment_evaluation_succeeded_card = {
  'address_line1_check': string;
  'address_postal_code_check': string;
  'cvc_check': string;
};

export type insights_resources_payment_evaluation_user_intervention_raised = {
  'custom'?: insights_resources_payment_evaluation_user_intervention_raised_custom;
  'key': string;
  'type': string;
};

export type insights_resources_payment_evaluation_user_intervention_raised_custom = {
  'type': string;
};

export type insights_resources_payment_evaluation_user_intervention_resolved = {
  'key': string;
  'outcome'?: string;
};

export type internal_card = {
  'brand'?: string;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'last4'?: string;
};

export type invoice = {
  'account_country'?: string;
  'account_name'?: string;
  'account_tax_ids'?: Record<string, any>[];
  'amount_due': number;
  'amount_overpaid': number;
  'amount_paid': number;
  'amount_paid_off_stripe': number;
  'amount_remaining': number;
  'amount_shipping': number;
  'application'?: Record<string, any>;
  'attempt_count': number;
  'attempted': boolean;
  'auto_advance': boolean;
  'automatic_tax': automatic_tax;
  'automatically_finalizes_at'?: number;
  'billing_reason'?: string;
  'collection_method': string;
  'confirmation_secret'?: Record<string, any>;
  'created': number;
  'currency': string;
  'custom_fields'?: invoice_setting_custom_field[];
  'customer': Record<string, any>;
  'customer_account'?: string;
  'customer_address'?: Record<string, any>;
  'customer_email'?: string;
  'customer_name'?: string;
  'customer_phone'?: string;
  'customer_shipping'?: Record<string, any>;
  'customer_tax_exempt'?: string;
  'customer_tax_ids'?: invoices_resource_invoice_tax_id[];
  'default_payment_method'?: Record<string, any>;
  'default_source'?: Record<string, any>;
  'default_tax_rates': tax_rate[];
  'description'?: string;
  'discounts': Record<string, any>[];
  'due_date'?: number;
  'effective_at'?: number;
  'ending_balance'?: number;
  'footer'?: string;
  'from_invoice'?: Record<string, any>;
  'hosted_invoice_url'?: string;
  'id': string;
  'invoice_pdf'?: string;
  'issuer': connect_account_reference;
  'last_finalization_error'?: Record<string, any>;
  'latest_revision'?: Record<string, any>;
  'lines': {
    'data': line_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'next_payment_attempt'?: number;
  'number'?: string;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'parent'?: Record<string, any>;
  'payment_settings': invoices_payment_settings;
  'payments'?: {
    'data': invoice_payment[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'period_end': number;
  'period_start': number;
  'post_payment_credit_notes_amount': number;
  'pre_payment_credit_notes_amount': number;
  'receipt_number'?: string;
  'rendering'?: Record<string, any>;
  'shipping_cost'?: Record<string, any>;
  'shipping_details'?: Record<string, any>;
  'starting_balance': number;
  'statement_descriptor'?: string;
  'status'?: string;
  'status_transitions': invoices_resource_status_transitions;
  'subtotal': number;
  'subtotal_excluding_tax'?: number;
  'test_clock'?: Record<string, any>;
  'threshold_reason'?: invoice_threshold_reason;
  'total': number;
  'total_discount_amounts'?: discounts_resource_discount_amount[];
  'total_excluding_tax'?: number;
  'total_pretax_credit_amounts'?: invoices_resource_pretax_credit_amount[];
  'total_taxes'?: billing_bill_resource_invoicing_taxes_tax[];
  'webhooks_delivered_at'?: number;
};

export type invoice_installments_card = {
  'enabled'?: boolean;
};

export type invoice_item_proration_credited_items = {
  'invoice_item'?: string;
  'invoice_line_item_details'?: credited_items_invoice_line_items;
  'type': string;
};

export type invoice_item_threshold_reason = {
  'line_item_ids': string[];
  'usage_gte': number;
};

export type invoice_line_item_period = {
  'end': number;
  'start': number;
};

export type invoice_mandate_options_card = {
  'amount'?: number;
  'amount_type'?: string;
  'description'?: string;
};

export type invoice_mandate_options_payto = {
  'amount'?: number;
  'amount_type'?: string;
  'purpose'?: string;
};

export type invoice_payment = {
  'amount_paid'?: number;
  'amount_requested': number;
  'created': number;
  'currency': string;
  'id': string;
  'invoice': Record<string, any>;
  'is_default': boolean;
  'livemode': boolean;
  'object': string;
  'payment': invoices_payments_invoice_payment_associated_payment;
  'status': string;
  'status_transitions': invoices_payments_invoice_payment_status_transitions;
};

export type invoice_payment_method_options_acss_debit = {
  'mandate_options'?: invoice_payment_method_options_acss_debit_mandate_options;
  'verification_method'?: string;
};

export type invoice_payment_method_options_acss_debit_mandate_options = {
  'transaction_type'?: string;
};

export type invoice_payment_method_options_bancontact = {
  'preferred_language': string;
};

export type invoice_payment_method_options_card = {
  'installments'?: invoice_installments_card;
  'request_three_d_secure'?: string;
};

export type invoice_payment_method_options_customer_balance = {
  'bank_transfer'?: invoice_payment_method_options_customer_balance_bank_transfer;
  'funding_type'?: string;
};

export type invoice_payment_method_options_customer_balance_bank_transfer = {
  'eu_bank_transfer'?: invoice_payment_method_options_customer_balance_bank_transfer_eu_bank_transfer;
  'type'?: string;
};

export type invoice_payment_method_options_customer_balance_bank_transfer_eu_bank_transfer = {
  'country': string;
};

export type invoice_payment_method_options_konbini = Record<string, any>;

export type invoice_payment_method_options_mandate_options_upi = {
  'amount'?: number;
  'amount_type'?: string;
  'description'?: string;
  'end_date'?: number;
};

export type invoice_payment_method_options_payto = {
  'mandate_options'?: invoice_mandate_options_payto;
};

export type invoice_payment_method_options_pix = {
  'amount_includes_iof'?: string;
  'expires_after_seconds'?: number;
};

export type invoice_payment_method_options_sepa_debit = Record<string, any>;

export type invoice_payment_method_options_upi = {
  'mandate_options'?: invoice_payment_method_options_mandate_options_upi;
};

export type invoice_payment_method_options_us_bank_account = {
  'financial_connections'?: invoice_payment_method_options_us_bank_account_linked_account_options;
  'verification_method'?: string;
};

export type invoice_payment_method_options_us_bank_account_linked_account_options = {
  'filters'?: invoice_payment_method_options_us_bank_account_linked_account_options_filters;
  'permissions'?: string[];
  'prefetch'?: string[];
};

export type invoice_payment_method_options_us_bank_account_linked_account_options_filters = {
  'account_subcategories'?: string[];
};

export type invoice_rendering_pdf = {
  'page_size'?: string;
};

export type invoice_rendering_template = {
  'created': number;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'nickname'?: string;
  'object': string;
  'status': string;
  'version': number;
};

export type invoice_setting_checkout_rendering_options = {
  'amount_tax_display'?: string;
  'template'?: string;
};

export type invoice_setting_custom_field = {
  'name': string;
  'value': string;
};

export type invoice_setting_customer_rendering_options = {
  'amount_tax_display'?: string;
  'template'?: string;
};

export type invoice_setting_customer_setting = {
  'custom_fields'?: invoice_setting_custom_field[];
  'default_payment_method'?: Record<string, any>;
  'footer'?: string;
  'rendering_options'?: Record<string, any>;
};

export type invoice_setting_quote_setting = {
  'days_until_due'?: number;
  'issuer': connect_account_reference;
};

export type invoice_setting_subscription_schedule_phase_setting = {
  'account_tax_ids'?: Record<string, any>[];
  'days_until_due'?: number;
  'issuer'?: Record<string, any>;
};

export type invoice_setting_subscription_schedule_setting = {
  'account_tax_ids'?: Record<string, any>[];
  'days_until_due'?: number;
  'issuer': connect_account_reference;
};

export type invoice_threshold_reason = {
  'amount_gte'?: number;
  'item_reasons': invoice_item_threshold_reason[];
};

export type invoiceitem = {
  'amount': number;
  'currency': string;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'date': number;
  'description'?: string;
  'discountable': boolean;
  'discounts'?: Record<string, any>[];
  'id': string;
  'invoice'?: Record<string, any>;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'net_amount'?: number;
  'object': string;
  'parent'?: Record<string, any>;
  'period': invoice_line_item_period;
  'pricing'?: Record<string, any>;
  'proration': boolean;
  'proration_details'?: proration_details;
  'quantity': number;
  'quantity_decimal': string;
  'tax_rates'?: tax_rate[];
  'test_clock'?: Record<string, any>;
};

export type invoices_payment_method_options = {
  'acss_debit'?: Record<string, any>;
  'bancontact'?: Record<string, any>;
  'card'?: Record<string, any>;
  'customer_balance'?: Record<string, any>;
  'konbini'?: Record<string, any>;
  'payto'?: Record<string, any>;
  'pix'?: Record<string, any>;
  'sepa_debit'?: Record<string, any>;
  'upi'?: Record<string, any>;
  'us_bank_account'?: Record<string, any>;
};

export type invoices_payment_settings = {
  'default_mandate'?: string;
  'payment_method_options'?: Record<string, any>;
  'payment_method_types'?: string[];
};

export type invoices_payments_invoice_payment_associated_payment = {
  'charge'?: Record<string, any>;
  'payment_intent'?: Record<string, any>;
  'payment_record'?: Record<string, any>;
  'type': string;
};

export type invoices_payments_invoice_payment_status_transitions = {
  'canceled_at'?: number;
  'paid_at'?: number;
};

export type invoices_resource_confirmation_secret = {
  'client_secret': string;
  'type': string;
};

export type invoices_resource_from_invoice = {
  'action': string;
  'invoice': Record<string, any>;
};

export type invoices_resource_invoice_rendering = {
  'amount_tax_display'?: string;
  'pdf'?: Record<string, any>;
  'template'?: string;
  'template_version'?: number;
};

export type invoices_resource_invoice_tax_id = {
  'type': string;
  'value'?: string;
};

export type invoices_resource_pretax_credit_amount = {
  'amount': number;
  'credit_balance_transaction'?: Record<string, any>;
  'discount'?: Record<string, any>;
  'type': string;
};

export type invoices_resource_shipping_cost = {
  'amount_subtotal': number;
  'amount_tax': number;
  'amount_total': number;
  'shipping_rate'?: Record<string, any>;
  'taxes'?: line_items_tax_amount[];
};

export type invoices_resource_status_transitions = {
  'finalized_at'?: number;
  'marked_uncollectible_at'?: number;
  'paid_at'?: number;
  'voided_at'?: number;
};

export type issuing.authorization = {
  'amount': number;
  'amount_details'?: Record<string, any>;
  'approved': boolean;
  'authorization_method': string;
  'balance_transactions': balance_transaction[];
  'card': issuing.card;
  'card_presence'?: string;
  'cardholder'?: Record<string, any>;
  'created': number;
  'currency': string;
  'fleet'?: Record<string, any>;
  'fraud_challenges'?: issuing_authorization_fraud_challenge[];
  'fuel'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'merchant_amount': number;
  'merchant_currency': string;
  'merchant_data': issuing_authorization_merchant_data;
  'metadata': Record<string, any>;
  'network_data'?: Record<string, any>;
  'object': string;
  'pending_request'?: Record<string, any>;
  'request_history': issuing_authorization_request[];
  'status': string;
  'token'?: Record<string, any>;
  'transactions': issuing.transaction[];
  'treasury'?: Record<string, any>;
  'verification_data': issuing_authorization_verification_data;
  'verified_by_fraud_challenge'?: boolean;
  'wallet'?: string;
};

export type issuing.card = {
  'brand': string;
  'cancellation_reason'?: string;
  'cardholder': issuing.cardholder;
  'created': number;
  'currency': string;
  'cvc'?: string;
  'exp_month': number;
  'exp_year': number;
  'financial_account'?: string;
  'id': string;
  'last4': string;
  'latest_fraud_warning'?: Record<string, any>;
  'lifecycle_controls'?: Record<string, any>;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'number'?: string;
  'object': string;
  'personalization_design'?: Record<string, any>;
  'replaced_by'?: Record<string, any>;
  'replacement_for'?: Record<string, any>;
  'replacement_reason'?: string;
  'second_line'?: string;
  'shipping'?: Record<string, any>;
  'spending_controls': issuing_card_authorization_controls;
  'status': string;
  'type': string;
  'wallets'?: Record<string, any>;
};

export type issuing.cardholder = {
  'billing': issuing_cardholder_address;
  'company'?: Record<string, any>;
  'created': number;
  'email'?: string;
  'id': string;
  'individual'?: Record<string, any>;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'name': string;
  'object': string;
  'phone_number'?: string;
  'preferred_locales'?: string[];
  'requirements': issuing_cardholder_requirements;
  'spending_controls'?: Record<string, any>;
  'status': string;
  'type': string;
};

export type issuing.dispute = {
  'amount': number;
  'balance_transactions'?: balance_transaction[];
  'created': number;
  'currency': string;
  'evidence': issuing_dispute_evidence;
  'id': string;
  'livemode': boolean;
  'loss_reason'?: string;
  'metadata': Record<string, any>;
  'object': string;
  'status': string;
  'transaction': Record<string, any>;
  'treasury'?: Record<string, any>;
};

export type issuing.personalization_design = {
  'card_logo'?: Record<string, any>;
  'carrier_text'?: Record<string, any>;
  'created': number;
  'id': string;
  'livemode': boolean;
  'lookup_key'?: string;
  'metadata': Record<string, any>;
  'name'?: string;
  'object': string;
  'physical_bundle': Record<string, any>;
  'preferences': issuing_personalization_design_preferences;
  'rejection_reasons': issuing_personalization_design_rejection_reasons;
  'status': string;
};

export type issuing.physical_bundle = {
  'features': issuing_physical_bundle_features;
  'id': string;
  'livemode': boolean;
  'name': string;
  'object': string;
  'status': string;
  'type': string;
};

export type issuing.settlement = {
  'bin': string;
  'clearing_date': number;
  'created': number;
  'currency': string;
  'id': string;
  'interchange_fees_amount': number;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'net_total_amount': number;
  'network': string;
  'network_fees_amount': number;
  'network_settlement_identifier': string;
  'object': string;
  'settlement_service': string;
  'status': string;
  'transaction_amount': number;
  'transaction_count': number;
};

export type issuing.token = {
  'card': Record<string, any>;
  'created': number;
  'device_fingerprint'?: string;
  'id': string;
  'last4'?: string;
  'livemode': boolean;
  'network': string;
  'network_data'?: issuing_network_token_network_data;
  'network_updated_at': number;
  'object': string;
  'status': string;
  'wallet_provider'?: string;
};

export type issuing.transaction = {
  'amount': number;
  'amount_details'?: Record<string, any>;
  'authorization'?: Record<string, any>;
  'balance_transaction'?: Record<string, any>;
  'card': Record<string, any>;
  'cardholder'?: Record<string, any>;
  'created': number;
  'currency': string;
  'dispute'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'merchant_amount': number;
  'merchant_currency': string;
  'merchant_data': issuing_authorization_merchant_data;
  'metadata': Record<string, any>;
  'network_data'?: Record<string, any>;
  'object': string;
  'purchase_details'?: Record<string, any>;
  'token'?: Record<string, any>;
  'treasury'?: Record<string, any>;
  'type': string;
  'wallet'?: string;
};

export type issuing_authorization_amount_details = {
  'atm_fee'?: number;
  'cashback_amount'?: number;
};

export type issuing_authorization_authentication_exemption = {
  'claimed_by': string;
  'type': string;
};

export type issuing_authorization_fleet_cardholder_prompt_data = {
  'alphanumeric_id'?: string;
  'driver_id'?: string;
  'odometer'?: number;
  'unspecified_id'?: string;
  'user_id'?: string;
  'vehicle_number'?: string;
};

export type issuing_authorization_fleet_data = {
  'cardholder_prompt_data'?: Record<string, any>;
  'purchase_type'?: string;
  'reported_breakdown'?: Record<string, any>;
  'service_type'?: string;
};

export type issuing_authorization_fleet_fuel_price_data = {
  'gross_amount_decimal'?: string;
};

export type issuing_authorization_fleet_non_fuel_price_data = {
  'gross_amount_decimal'?: string;
};

export type issuing_authorization_fleet_reported_breakdown = {
  'fuel'?: Record<string, any>;
  'non_fuel'?: Record<string, any>;
  'tax'?: Record<string, any>;
};

export type issuing_authorization_fleet_tax_data = {
  'local_amount_decimal'?: string;
  'national_amount_decimal'?: string;
};

export type issuing_authorization_fraud_challenge = {
  'channel': string;
  'status': string;
  'undeliverable_reason'?: string;
};

export type issuing_authorization_fuel_data = {
  'industry_product_code'?: string;
  'quantity_decimal'?: string;
  'type'?: string;
  'unit'?: string;
  'unit_cost_decimal'?: string;
};

export type issuing_authorization_merchant_data = {
  'category': string;
  'category_code': string;
  'city'?: string;
  'country'?: string;
  'name'?: string;
  'network_id': string;
  'postal_code'?: string;
  'state'?: string;
  'tax_id'?: string;
  'terminal_id'?: string;
  'url'?: string;
};

export type issuing_authorization_network_data = {
  'acquiring_institution_id'?: string;
  'system_trace_audit_number'?: string;
  'transaction_id'?: string;
};

export type issuing_authorization_pending_request = {
  'amount': number;
  'amount_details'?: Record<string, any>;
  'currency': string;
  'is_amount_controllable': boolean;
  'merchant_amount': number;
  'merchant_currency': string;
  'network_risk_score'?: number;
};

export type issuing_authorization_request = {
  'amount': number;
  'amount_details'?: Record<string, any>;
  'approved': boolean;
  'authorization_code'?: string;
  'created': number;
  'currency': string;
  'merchant_amount': number;
  'merchant_currency': string;
  'network_risk_score'?: number;
  'reason': string;
  'reason_message'?: string;
  'requested_at'?: number;
};

export type issuing_authorization_three_d_secure = {
  'result': string;
};

export type issuing_authorization_treasury = {
  'received_credits': string[];
  'received_debits': string[];
  'transaction'?: string;
};

export type issuing_authorization_verification_data = {
  'address_line1_check': string;
  'address_postal_code_check': string;
  'authentication_exemption'?: Record<string, any>;
  'cvc_check': string;
  'expiry_check': string;
  'postal_code'?: string;
  'three_d_secure'?: Record<string, any>;
};

export type issuing_card_apple_pay = {
  'eligible': boolean;
  'ineligible_reason'?: string;
};

export type issuing_card_authorization_controls = {
  'allowed_card_presences'?: string[];
  'allowed_categories'?: string[];
  'allowed_merchant_countries'?: string[];
  'blocked_card_presences'?: string[];
  'blocked_categories'?: string[];
  'blocked_merchant_countries'?: string[];
  'spending_limits'?: issuing_card_spending_limit[];
  'spending_limits_currency'?: string;
};

export type issuing_card_fraud_warning = {
  'started_at'?: number;
  'type'?: string;
};

export type issuing_card_google_pay = {
  'eligible': boolean;
  'ineligible_reason'?: string;
};

export type issuing_card_lifecycle_conditions = {
  'payment_count': number;
};

export type issuing_card_lifecycle_controls = {
  'cancel_after': issuing_card_lifecycle_conditions;
};

export type issuing_card_shipping = {
  'address': address;
  'address_validation'?: Record<string, any>;
  'carrier'?: string;
  'customs'?: Record<string, any>;
  'eta'?: number;
  'name': string;
  'phone_number'?: string;
  'require_signature'?: boolean;
  'service': string;
  'status'?: string;
  'tracking_number'?: string;
  'tracking_url'?: string;
  'type': string;
};

export type issuing_card_shipping_address_validation = {
  'mode': string;
  'normalized_address'?: Record<string, any>;
  'result'?: string;
};

export type issuing_card_shipping_customs = {
  'eori_number'?: string;
};

export type issuing_card_spending_limit = {
  'amount': number;
  'categories'?: string[];
  'interval': string;
};

export type issuing_card_wallets = {
  'apple_pay': issuing_card_apple_pay;
  'google_pay': issuing_card_google_pay;
  'primary_account_identifier'?: string;
};

export type issuing_cardholder_address = {
  'address': address;
};

export type issuing_cardholder_authorization_controls = {
  'allowed_card_presences'?: string[];
  'allowed_categories'?: string[];
  'allowed_merchant_countries'?: string[];
  'blocked_card_presences'?: string[];
  'blocked_categories'?: string[];
  'blocked_merchant_countries'?: string[];
  'spending_limits'?: issuing_cardholder_spending_limit[];
  'spending_limits_currency'?: string;
};

export type issuing_cardholder_card_issuing = {
  'user_terms_acceptance'?: Record<string, any>;
};

export type issuing_cardholder_company = {
  'tax_id_provided': boolean;
};

export type issuing_cardholder_id_document = {
  'back'?: Record<string, any>;
  'front'?: Record<string, any>;
};

export type issuing_cardholder_individual = {
  'card_issuing'?: Record<string, any>;
  'dob'?: Record<string, any>;
  'first_name'?: string;
  'last_name'?: string;
  'verification'?: Record<string, any>;
};

export type issuing_cardholder_individual_dob = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type issuing_cardholder_requirements = {
  'disabled_reason'?: string;
  'past_due'?: string[];
};

export type issuing_cardholder_spending_limit = {
  'amount': number;
  'categories'?: string[];
  'interval': string;
};

export type issuing_cardholder_user_terms_acceptance = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type issuing_cardholder_verification = {
  'document'?: Record<string, any>;
};

export type issuing_dispute_canceled_evidence = {
  'additional_documentation'?: Record<string, any>;
  'canceled_at'?: number;
  'cancellation_policy_provided'?: boolean;
  'cancellation_reason'?: string;
  'expected_at'?: number;
  'explanation'?: string;
  'product_description'?: string;
  'product_type'?: string;
  'return_status'?: string;
  'returned_at'?: number;
};

export type issuing_dispute_duplicate_evidence = {
  'additional_documentation'?: Record<string, any>;
  'card_statement'?: Record<string, any>;
  'cash_receipt'?: Record<string, any>;
  'check_image'?: Record<string, any>;
  'explanation'?: string;
  'original_transaction'?: string;
};

export type issuing_dispute_evidence = {
  'canceled'?: issuing_dispute_canceled_evidence;
  'duplicate'?: issuing_dispute_duplicate_evidence;
  'fraudulent'?: issuing_dispute_fraudulent_evidence;
  'merchandise_not_as_described'?: issuing_dispute_merchandise_not_as_described_evidence;
  'no_valid_authorization'?: issuing_dispute_no_valid_authorization_evidence;
  'not_received'?: issuing_dispute_not_received_evidence;
  'other'?: issuing_dispute_other_evidence;
  'reason': string;
  'service_not_as_described'?: issuing_dispute_service_not_as_described_evidence;
};

export type issuing_dispute_fraudulent_evidence = {
  'additional_documentation'?: Record<string, any>;
  'explanation'?: string;
};

export type issuing_dispute_merchandise_not_as_described_evidence = {
  'additional_documentation'?: Record<string, any>;
  'explanation'?: string;
  'received_at'?: number;
  'return_description'?: string;
  'return_status'?: string;
  'returned_at'?: number;
};

export type issuing_dispute_no_valid_authorization_evidence = {
  'additional_documentation'?: Record<string, any>;
  'explanation'?: string;
};

export type issuing_dispute_not_received_evidence = {
  'additional_documentation'?: Record<string, any>;
  'expected_at'?: number;
  'explanation'?: string;
  'product_description'?: string;
  'product_type'?: string;
};

export type issuing_dispute_other_evidence = {
  'additional_documentation'?: Record<string, any>;
  'explanation'?: string;
  'product_description'?: string;
  'product_type'?: string;
};

export type issuing_dispute_service_not_as_described_evidence = {
  'additional_documentation'?: Record<string, any>;
  'canceled_at'?: number;
  'cancellation_reason'?: string;
  'explanation'?: string;
  'received_at'?: number;
};

export type issuing_dispute_treasury = {
  'debit_reversal'?: string;
  'received_debit': string;
};

export type issuing_network_token_address = {
  'line1': string;
  'postal_code': string;
};

export type issuing_network_token_device = {
  'device_fingerprint'?: string;
  'ip_address'?: string;
  'location'?: string;
  'name'?: string;
  'phone_number'?: string;
  'type'?: string;
};

export type issuing_network_token_mastercard = {
  'card_reference_id'?: string;
  'token_reference_id': string;
  'token_requestor_id': string;
  'token_requestor_name'?: string;
};

export type issuing_network_token_network_data = {
  'device'?: issuing_network_token_device;
  'mastercard'?: issuing_network_token_mastercard;
  'type': string;
  'visa'?: issuing_network_token_visa;
  'wallet_provider'?: issuing_network_token_wallet_provider;
};

export type issuing_network_token_visa = {
  'card_reference_id'?: string;
  'token_reference_id': string;
  'token_requestor_id': string;
  'token_risk_score'?: string;
};

export type issuing_network_token_wallet_provider = {
  'account_id'?: string;
  'account_trust_score'?: number;
  'card_number_source'?: string;
  'cardholder_address'?: issuing_network_token_address;
  'cardholder_name'?: string;
  'device_trust_score'?: number;
  'hashed_account_email_address'?: string;
  'reason_codes'?: string[];
  'suggested_decision'?: string;
  'suggested_decision_version'?: string;
};

export type issuing_personalization_design_carrier_text = {
  'footer_body'?: string;
  'footer_title'?: string;
  'header_body'?: string;
  'header_title'?: string;
};

export type issuing_personalization_design_preferences = {
  'is_default': boolean;
  'is_platform_default'?: boolean;
};

export type issuing_personalization_design_rejection_reasons = {
  'card_logo'?: string[];
  'carrier_text'?: string[];
};

export type issuing_physical_bundle_features = {
  'card_logo': string;
  'carrier_text': string;
  'second_line': string;
};

export type issuing_transaction_amount_details = {
  'atm_fee'?: number;
  'cashback_amount'?: number;
};

export type issuing_transaction_fleet_cardholder_prompt_data = {
  'driver_id'?: string;
  'odometer'?: number;
  'unspecified_id'?: string;
  'user_id'?: string;
  'vehicle_number'?: string;
};

export type issuing_transaction_fleet_data = {
  'cardholder_prompt_data'?: Record<string, any>;
  'purchase_type'?: string;
  'reported_breakdown'?: Record<string, any>;
  'service_type'?: string;
};

export type issuing_transaction_fleet_fuel_price_data = {
  'gross_amount_decimal'?: string;
};

export type issuing_transaction_fleet_non_fuel_price_data = {
  'gross_amount_decimal'?: string;
};

export type issuing_transaction_fleet_reported_breakdown = {
  'fuel'?: Record<string, any>;
  'non_fuel'?: Record<string, any>;
  'tax'?: Record<string, any>;
};

export type issuing_transaction_fleet_tax_data = {
  'local_amount_decimal'?: string;
  'national_amount_decimal'?: string;
};

export type issuing_transaction_flight_data = {
  'departure_at'?: number;
  'passenger_name'?: string;
  'refundable'?: boolean;
  'segments'?: issuing_transaction_flight_data_leg[];
  'travel_agency'?: string;
};

export type issuing_transaction_flight_data_leg = {
  'arrival_airport_code'?: string;
  'carrier'?: string;
  'departure_airport_code'?: string;
  'flight_number'?: string;
  'service_class'?: string;
  'stopover_allowed'?: boolean;
};

export type issuing_transaction_fuel_data = {
  'industry_product_code'?: string;
  'quantity_decimal'?: string;
  'type': string;
  'unit': string;
  'unit_cost_decimal': string;
};

export type issuing_transaction_lodging_data = {
  'check_in_at'?: number;
  'nights'?: number;
};

export type issuing_transaction_network_data = {
  'authorization_code'?: string;
  'processing_date'?: string;
  'transaction_id'?: string;
};

export type issuing_transaction_purchase_details = {
  'fleet'?: Record<string, any>;
  'flight'?: Record<string, any>;
  'fuel'?: Record<string, any>;
  'lodging'?: Record<string, any>;
  'receipt'?: issuing_transaction_receipt_data[];
  'reference'?: string;
};

export type issuing_transaction_receipt_data = {
  'description'?: string;
  'quantity'?: number;
  'total'?: number;
  'unit_cost'?: number;
};

export type issuing_transaction_treasury = {
  'received_credit'?: string;
  'received_debit'?: string;
};

export type item = {
  'adjustable_quantity'?: Record<string, any>;
  'amount_discount': number;
  'amount_subtotal': number;
  'amount_tax': number;
  'amount_total': number;
  'currency': string;
  'description'?: string;
  'discounts'?: line_items_discount_amount[];
  'id': string;
  'metadata'?: Record<string, any>;
  'object': string;
  'price'?: Record<string, any>;
  'quantity'?: number;
  'taxes'?: line_items_tax_amount[];
};

export type klarna_address = {
  'country'?: string;
};

export type klarna_payer_details = {
  'address'?: Record<string, any>;
};

export type legal_entity_company = {
  'address'?: address;
  'address_kana'?: Record<string, any>;
  'address_kanji'?: Record<string, any>;
  'directors_provided'?: boolean;
  'directorship_declaration'?: Record<string, any>;
  'executives_provided'?: boolean;
  'export_license_id'?: string;
  'export_purpose_code'?: string;
  'name'?: string;
  'name_kana'?: string;
  'name_kanji'?: string;
  'owners_provided'?: boolean;
  'ownership_declaration'?: Record<string, any>;
  'ownership_exemption_reason'?: string;
  'phone'?: string;
  'registration_date'?: legal_entity_registration_date;
  'representative_declaration'?: Record<string, any>;
  'structure'?: string;
  'tax_id_provided'?: boolean;
  'tax_id_registrar'?: string;
  'vat_id_provided'?: boolean;
  'verification'?: Record<string, any>;
};

export type legal_entity_company_verification = {
  'document': legal_entity_company_verification_document;
};

export type legal_entity_company_verification_document = {
  'back'?: Record<string, any>;
  'details'?: string;
  'details_code'?: string;
  'front'?: Record<string, any>;
};

export type legal_entity_directorship_declaration = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type legal_entity_dob = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type legal_entity_japan_address = {
  'city'?: string;
  'country'?: string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
  'town'?: string;
};

export type legal_entity_person_verification = {
  'additional_document'?: Record<string, any>;
  'details'?: string;
  'details_code'?: string;
  'document'?: legal_entity_person_verification_document;
  'status': string;
};

export type legal_entity_person_verification_document = {
  'back'?: Record<string, any>;
  'details'?: string;
  'details_code'?: string;
  'front'?: Record<string, any>;
};

export type legal_entity_registration_date = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type legal_entity_representative_declaration = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type legal_entity_ubo_declaration = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type line_item = {
  'amount': number;
  'currency': string;
  'description'?: string;
  'discount_amounts'?: discounts_resource_discount_amount[];
  'discountable': boolean;
  'discounts': Record<string, any>[];
  'id': string;
  'invoice'?: string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'parent'?: Record<string, any>;
  'period': invoice_line_item_period;
  'pretax_credit_amounts'?: invoices_resource_pretax_credit_amount[];
  'pricing'?: Record<string, any>;
  'quantity'?: number;
  'quantity_decimal'?: string;
  'subscription'?: Record<string, any>;
  'subtotal': number;
  'taxes'?: billing_bill_resource_invoicing_taxes_tax[];
};

export type line_items_adjustable_quantity = {
  'enabled': boolean;
  'maximum'?: number;
  'minimum'?: number;
};

export type line_items_discount_amount = {
  'amount': number;
  'discount': discount;
};

export type line_items_tax_amount = {
  'amount': number;
  'rate': tax_rate;
  'taxability_reason'?: string;
  'taxable_amount'?: number;
};

export type linked_account_options_common = {
  'filters'?: payment_flows_private_payment_methods_financial_connections_common_linked_account_options_filters;
  'permissions'?: string[];
  'prefetch'?: string[];
  'return_url'?: string;
};

export type login_link = {
  'created': number;
  'object': string;
  'url': string;
};

export type mandate = {
  'customer_acceptance': customer_acceptance;
  'id': string;
  'livemode': boolean;
  'multi_use'?: mandate_multi_use;
  'object': string;
  'on_behalf_of'?: string;
  'payment_method': Record<string, any>;
  'payment_method_details': mandate_payment_method_details;
  'single_use'?: mandate_single_use;
  'status': string;
  'type': string;
};

export type mandate_acss_debit = {
  'default_for'?: string[];
  'interval_description'?: string;
  'payment_schedule': string;
  'transaction_type': string;
};

export type mandate_amazon_pay = Record<string, any>;

export type mandate_au_becs_debit = {
  'url': string;
};

export type mandate_bacs_debit = {
  'display_name'?: string;
  'network_status': string;
  'reference': string;
  'revocation_reason'?: string;
  'service_user_number'?: string;
  'url': string;
};

export type mandate_cashapp = Record<string, any>;

export type mandate_kakao_pay = Record<string, any>;

export type mandate_klarna = Record<string, any>;

export type mandate_kr_card = Record<string, any>;

export type mandate_link = Record<string, any>;

export type mandate_multi_use = {
  'amount'?: number;
  'currency'?: string;
};

export type mandate_naver_pay = Record<string, any>;

export type mandate_nz_bank_account = Record<string, any>;

export type mandate_options_payto = {
  'amount'?: number;
  'amount_type'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
  'payments_per_period'?: number;
  'purpose'?: string;
  'start_date'?: string;
};

export type mandate_options_upi = {
  'amount'?: number;
  'amount_type'?: string;
  'description'?: string;
  'end_date'?: number;
};

export type mandate_payment_method_details = {
  'acss_debit'?: mandate_acss_debit;
  'amazon_pay'?: mandate_amazon_pay;
  'au_becs_debit'?: mandate_au_becs_debit;
  'bacs_debit'?: mandate_bacs_debit;
  'card'?: card_mandate_payment_method_details;
  'cashapp'?: mandate_cashapp;
  'kakao_pay'?: mandate_kakao_pay;
  'klarna'?: mandate_klarna;
  'kr_card'?: mandate_kr_card;
  'link'?: mandate_link;
  'naver_pay'?: mandate_naver_pay;
  'nz_bank_account'?: mandate_nz_bank_account;
  'paypal'?: mandate_paypal;
  'payto'?: mandate_payto;
  'pix'?: mandate_pix;
  'revolut_pay'?: mandate_revolut_pay;
  'sepa_debit'?: mandate_sepa_debit;
  'twint'?: mandate_twint;
  'type': string;
  'upi'?: mandate_upi;
  'us_bank_account'?: mandate_us_bank_account;
};

export type mandate_paypal = {
  'billing_agreement_id'?: string;
  'payer_id'?: string;
};

export type mandate_payto = {
  'amount'?: number;
  'amount_type': string;
  'end_date'?: string;
  'payment_schedule': string;
  'payments_per_period'?: number;
  'purpose'?: string;
  'start_date'?: string;
};

export type mandate_pix = {
  'amount_includes_iof'?: string;
  'amount_type'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
  'reference'?: string;
  'start_date'?: string;
};

export type mandate_revolut_pay = Record<string, any>;

export type mandate_sepa_debit = {
  'reference': string;
  'url': string;
};

export type mandate_single_use = {
  'amount': number;
  'currency': string;
};

export type mandate_twint = Record<string, any>;

export type mandate_upi = {
  'amount'?: number;
  'amount_type'?: string;
  'description'?: string;
  'end_date'?: number;
};

export type mandate_us_bank_account = {
  'collection_method'?: string;
};

export type networks = {
  'available': string[];
  'preferred'?: string;
};

export type notification_event_data = {
  'object': Record<string, any>;
  'previous_attributes'?: Record<string, any>;
};

export type notification_event_request = {
  'id'?: string;
  'idempotency_key'?: string;
};

export type offline_acceptance = Record<string, any>;

export type online_acceptance = {
  'ip_address'?: string;
  'user_agent'?: string;
};

export type outbound_payments_payment_method_details = {
  'billing_details': treasury_shared_resource_billing_details;
  'financial_account'?: outbound_payments_payment_method_details_financial_account;
  'type': string;
  'us_bank_account'?: outbound_payments_payment_method_details_us_bank_account;
};

export type outbound_payments_payment_method_details_financial_account = {
  'id': string;
  'network': string;
};

export type outbound_payments_payment_method_details_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: Record<string, any>;
  'network': string;
  'routing_number'?: string;
};

export type outbound_transfers_payment_method_details = {
  'billing_details': treasury_shared_resource_billing_details;
  'financial_account'?: outbound_transfers_payment_method_details_financial_account;
  'type': string;
  'us_bank_account'?: outbound_transfers_payment_method_details_us_bank_account;
};

export type outbound_transfers_payment_method_details_financial_account = {
  'id': string;
  'network': string;
};

export type outbound_transfers_payment_method_details_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: Record<string, any>;
  'network': string;
  'routing_number'?: string;
};

export type package_dimensions = {
  'height': number;
  'length': number;
  'weight': number;
  'width': number;
};

export type payment_attempt_record = {
  'amount': payments_primitives_payment_records_resource_amount;
  'amount_authorized': payments_primitives_payment_records_resource_amount;
  'amount_canceled': payments_primitives_payment_records_resource_amount;
  'amount_failed': payments_primitives_payment_records_resource_amount;
  'amount_guaranteed': payments_primitives_payment_records_resource_amount;
  'amount_refunded': payments_primitives_payment_records_resource_amount;
  'amount_requested': payments_primitives_payment_records_resource_amount;
  'application'?: string;
  'created': number;
  'customer_details'?: Record<string, any>;
  'customer_presence'?: string;
  'description'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'payment_method_details'?: Record<string, any>;
  'payment_record'?: string;
  'processor_details': payments_primitives_payment_records_resource_processor_details;
  'reported_by': string;
  'shipping_details'?: Record<string, any>;
};

export type payment_data = {
  'description'?: string;
  'metadata'?: Record<string, any>;
};

export type payment_flows_amount_details = {
  'discount_amount'?: number;
  'error'?: payment_flows_amount_details_resource_error;
  'line_items'?: {
    'data': payment_intent_amount_details_line_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'shipping'?: payment_flows_amount_details_resource_shipping;
  'tax'?: payment_flows_amount_details_resource_tax;
  'tip'?: payment_flows_amount_details_client_resource_tip;
};

export type payment_flows_amount_details_client = {
  'tip'?: payment_flows_amount_details_client_resource_tip;
};

export type payment_flows_amount_details_client_resource_tip = {
  'amount'?: number;
};

export type payment_flows_amount_details_resource_error = {
  'code'?: string;
  'message'?: string;
};

export type payment_flows_amount_details_resource_line_items_list_resource_line_item_resource_payment_method_options = {
  'card'?: payment_flows_private_payment_methods_card_payment_intent_amount_details_line_item_payment_method_options;
  'card_present'?: payment_flows_private_payment_methods_card_present_amount_details_line_item_payment_method_options;
  'klarna'?: payment_flows_private_payment_methods_klarna_payment_intent_amount_details_line_item_payment_method_options;
  'paypal'?: payment_flows_private_payment_methods_paypal_amount_details_line_item_payment_method_options;
};

export type payment_flows_amount_details_resource_line_items_list_resource_line_item_resource_tax = {
  'total_tax_amount': number;
};

export type payment_flows_amount_details_resource_shipping = {
  'amount'?: number;
  'from_postal_code'?: string;
  'to_postal_code'?: string;
};

export type payment_flows_amount_details_resource_tax = {
  'total_tax_amount'?: number;
};

export type payment_flows_automatic_payment_methods_payment_intent = {
  'allow_redirects'?: string;
  'enabled': boolean;
};

export type payment_flows_automatic_payment_methods_setup_intent = {
  'allow_redirects'?: string;
  'enabled'?: boolean;
};

export type payment_flows_installment_options = {
  'enabled': boolean;
  'plan'?: payment_method_details_card_installments_plan;
};

export type payment_flows_payment_details = {
  'customer_reference'?: string;
  'order_reference'?: string;
};

export type payment_flows_payment_intent_async_workflows = {
  'inputs'?: payment_flows_payment_intent_async_workflows_resource_inputs;
};

export type payment_flows_payment_intent_async_workflows_resource_inputs = {
  'tax'?: payment_flows_payment_intent_async_workflows_resource_inputs_resource_tax;
};

export type payment_flows_payment_intent_async_workflows_resource_inputs_resource_tax = {
  'calculation': string;
};

export type payment_flows_payment_intent_presentment_details = {
  'presentment_amount': number;
  'presentment_currency': string;
};

export type payment_flows_private_payment_methods_alipay = Record<string, any>;

export type payment_flows_private_payment_methods_alipay_details = {
  'buyer_id'?: string;
  'fingerprint'?: string;
  'transaction_id'?: string;
};

export type payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_extended_authorization_extended_authorization = {
  'status': string;
};

export type payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_incremental_authorization_incremental_authorization = {
  'status': string;
};

export type payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_overcapture_overcapture = {
  'maximum_amount_capturable': number;
  'status': string;
};

export type payment_flows_private_payment_methods_card_details_api_resource_multicapture = {
  'status': string;
};

export type payment_flows_private_payment_methods_card_payment_intent_amount_details_line_item_payment_method_options = {
  'commodity_code'?: string;
};

export type payment_flows_private_payment_methods_card_present_amount_details_line_item_payment_method_options = {
  'commodity_code'?: string;
};

export type payment_flows_private_payment_methods_card_present_common_wallet = {
  'type': string;
};

export type payment_flows_private_payment_methods_financial_connections_common_linked_account_options_filters = {
  'account_subcategories'?: string[];
};

export type payment_flows_private_payment_methods_kakao_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_flows_private_payment_methods_klarna_dob = {
  'day'?: number;
  'month'?: number;
  'year'?: number;
};

export type payment_flows_private_payment_methods_klarna_payment_intent_amount_details_line_item_payment_method_options = {
  'image_url'?: string;
  'product_url'?: string;
  'reference'?: string;
  'subscription_reference'?: string;
};

export type payment_flows_private_payment_methods_naver_pay_payment_method_options = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_flows_private_payment_methods_payco_payment_method_options = {
  'capture_method'?: string;
};

export type payment_flows_private_payment_methods_paypal_amount_details_line_item_payment_method_options = {
  'category'?: string;
  'description'?: string;
  'sold_by'?: string;
};

export type payment_flows_private_payment_methods_samsung_pay_payment_method_options = {
  'capture_method'?: string;
};

export type payment_intent = {
  'amount'?: number;
  'amount_capturable'?: number;
  'amount_details'?: Record<string, any>;
  'amount_received'?: number;
  'application'?: Record<string, any>;
  'application_fee_amount'?: number;
  'automatic_payment_methods'?: Record<string, any>;
  'canceled_at'?: number;
  'cancellation_reason'?: string;
  'capture_method'?: string;
  'client_secret'?: string;
  'confirmation_method'?: string;
  'created': number;
  'currency'?: string;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'description'?: string;
  'excluded_payment_method_types'?: string[];
  'hooks'?: payment_flows_payment_intent_async_workflows;
  'id': string;
  'last_payment_error'?: Record<string, any>;
  'latest_charge'?: Record<string, any>;
  'livemode': boolean;
  'managed_payments'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'next_action'?: Record<string, any>;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'payment_details'?: payment_flows_payment_details;
  'payment_method'?: Record<string, any>;
  'payment_method_configuration_details'?: Record<string, any>;
  'payment_method_options'?: Record<string, any>;
  'payment_method_types'?: string[];
  'presentment_details'?: payment_flows_payment_intent_presentment_details;
  'processing'?: Record<string, any>;
  'receipt_email'?: string;
  'review'?: Record<string, any>;
  'setup_future_usage'?: string;
  'shipping'?: Record<string, any>;
  'statement_descriptor'?: string;
  'statement_descriptor_suffix'?: string;
  'status': string;
  'transfer_data'?: Record<string, any>;
  'transfer_group'?: string;
};

export type payment_intent_amount_details_line_item = {
  'discount_amount'?: number;
  'id': string;
  'object': string;
  'payment_method_options'?: Record<string, any>;
  'product_code'?: string;
  'product_name': string;
  'quantity': number;
  'tax'?: Record<string, any>;
  'unit_cost': number;
  'unit_of_measure'?: string;
};

export type payment_intent_card_processing = {
  'customer_notification'?: payment_intent_processing_customer_notification;
};

export type payment_intent_next_action = {
  'alipay_handle_redirect'?: payment_intent_next_action_alipay_handle_redirect;
  'blik_authorize'?: payment_intent_next_action_blik_authorize;
  'boleto_display_details'?: payment_intent_next_action_boleto;
  'card_await_notification'?: payment_intent_next_action_card_await_notification;
  'cashapp_handle_redirect_or_display_qr_code'?: payment_intent_next_action_cashapp_handle_redirect_or_display_qr_code;
  'display_bank_transfer_instructions'?: payment_intent_next_action_display_bank_transfer_instructions;
  'klarna_display_qr_code'?: payment_intent_next_action_klarna_display_qr_code;
  'konbini_display_details'?: payment_intent_next_action_konbini;
  'multibanco_display_details'?: payment_intent_next_action_display_multibanco_details;
  'oxxo_display_details'?: payment_intent_next_action_display_oxxo_details;
  'paynow_display_qr_code'?: payment_intent_next_action_paynow_display_qr_code;
  'pix_display_qr_code'?: payment_intent_next_action_pix_display_qr_code;
  'promptpay_display_qr_code'?: payment_intent_next_action_promptpay_display_qr_code;
  'redirect_to_url'?: payment_intent_next_action_redirect_to_url;
  'swish_handle_redirect_or_display_qr_code'?: payment_intent_next_action_swish_handle_redirect_or_display_qr_code;
  'type': string;
  'upi_handle_redirect_or_display_qr_code'?: payment_intent_next_action_upi_handle_redirect_or_display_qr_code;
  'use_stripe_sdk'?: Record<string, any>;
  'verify_with_microdeposits'?: payment_intent_next_action_verify_with_microdeposits;
  'wechat_pay_display_qr_code'?: payment_intent_next_action_wechat_pay_display_qr_code;
  'wechat_pay_redirect_to_android_app'?: payment_intent_next_action_wechat_pay_redirect_to_android_app;
  'wechat_pay_redirect_to_ios_app'?: payment_intent_next_action_wechat_pay_redirect_to_ios_app;
};

export type payment_intent_next_action_alipay_handle_redirect = {
  'native_data'?: string;
  'native_url'?: string;
  'return_url'?: string;
  'url'?: string;
};

export type payment_intent_next_action_blik_authorize = Record<string, any>;

export type payment_intent_next_action_boleto = {
  'expires_at'?: number;
  'hosted_voucher_url'?: string;
  'number'?: string;
  'pdf'?: string;
};

export type payment_intent_next_action_card_await_notification = {
  'charge_attempt_at'?: number;
  'customer_approval_required'?: boolean;
};

export type payment_intent_next_action_cashapp_handle_redirect_or_display_qr_code = {
  'hosted_instructions_url': string;
  'mobile_auth_url': string;
  'qr_code': payment_intent_next_action_cashapp_qr_code;
};

export type payment_intent_next_action_cashapp_qr_code = {
  'expires_at': number;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_display_bank_transfer_instructions = {
  'amount_remaining'?: number;
  'currency'?: string;
  'financial_addresses'?: funding_instructions_bank_transfer_financial_address[];
  'hosted_instructions_url'?: string;
  'reference'?: string;
  'type': string;
};

export type payment_intent_next_action_display_multibanco_details = {
  'entity'?: string;
  'expires_at'?: number;
  'hosted_voucher_url'?: string;
  'reference'?: string;
};

export type payment_intent_next_action_display_oxxo_details = {
  'expires_after'?: number;
  'hosted_voucher_url'?: string;
  'number'?: string;
};

export type payment_intent_next_action_klarna_display_qr_code = {
  'data': string;
  'expires_at'?: number;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_konbini = {
  'expires_at': number;
  'hosted_voucher_url'?: string;
  'stores': payment_intent_next_action_konbini_stores;
};

export type payment_intent_next_action_konbini_familymart = {
  'confirmation_number'?: string;
  'payment_code': string;
};

export type payment_intent_next_action_konbini_lawson = {
  'confirmation_number'?: string;
  'payment_code': string;
};

export type payment_intent_next_action_konbini_ministop = {
  'confirmation_number'?: string;
  'payment_code': string;
};

export type payment_intent_next_action_konbini_seicomart = {
  'confirmation_number'?: string;
  'payment_code': string;
};

export type payment_intent_next_action_konbini_stores = {
  'familymart'?: Record<string, any>;
  'lawson'?: Record<string, any>;
  'ministop'?: Record<string, any>;
  'seicomart'?: Record<string, any>;
};

export type payment_intent_next_action_paynow_display_qr_code = {
  'data': string;
  'hosted_instructions_url'?: string;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_pix_display_qr_code = {
  'data'?: string;
  'expires_at'?: number;
  'hosted_instructions_url'?: string;
  'image_url_png'?: string;
  'image_url_svg'?: string;
};

export type payment_intent_next_action_promptpay_display_qr_code = {
  'data': string;
  'hosted_instructions_url': string;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_redirect_to_url = {
  'return_url'?: string;
  'url'?: string;
};

export type payment_intent_next_action_swish_handle_redirect_or_display_qr_code = {
  'hosted_instructions_url': string;
  'qr_code': payment_intent_next_action_swish_qr_code;
};

export type payment_intent_next_action_swish_qr_code = {
  'data': string;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_upi_handle_redirect_or_display_qr_code = {
  'hosted_instructions_url': string;
  'qr_code': payment_intent_next_action_upiqr_code;
};

export type payment_intent_next_action_upiqr_code = {
  'expires_at': number;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_verify_with_microdeposits = {
  'arrival_date': number;
  'hosted_verification_url': string;
  'microdeposit_type'?: string;
};

export type payment_intent_next_action_wechat_pay_display_qr_code = {
  'data': string;
  'hosted_instructions_url': string;
  'image_data_url': string;
  'image_url_png': string;
  'image_url_svg': string;
};

export type payment_intent_next_action_wechat_pay_redirect_to_android_app = {
  'app_id': string;
  'nonce_str': string;
  'package': string;
  'partner_id': string;
  'prepay_id': string;
  'sign': string;
  'timestamp': string;
};

export type payment_intent_next_action_wechat_pay_redirect_to_ios_app = {
  'native_url': string;
};

export type payment_intent_payment_method_options = {
  'acss_debit'?: Record<string, any>;
  'affirm'?: Record<string, any>;
  'afterpay_clearpay'?: Record<string, any>;
  'alipay'?: Record<string, any>;
  'alma'?: Record<string, any>;
  'amazon_pay'?: Record<string, any>;
  'au_becs_debit'?: Record<string, any>;
  'bacs_debit'?: Record<string, any>;
  'bancontact'?: Record<string, any>;
  'billie'?: Record<string, any>;
  'bizum'?: Record<string, any>;
  'blik'?: Record<string, any>;
  'boleto'?: Record<string, any>;
  'card'?: Record<string, any>;
  'card_present'?: Record<string, any>;
  'cashapp'?: Record<string, any>;
  'crypto'?: Record<string, any>;
  'customer_balance'?: Record<string, any>;
  'eps'?: Record<string, any>;
  'fpx'?: Record<string, any>;
  'giropay'?: Record<string, any>;
  'grabpay'?: Record<string, any>;
  'ideal'?: Record<string, any>;
  'interac_present'?: Record<string, any>;
  'kakao_pay'?: Record<string, any>;
  'klarna'?: Record<string, any>;
  'konbini'?: Record<string, any>;
  'kr_card'?: Record<string, any>;
  'link'?: Record<string, any>;
  'mb_way'?: Record<string, any>;
  'mobilepay'?: Record<string, any>;
  'multibanco'?: Record<string, any>;
  'naver_pay'?: Record<string, any>;
  'nz_bank_account'?: Record<string, any>;
  'oxxo'?: Record<string, any>;
  'p24'?: Record<string, any>;
  'pay_by_bank'?: Record<string, any>;
  'payco'?: Record<string, any>;
  'paynow'?: Record<string, any>;
  'paypal'?: Record<string, any>;
  'payto'?: Record<string, any>;
  'pix'?: Record<string, any>;
  'promptpay'?: Record<string, any>;
  'revolut_pay'?: Record<string, any>;
  'samsung_pay'?: Record<string, any>;
  'satispay'?: Record<string, any>;
  'scalapay'?: Record<string, any>;
  'sepa_debit'?: Record<string, any>;
  'sofort'?: Record<string, any>;
  'swish'?: Record<string, any>;
  'twint'?: Record<string, any>;
  'upi'?: Record<string, any>;
  'us_bank_account'?: Record<string, any>;
  'wechat_pay'?: Record<string, any>;
  'zip'?: Record<string, any>;
};

export type payment_intent_payment_method_options_acss_debit = {
  'mandate_options'?: payment_intent_payment_method_options_mandate_options_acss_debit;
  'setup_future_usage'?: string;
  'target_date'?: string;
  'verification_method'?: string;
};

export type payment_intent_payment_method_options_au_becs_debit = {
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type payment_intent_payment_method_options_bacs_debit = {
  'mandate_options'?: payment_intent_payment_method_options_mandate_options_bacs_debit;
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type payment_intent_payment_method_options_blik = {
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_card = {
  'capture_method'?: string;
  'installments'?: Record<string, any>;
  'mandate_options'?: Record<string, any>;
  'network'?: string;
  'request_extended_authorization'?: string;
  'request_incremental_authorization'?: string;
  'request_multicapture'?: string;
  'request_overcapture'?: string;
  'request_three_d_secure'?: string;
  'require_cvc_recollection'?: boolean;
  'setup_future_usage'?: string;
  'statement_descriptor_suffix_kana'?: string;
  'statement_descriptor_suffix_kanji'?: string;
};

export type payment_intent_payment_method_options_eps = {
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_link = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_mandate_options_acss_debit = {
  'custom_mandate_url'?: string;
  'interval_description'?: string;
  'payment_schedule'?: string;
  'transaction_type'?: string;
};

export type payment_intent_payment_method_options_mandate_options_bacs_debit = {
  'reference_prefix'?: string;
};

export type payment_intent_payment_method_options_mandate_options_payto = {
  'amount'?: number;
  'amount_type'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
  'payments_per_period'?: number;
  'purpose'?: string;
};

export type payment_intent_payment_method_options_mandate_options_sepa_debit = {
  'reference_prefix'?: string;
};

export type payment_intent_payment_method_options_mobilepay = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_nz_bank_account = {
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type payment_intent_payment_method_options_payto = {
  'mandate_options'?: payment_intent_payment_method_options_mandate_options_payto;
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_sepa_debit = {
  'mandate_options'?: payment_intent_payment_method_options_mandate_options_sepa_debit;
  'setup_future_usage'?: string;
  'target_date'?: string;
};

export type payment_intent_payment_method_options_swish = {
  'reference'?: string;
  'setup_future_usage'?: string;
};

export type payment_intent_payment_method_options_us_bank_account = {
  'financial_connections'?: linked_account_options_common;
  'mandate_options'?: payment_method_options_us_bank_account_mandate_options;
  'setup_future_usage'?: string;
  'target_date'?: string;
  'transaction_purpose'?: string;
  'verification_method'?: string;
};

export type payment_intent_processing = {
  'card'?: payment_intent_card_processing;
  'type': string;
};

export type payment_intent_processing_customer_notification = {
  'approval_requested'?: boolean;
  'completes_at'?: number;
};

export type payment_intent_type_specific_payment_method_options_client = {
  'capture_method'?: string;
  'installments'?: payment_flows_installment_options;
  'mandate_options'?: payment_intent_payment_method_options_mandate_options_payto;
  'request_incremental_authorization_support'?: boolean;
  'require_cvc_recollection'?: boolean;
  'routing'?: payment_method_options_card_present_routing;
  'setup_future_usage'?: string;
  'verification_method'?: string;
};

export type payment_link = {
  'active': boolean;
  'after_completion': payment_links_resource_after_completion;
  'allow_promotion_codes': boolean;
  'application'?: Record<string, any>;
  'application_fee_amount'?: number;
  'application_fee_percent'?: number;
  'automatic_tax': payment_links_resource_automatic_tax;
  'billing_address_collection': string;
  'consent_collection'?: Record<string, any>;
  'currency': string;
  'custom_fields': payment_links_resource_custom_fields[];
  'custom_text': payment_links_resource_custom_text;
  'customer_creation': string;
  'id': string;
  'inactive_message'?: string;
  'invoice_creation'?: Record<string, any>;
  'line_items'?: {
    'data': item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'managed_payments'?: Record<string, any>;
  'metadata': Record<string, any>;
  'name_collection'?: payment_links_resource_name_collection;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'optional_items'?: payment_links_resource_optional_item[];
  'payment_intent_data'?: Record<string, any>;
  'payment_method_collection': string;
  'payment_method_options'?: Record<string, any>;
  'payment_method_types'?: string[];
  'phone_number_collection': payment_links_resource_phone_number_collection;
  'restrictions'?: Record<string, any>;
  'shipping_address_collection'?: Record<string, any>;
  'shipping_options': payment_links_resource_shipping_option[];
  'submit_type': string;
  'subscription_data'?: Record<string, any>;
  'tax_id_collection': payment_links_resource_tax_id_collection;
  'transfer_data'?: Record<string, any>;
  'url': string;
};

export type payment_links_resource_after_completion = {
  'hosted_confirmation'?: payment_links_resource_completion_behavior_confirmation_page;
  'redirect'?: payment_links_resource_completion_behavior_redirect;
  'type': string;
};

export type payment_links_resource_automatic_tax = {
  'enabled': boolean;
  'liability'?: Record<string, any>;
};

export type payment_links_resource_business_name = {
  'enabled': boolean;
  'optional': boolean;
};

export type payment_links_resource_card_payment_method_options = {
  'restrictions'?: Record<string, any>;
};

export type payment_links_resource_card_restrictions = {
  'brands_blocked': string[];
};

export type payment_links_resource_completed_sessions = {
  'count': number;
  'limit': number;
};

export type payment_links_resource_completion_behavior_confirmation_page = {
  'custom_message'?: string;
};

export type payment_links_resource_completion_behavior_redirect = {
  'url': string;
};

export type payment_links_resource_consent_collection = {
  'payment_method_reuse_agreement'?: Record<string, any>;
  'promotions'?: string;
  'terms_of_service'?: string;
};

export type payment_links_resource_custom_fields = {
  'dropdown'?: payment_links_resource_custom_fields_dropdown;
  'key': string;
  'label': payment_links_resource_custom_fields_label;
  'numeric'?: payment_links_resource_custom_fields_numeric;
  'optional': boolean;
  'text'?: payment_links_resource_custom_fields_text;
  'type': string;
};

export type payment_links_resource_custom_fields_dropdown = {
  'default_value'?: string;
  'options': payment_links_resource_custom_fields_dropdown_option[];
};

export type payment_links_resource_custom_fields_dropdown_option = {
  'label': string;
  'value': string;
};

export type payment_links_resource_custom_fields_label = {
  'custom'?: string;
  'type': string;
};

export type payment_links_resource_custom_fields_numeric = {
  'default_value'?: string;
  'maximum_length'?: number;
  'minimum_length'?: number;
};

export type payment_links_resource_custom_fields_text = {
  'default_value'?: string;
  'maximum_length'?: number;
  'minimum_length'?: number;
};

export type payment_links_resource_custom_text = {
  'after_submit'?: Record<string, any>;
  'shipping_address'?: Record<string, any>;
  'submit'?: Record<string, any>;
  'terms_of_service_acceptance'?: Record<string, any>;
};

export type payment_links_resource_custom_text_position = {
  'message': string;
};

export type payment_links_resource_individual_name = {
  'enabled': boolean;
  'optional': boolean;
};

export type payment_links_resource_invoice_creation = {
  'enabled': boolean;
  'invoice_data'?: Record<string, any>;
};

export type payment_links_resource_invoice_settings = {
  'account_tax_ids'?: Record<string, any>[];
  'custom_fields'?: invoice_setting_custom_field[];
  'description'?: string;
  'footer'?: string;
  'issuer'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'rendering_options'?: Record<string, any>;
};

export type payment_links_resource_name_collection = {
  'business'?: payment_links_resource_business_name;
  'individual'?: payment_links_resource_individual_name;
};

export type payment_links_resource_optional_item = {
  'adjustable_quantity'?: Record<string, any>;
  'price': string;
  'quantity': number;
};

export type payment_links_resource_optional_item_adjustable_quantity = {
  'enabled': boolean;
  'maximum'?: number;
  'minimum'?: number;
};

export type payment_links_resource_payment_intent_data = {
  'capture_method'?: string;
  'description'?: string;
  'metadata': Record<string, any>;
  'setup_future_usage'?: string;
  'statement_descriptor'?: string;
  'statement_descriptor_suffix'?: string;
  'transfer_group'?: string;
};

export type payment_links_resource_payment_method_options = {
  'card'?: Record<string, any>;
};

export type payment_links_resource_payment_method_reuse_agreement = {
  'position': string;
};

export type payment_links_resource_phone_number_collection = {
  'enabled': boolean;
};

export type payment_links_resource_restrictions = {
  'completed_sessions': payment_links_resource_completed_sessions;
};

export type payment_links_resource_shipping_address_collection = {
  'allowed_countries': string[];
};

export type payment_links_resource_shipping_option = {
  'shipping_amount': number;
  'shipping_rate': Record<string, any>;
};

export type payment_links_resource_subscription_data = {
  'description'?: string;
  'invoice_settings': payment_links_resource_subscription_data_invoice_settings;
  'metadata': Record<string, any>;
  'trial_period_days'?: number;
  'trial_settings'?: Record<string, any>;
};

export type payment_links_resource_subscription_data_invoice_settings = {
  'issuer': connect_account_reference;
};

export type payment_links_resource_tax_id_collection = {
  'enabled': boolean;
  'required': string;
};

export type payment_links_resource_transfer_data = {
  'amount'?: number;
  'destination': Record<string, any>;
};

export type payment_method = {
  'acss_debit'?: payment_method_acss_debit;
  'affirm'?: payment_method_affirm;
  'afterpay_clearpay'?: payment_method_afterpay_clearpay;
  'alipay'?: payment_flows_private_payment_methods_alipay;
  'allow_redisplay'?: string;
  'alma'?: payment_method_alma;
  'amazon_pay'?: payment_method_amazon_pay;
  'au_becs_debit'?: payment_method_au_becs_debit;
  'bacs_debit'?: payment_method_bacs_debit;
  'bancontact'?: payment_method_bancontact;
  'billie'?: payment_method_billie;
  'billing_details': billing_details;
  'bizum'?: payment_method_bizum;
  'blik'?: payment_method_blik;
  'boleto'?: payment_method_boleto;
  'card'?: payment_method_card;
  'card_present'?: payment_method_card_present;
  'cashapp'?: payment_method_cashapp;
  'created': number;
  'crypto'?: payment_method_crypto;
  'custom'?: payment_method_custom;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'customer_balance'?: payment_method_customer_balance;
  'eps'?: payment_method_eps;
  'fpx'?: payment_method_fpx;
  'giropay'?: payment_method_giropay;
  'grabpay'?: payment_method_grabpay;
  'id': string;
  'ideal'?: payment_method_ideal;
  'interac_present'?: payment_method_interac_present;
  'kakao_pay'?: payment_method_kakao_pay;
  'klarna'?: payment_method_klarna;
  'konbini'?: payment_method_konbini;
  'kr_card'?: payment_method_kr_card;
  'link'?: payment_method_link;
  'livemode': boolean;
  'mb_way'?: payment_method_mb_way;
  'metadata'?: Record<string, any>;
  'mobilepay'?: payment_method_mobilepay;
  'multibanco'?: payment_method_multibanco;
  'naver_pay'?: payment_method_naver_pay;
  'nz_bank_account'?: payment_method_nz_bank_account;
  'object': string;
  'oxxo'?: payment_method_oxxo;
  'p24'?: payment_method_p24;
  'pay_by_bank'?: payment_method_pay_by_bank;
  'payco'?: payment_method_payco;
  'paynow'?: payment_method_paynow;
  'paypal'?: payment_method_paypal;
  'payto'?: payment_method_payto;
  'pix'?: payment_method_pix;
  'promptpay'?: payment_method_promptpay;
  'radar_options'?: radar_radar_options;
  'revolut_pay'?: payment_method_revolut_pay;
  'samsung_pay'?: payment_method_samsung_pay;
  'satispay'?: payment_method_satispay;
  'scalapay'?: payment_method_scalapay;
  'sepa_debit'?: payment_method_sepa_debit;
  'sofort'?: payment_method_sofort;
  'sunbit'?: payment_method_sunbit;
  'swish'?: payment_method_swish;
  'twint'?: payment_method_twint;
  'type': string;
  'upi'?: payment_method_upi;
  'us_bank_account'?: payment_method_us_bank_account;
  'wechat_pay'?: payment_method_wechat_pay;
  'zip'?: payment_method_zip;
};

export type payment_method_acss_debit = {
  'bank_name'?: string;
  'fingerprint'?: string;
  'institution_number'?: string;
  'last4'?: string;
  'transit_number'?: string;
};

export type payment_method_affirm = Record<string, any>;

export type payment_method_afterpay_clearpay = Record<string, any>;

export type payment_method_alma = Record<string, any>;

export type payment_method_amazon_pay = Record<string, any>;

export type payment_method_au_becs_debit = {
  'bsb_number'?: string;
  'fingerprint'?: string;
  'last4'?: string;
};

export type payment_method_bacs_debit = {
  'fingerprint'?: string;
  'last4'?: string;
  'sort_code'?: string;
};

export type payment_method_bancontact = Record<string, any>;

export type payment_method_billie = Record<string, any>;

export type payment_method_bizum = Record<string, any>;

export type payment_method_blik = Record<string, any>;

export type payment_method_boleto = {
  'tax_id': string;
};

export type payment_method_card = {
  'brand': string;
  'checks'?: Record<string, any>;
  'country'?: string;
  'display_brand'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding': string;
  'generated_from'?: Record<string, any>;
  'last4': string;
  'networks'?: Record<string, any>;
  'regulated_status'?: string;
  'three_d_secure_usage'?: Record<string, any>;
  'wallet'?: Record<string, any>;
};

export type payment_method_card_checks = {
  'address_line1_check'?: string;
  'address_postal_code_check'?: string;
  'cvc_check'?: string;
};

export type payment_method_card_generated_card = {
  'charge'?: string;
  'payment_method_details'?: Record<string, any>;
  'setup_attempt'?: Record<string, any>;
};

export type payment_method_card_present = {
  'brand'?: string;
  'brand_product'?: string;
  'cardholder_name'?: string;
  'country'?: string;
  'description'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding'?: string;
  'issuer'?: string;
  'last4'?: string;
  'networks'?: Record<string, any>;
  'offline'?: Record<string, any>;
  'preferred_locales'?: string[];
  'read_method'?: string;
  'wallet'?: payment_flows_private_payment_methods_card_present_common_wallet;
};

export type payment_method_card_present_networks = {
  'available': string[];
  'preferred'?: string;
};

export type payment_method_card_wallet = {
  'amex_express_checkout'?: payment_method_card_wallet_amex_express_checkout;
  'apple_pay'?: payment_method_card_wallet_apple_pay;
  'dynamic_last4'?: string;
  'google_pay'?: payment_method_card_wallet_google_pay;
  'link'?: payment_method_card_wallet_link;
  'masterpass'?: payment_method_card_wallet_masterpass;
  'samsung_pay'?: payment_method_card_wallet_samsung_pay;
  'type': string;
  'visa_checkout'?: payment_method_card_wallet_visa_checkout;
};

export type payment_method_card_wallet_amex_express_checkout = Record<string, any>;

export type payment_method_card_wallet_apple_pay = Record<string, any>;

export type payment_method_card_wallet_google_pay = Record<string, any>;

export type payment_method_card_wallet_link = Record<string, any>;

export type payment_method_card_wallet_masterpass = {
  'billing_address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'shipping_address'?: Record<string, any>;
};

export type payment_method_card_wallet_samsung_pay = Record<string, any>;

export type payment_method_card_wallet_visa_checkout = {
  'billing_address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'shipping_address'?: Record<string, any>;
};

export type payment_method_cashapp = {
  'buyer_id'?: string;
  'cashtag'?: string;
};

export type payment_method_config_biz_payment_method_configuration_details = {
  'id': string;
  'parent'?: string;
};

export type payment_method_config_resource_display_preference = {
  'overridable'?: boolean;
  'preference': string;
  'value': string;
};

export type payment_method_config_resource_payment_method_properties = {
  'available': boolean;
  'display_preference': payment_method_config_resource_display_preference;
};

export type payment_method_configuration = {
  'acss_debit'?: payment_method_config_resource_payment_method_properties;
  'active': boolean;
  'affirm'?: payment_method_config_resource_payment_method_properties;
  'afterpay_clearpay'?: payment_method_config_resource_payment_method_properties;
  'alipay'?: payment_method_config_resource_payment_method_properties;
  'alma'?: payment_method_config_resource_payment_method_properties;
  'amazon_pay'?: payment_method_config_resource_payment_method_properties;
  'apple_pay'?: payment_method_config_resource_payment_method_properties;
  'application'?: string;
  'au_becs_debit'?: payment_method_config_resource_payment_method_properties;
  'bacs_debit'?: payment_method_config_resource_payment_method_properties;
  'bancontact'?: payment_method_config_resource_payment_method_properties;
  'billie'?: payment_method_config_resource_payment_method_properties;
  'bizum'?: payment_method_config_resource_payment_method_properties;
  'blik'?: payment_method_config_resource_payment_method_properties;
  'boleto'?: payment_method_config_resource_payment_method_properties;
  'card'?: payment_method_config_resource_payment_method_properties;
  'cartes_bancaires'?: payment_method_config_resource_payment_method_properties;
  'cashapp'?: payment_method_config_resource_payment_method_properties;
  'crypto'?: payment_method_config_resource_payment_method_properties;
  'customer_balance'?: payment_method_config_resource_payment_method_properties;
  'eps'?: payment_method_config_resource_payment_method_properties;
  'fpx'?: payment_method_config_resource_payment_method_properties;
  'giropay'?: payment_method_config_resource_payment_method_properties;
  'google_pay'?: payment_method_config_resource_payment_method_properties;
  'grabpay'?: payment_method_config_resource_payment_method_properties;
  'id': string;
  'ideal'?: payment_method_config_resource_payment_method_properties;
  'is_default': boolean;
  'jcb'?: payment_method_config_resource_payment_method_properties;
  'kakao_pay'?: payment_method_config_resource_payment_method_properties;
  'klarna'?: payment_method_config_resource_payment_method_properties;
  'konbini'?: payment_method_config_resource_payment_method_properties;
  'kr_card'?: payment_method_config_resource_payment_method_properties;
  'link'?: payment_method_config_resource_payment_method_properties;
  'livemode': boolean;
  'mb_way'?: payment_method_config_resource_payment_method_properties;
  'mobilepay'?: payment_method_config_resource_payment_method_properties;
  'multibanco'?: payment_method_config_resource_payment_method_properties;
  'name': string;
  'naver_pay'?: payment_method_config_resource_payment_method_properties;
  'nz_bank_account'?: payment_method_config_resource_payment_method_properties;
  'object': string;
  'oxxo'?: payment_method_config_resource_payment_method_properties;
  'p24'?: payment_method_config_resource_payment_method_properties;
  'parent'?: string;
  'pay_by_bank'?: payment_method_config_resource_payment_method_properties;
  'payco'?: payment_method_config_resource_payment_method_properties;
  'paynow'?: payment_method_config_resource_payment_method_properties;
  'paypal'?: payment_method_config_resource_payment_method_properties;
  'payto'?: payment_method_config_resource_payment_method_properties;
  'pix'?: payment_method_config_resource_payment_method_properties;
  'promptpay'?: payment_method_config_resource_payment_method_properties;
  'revolut_pay'?: payment_method_config_resource_payment_method_properties;
  'samsung_pay'?: payment_method_config_resource_payment_method_properties;
  'satispay'?: payment_method_config_resource_payment_method_properties;
  'scalapay'?: payment_method_config_resource_payment_method_properties;
  'sepa_debit'?: payment_method_config_resource_payment_method_properties;
  'sofort'?: payment_method_config_resource_payment_method_properties;
  'sunbit'?: payment_method_config_resource_payment_method_properties;
  'swish'?: payment_method_config_resource_payment_method_properties;
  'twint'?: payment_method_config_resource_payment_method_properties;
  'upi'?: payment_method_config_resource_payment_method_properties;
  'us_bank_account'?: payment_method_config_resource_payment_method_properties;
  'wechat_pay'?: payment_method_config_resource_payment_method_properties;
  'zip'?: payment_method_config_resource_payment_method_properties;
};

export type payment_method_crypto = Record<string, any>;

export type payment_method_custom = {
  'display_name'?: string;
  'logo'?: Record<string, any>;
  'type': string;
};

export type payment_method_customer_balance = Record<string, any>;

export type payment_method_details = {
  'ach_credit_transfer'?: payment_method_details_ach_credit_transfer;
  'ach_debit'?: payment_method_details_ach_debit;
  'acss_debit'?: payment_method_details_acss_debit;
  'affirm'?: payment_method_details_affirm;
  'afterpay_clearpay'?: payment_method_details_afterpay_clearpay;
  'alipay'?: payment_flows_private_payment_methods_alipay_details;
  'alma'?: payment_method_details_alma;
  'amazon_pay'?: payment_method_details_amazon_pay;
  'au_becs_debit'?: payment_method_details_au_becs_debit;
  'bacs_debit'?: payment_method_details_bacs_debit;
  'bancontact'?: payment_method_details_bancontact;
  'billie'?: payment_method_details_billie;
  'bizum'?: payment_method_details_bizum;
  'blik'?: payment_method_details_blik;
  'boleto'?: payment_method_details_boleto;
  'card'?: payment_method_details_card;
  'card_present'?: payment_method_details_card_present;
  'cashapp'?: payment_method_details_cashapp;
  'crypto'?: payment_method_details_crypto;
  'customer_balance'?: payment_method_details_customer_balance;
  'eps'?: payment_method_details_eps;
  'fpx'?: payment_method_details_fpx;
  'giropay'?: payment_method_details_giropay;
  'grabpay'?: payment_method_details_grabpay;
  'ideal'?: payment_method_details_ideal;
  'interac_present'?: payment_method_details_interac_present;
  'kakao_pay'?: payment_method_details_kakao_pay;
  'klarna'?: payment_method_details_klarna;
  'konbini'?: payment_method_details_konbini;
  'kr_card'?: payment_method_details_kr_card;
  'link'?: payment_method_details_link;
  'mb_way'?: payment_method_details_mb_way;
  'mobilepay'?: payment_method_details_mobilepay;
  'multibanco'?: payment_method_details_multibanco;
  'naver_pay'?: payment_method_details_naver_pay;
  'nz_bank_account'?: payment_method_details_nz_bank_account;
  'oxxo'?: payment_method_details_oxxo;
  'p24'?: payment_method_details_p24;
  'pay_by_bank'?: payment_method_details_pay_by_bank;
  'payco'?: payment_method_details_payco;
  'paynow'?: payment_method_details_paynow;
  'paypal'?: payment_method_details_paypal;
  'payto'?: payment_method_details_payto;
  'pix'?: payment_method_details_pix;
  'promptpay'?: payment_method_details_promptpay;
  'revolut_pay'?: payment_method_details_revolut_pay;
  'samsung_pay'?: payment_method_details_samsung_pay;
  'satispay'?: payment_method_details_satispay;
  'scalapay'?: payment_method_details_scalapay;
  'sepa_debit'?: payment_method_details_sepa_debit;
  'sofort'?: payment_method_details_sofort;
  'stripe_account'?: payment_method_details_stripe_account;
  'sunbit'?: payment_method_details_sunbit;
  'swish'?: payment_method_details_swish;
  'twint'?: payment_method_details_twint;
  'type': string;
  'upi'?: payment_method_details_upi;
  'us_bank_account'?: payment_method_details_us_bank_account;
  'wechat'?: payment_method_details_wechat;
  'wechat_pay'?: payment_method_details_wechat_pay;
  'zip'?: payment_method_details_zip;
};

export type payment_method_details_ach_credit_transfer = {
  'account_number'?: string;
  'bank_name'?: string;
  'routing_number'?: string;
  'swift_code'?: string;
};

export type payment_method_details_ach_debit = {
  'account_holder_type'?: string;
  'bank_name'?: string;
  'country'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'routing_number'?: string;
};

export type payment_method_details_acss_debit = {
  'bank_name'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'institution_number'?: string;
  'last4'?: string;
  'mandate'?: string;
  'transit_number'?: string;
};

export type payment_method_details_affirm = {
  'location'?: string;
  'reader'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_afterpay_clearpay = {
  'order_id'?: string;
  'reference'?: string;
};

export type payment_method_details_alma = {
  'installments'?: alma_installments;
  'transaction_id'?: string;
};

export type payment_method_details_amazon_pay = {
  'funding'?: amazon_pay_underlying_payment_method_funding_details;
  'transaction_id'?: string;
};

export type payment_method_details_au_becs_debit = {
  'bsb_number'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: string;
};

export type payment_method_details_bacs_debit = {
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: string;
  'sort_code'?: string;
};

export type payment_method_details_bancontact = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type payment_method_details_billie = {
  'transaction_id'?: string;
};

export type payment_method_details_bizum = {
  'transaction_id'?: string;
};

export type payment_method_details_blik = {
  'buyer_id'?: string;
};

export type payment_method_details_boleto = {
  'tax_id': string;
};

export type payment_method_details_card = {
  'amount_authorized'?: number;
  'authorization_code'?: string;
  'brand'?: string;
  'capture_before'?: number;
  'checks'?: Record<string, any>;
  'country'?: string;
  'exp_month': number;
  'exp_year': number;
  'extended_authorization'?: payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_extended_authorization_extended_authorization;
  'fingerprint'?: string;
  'funding'?: string;
  'incremental_authorization'?: payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_incremental_authorization_incremental_authorization;
  'installments'?: Record<string, any>;
  'last4'?: string;
  'mandate'?: string;
  'multicapture'?: payment_flows_private_payment_methods_card_details_api_resource_multicapture;
  'network'?: string;
  'network_token'?: Record<string, any>;
  'network_transaction_id'?: string;
  'overcapture'?: payment_flows_private_payment_methods_card_details_api_resource_enterprise_features_overcapture_overcapture;
  'regulated_status'?: string;
  'three_d_secure'?: Record<string, any>;
  'wallet'?: Record<string, any>;
};

export type payment_method_details_card_checks = {
  'address_line1_check'?: string;
  'address_postal_code_check'?: string;
  'cvc_check'?: string;
};

export type payment_method_details_card_installments = {
  'plan'?: Record<string, any>;
};

export type payment_method_details_card_installments_plan = {
  'count'?: number;
  'interval'?: string;
  'type': string;
};

export type payment_method_details_card_network_token = {
  'used': boolean;
};

export type payment_method_details_card_present = {
  'amount_authorized'?: number;
  'brand'?: string;
  'brand_product'?: string;
  'capture_before'?: number;
  'cardholder_name'?: string;
  'country'?: string;
  'description'?: string;
  'emv_auth_data'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding'?: string;
  'generated_card'?: string;
  'incremental_authorization_supported': boolean;
  'issuer'?: string;
  'last4'?: string;
  'location'?: string;
  'network'?: string;
  'network_transaction_id'?: string;
  'offline'?: Record<string, any>;
  'overcapture_supported': boolean;
  'preferred_locales'?: string[];
  'read_method'?: string;
  'reader'?: string;
  'receipt'?: Record<string, any>;
  'wallet'?: payment_flows_private_payment_methods_card_present_common_wallet;
};

export type payment_method_details_card_present_offline = {
  'stored_at'?: number;
  'type'?: string;
};

export type payment_method_details_card_present_receipt = {
  'account_type'?: string;
  'application_cryptogram'?: string;
  'application_preferred_name'?: string;
  'authorization_code'?: string;
  'authorization_response_code'?: string;
  'cardholder_verification_method'?: string;
  'dedicated_file_name'?: string;
  'terminal_verification_results'?: string;
  'transaction_status_information'?: string;
};

export type payment_method_details_card_wallet = {
  'amex_express_checkout'?: payment_method_details_card_wallet_amex_express_checkout;
  'apple_pay'?: payment_method_details_card_wallet_apple_pay;
  'dynamic_last4'?: string;
  'google_pay'?: payment_method_details_card_wallet_google_pay;
  'link'?: payment_method_details_card_wallet_link;
  'masterpass'?: payment_method_details_card_wallet_masterpass;
  'samsung_pay'?: payment_method_details_card_wallet_samsung_pay;
  'type': string;
  'visa_checkout'?: payment_method_details_card_wallet_visa_checkout;
};

export type payment_method_details_card_wallet_amex_express_checkout = Record<string, any>;

export type payment_method_details_card_wallet_apple_pay = Record<string, any>;

export type payment_method_details_card_wallet_google_pay = Record<string, any>;

export type payment_method_details_card_wallet_link = Record<string, any>;

export type payment_method_details_card_wallet_masterpass = {
  'billing_address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'shipping_address'?: Record<string, any>;
};

export type payment_method_details_card_wallet_samsung_pay = Record<string, any>;

export type payment_method_details_card_wallet_visa_checkout = {
  'billing_address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'shipping_address'?: Record<string, any>;
};

export type payment_method_details_cashapp = {
  'buyer_id'?: string;
  'cashtag'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_crypto = {
  'buyer_address'?: string;
  'network'?: string;
  'token_currency'?: string;
  'transaction_hash'?: string;
};

export type payment_method_details_customer_balance = Record<string, any>;

export type payment_method_details_eps = {
  'bank'?: string;
  'verified_name'?: string;
};

export type payment_method_details_fpx = {
  'bank': string;
  'transaction_id'?: string;
};

export type payment_method_details_giropay = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'verified_name'?: string;
};

export type payment_method_details_grabpay = {
  'transaction_id'?: string;
};

export type payment_method_details_ideal = {
  'bank'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'transaction_id'?: string;
  'verified_name'?: string;
};

export type payment_method_details_interac_present = {
  'brand'?: string;
  'cardholder_name'?: string;
  'country'?: string;
  'description'?: string;
  'emv_auth_data'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding'?: string;
  'generated_card'?: string;
  'issuer'?: string;
  'last4'?: string;
  'location'?: string;
  'network'?: string;
  'network_transaction_id'?: string;
  'preferred_locales'?: string[];
  'read_method'?: string;
  'reader'?: string;
  'receipt'?: Record<string, any>;
};

export type payment_method_details_interac_present_receipt = {
  'account_type'?: string;
  'application_cryptogram'?: string;
  'application_preferred_name'?: string;
  'authorization_code'?: string;
  'authorization_response_code'?: string;
  'cardholder_verification_method'?: string;
  'dedicated_file_name'?: string;
  'terminal_verification_results'?: string;
  'transaction_status_information'?: string;
};

export type payment_method_details_kakao_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_klarna = {
  'location'?: string;
  'payer_details'?: Record<string, any>;
  'payment_method_category'?: string;
  'preferred_locale'?: string;
  'reader'?: string;
};

export type payment_method_details_konbini = {
  'store'?: Record<string, any>;
};

export type payment_method_details_konbini_store = {
  'chain'?: string;
};

export type payment_method_details_kr_card = {
  'brand'?: string;
  'buyer_id'?: string;
  'last4'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_link = {
  'country'?: string;
};

export type payment_method_details_mb_way = Record<string, any>;

export type payment_method_details_mobilepay = {
  'card'?: Record<string, any>;
};

export type payment_method_details_multibanco = {
  'entity'?: string;
  'reference'?: string;
};

export type payment_method_details_naver_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_nz_bank_account = {
  'account_holder_name'?: string;
  'bank_code': string;
  'bank_name': string;
  'branch_code': string;
  'expected_debit_date'?: string;
  'last4': string;
  'suffix'?: string;
};

export type payment_method_details_oxxo = {
  'number'?: string;
};

export type payment_method_details_p24 = {
  'bank'?: string;
  'reference'?: string;
  'verified_name'?: string;
};

export type payment_method_details_passthrough_card = {
  'brand'?: string;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'funding'?: string;
  'last4'?: string;
};

export type payment_method_details_pay_by_bank = Record<string, any>;

export type payment_method_details_payco = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_acss_debit = {
  'bank_name'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'institution_number'?: string;
  'last4'?: string;
  'mandate'?: string;
  'transit_number'?: string;
};

export type payment_method_details_payment_record_affirm = {
  'location'?: string;
  'reader'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_afterpay_clearpay = {
  'order_id'?: string;
  'reference'?: string;
};

export type payment_method_details_payment_record_alma = {
  'installments'?: payments_primitives_payment_records_resource_payment_method_alma_details_resource_installments;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_amazon_pay = {
  'funding'?: payments_primitives_payment_records_resource_payment_method_amazon_pay_details_resource_funding;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_bancontact = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_billie = {
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_bizum = {
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_blik = {
  'buyer_id'?: string;
};

export type payment_method_details_payment_record_boleto = {
  'tax_id'?: string;
};

export type payment_method_details_payment_record_cashapp = {
  'buyer_id'?: string;
  'cashtag'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_eps = {
  'bank'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_giropay = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_ideal = {
  'bank'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'transaction_id'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_kakao_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_klarna = {
  'location'?: string;
  'payer_details'?: Record<string, any>;
  'payment_method_category'?: string;
  'preferred_locale'?: string;
  'reader'?: string;
};

export type payment_method_details_payment_record_konbini = {
  'store'?: Record<string, any>;
};

export type payment_method_details_payment_record_link = {
  'country'?: string;
};

export type payment_method_details_payment_record_mb_way = Record<string, any>;

export type payment_method_details_payment_record_mobilepay = {
  'card'?: Record<string, any>;
};

export type payment_method_details_payment_record_multibanco = {
  'entity'?: string;
  'reference'?: string;
};

export type payment_method_details_payment_record_naver_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_oxxo = {
  'number'?: string;
};

export type payment_method_details_payment_record_p24 = {
  'bank'?: string;
  'reference'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_pay_by_bank = Record<string, any>;

export type payment_method_details_payment_record_payco = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_paynow = {
  'location'?: string;
  'reader'?: string;
  'reference'?: string;
};

export type payment_method_details_payment_record_payto = {
  'bsb_number'?: string;
  'last4'?: string;
  'mandate'?: string;
  'pay_id'?: string;
};

export type payment_method_details_payment_record_pix = {
  'bank_transaction_id'?: string;
  'mandate'?: string;
};

export type payment_method_details_payment_record_promptpay = {
  'reference'?: string;
};

export type payment_method_details_payment_record_revolut_pay = {
  'funding'?: payments_primitives_payment_records_resource_payment_method_revolut_pay_details_resource_funding;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_samsung_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_satispay = {
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_scalapay = {
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_sepa_debit = {
  'bank_code'?: string;
  'branch_code'?: string;
  'country'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: string;
};

export type payment_method_details_payment_record_sofort = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'country'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type payment_method_details_payment_record_swish = {
  'fingerprint'?: string;
  'payment_reference'?: string;
  'verified_phone_last4'?: string;
};

export type payment_method_details_payment_record_twint = {
  'mandate'?: string;
};

export type payment_method_details_payment_record_upi = {
  'vpa'?: string;
};

export type payment_method_details_payment_record_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: Record<string, any>;
  'payment_reference'?: string;
  'routing_number'?: string;
};

export type payment_method_details_payment_record_wechat_pay = {
  'fingerprint'?: string;
  'location'?: string;
  'reader'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_payment_record_zip = Record<string, any>;

export type payment_method_details_paynow = {
  'location'?: string;
  'reader'?: string;
  'reference'?: string;
};

export type payment_method_details_paypal = {
  'country'?: string;
  'payer_email'?: string;
  'payer_id'?: string;
  'payer_name'?: string;
  'seller_protection'?: Record<string, any>;
  'transaction_id'?: string;
};

export type payment_method_details_payto = {
  'bsb_number'?: string;
  'last4'?: string;
  'mandate'?: string;
  'pay_id'?: string;
};

export type payment_method_details_pix = {
  'bank_transaction_id'?: string;
  'mandate'?: string;
};

export type payment_method_details_promptpay = {
  'reference'?: string;
};

export type payment_method_details_revolut_pay = {
  'funding'?: revolut_pay_underlying_payment_method_funding_details;
  'transaction_id'?: string;
};

export type payment_method_details_samsung_pay = {
  'buyer_id'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_satispay = {
  'transaction_id'?: string;
};

export type payment_method_details_scalapay = {
  'transaction_id'?: string;
};

export type payment_method_details_sepa_debit = {
  'bank_code'?: string;
  'branch_code'?: string;
  'country'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: string;
};

export type payment_method_details_sofort = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'country'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type payment_method_details_stripe_account = Record<string, any>;

export type payment_method_details_sunbit = {
  'transaction_id'?: string;
};

export type payment_method_details_swish = {
  'fingerprint'?: string;
  'payment_reference'?: string;
  'verified_phone_last4'?: string;
};

export type payment_method_details_twint = {
  'mandate'?: string;
};

export type payment_method_details_upi = {
  'vpa'?: string;
};

export type payment_method_details_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'expected_debit_date'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate'?: Record<string, any>;
  'payment_reference'?: string;
  'routing_number'?: string;
};

export type payment_method_details_wechat = Record<string, any>;

export type payment_method_details_wechat_pay = {
  'fingerprint'?: string;
  'location'?: string;
  'reader'?: string;
  'transaction_id'?: string;
};

export type payment_method_details_zip = Record<string, any>;

export type payment_method_domain = {
  'amazon_pay': payment_method_domain_resource_payment_method_status;
  'apple_pay': payment_method_domain_resource_payment_method_status;
  'created': number;
  'domain_name': string;
  'enabled': boolean;
  'google_pay': payment_method_domain_resource_payment_method_status;
  'id': string;
  'klarna': payment_method_domain_resource_payment_method_status;
  'link': payment_method_domain_resource_payment_method_status;
  'livemode': boolean;
  'object': string;
  'paypal': payment_method_domain_resource_payment_method_status;
};

export type payment_method_domain_resource_payment_method_status = {
  'status': string;
  'status_details'?: payment_method_domain_resource_payment_method_status_details;
};

export type payment_method_domain_resource_payment_method_status_details = {
  'error_message': string;
};

export type payment_method_eps = {
  'bank'?: string;
};

export type payment_method_fpx = {
  'bank': string;
};

export type payment_method_giropay = Record<string, any>;

export type payment_method_grabpay = Record<string, any>;

export type payment_method_ideal = {
  'bank'?: string;
  'bic'?: string;
};

export type payment_method_interac_present = {
  'brand'?: string;
  'cardholder_name'?: string;
  'country'?: string;
  'description'?: string;
  'exp_month': number;
  'exp_year': number;
  'fingerprint'?: string;
  'funding'?: string;
  'issuer'?: string;
  'last4'?: string;
  'networks'?: Record<string, any>;
  'preferred_locales'?: string[];
  'read_method'?: string;
};

export type payment_method_kakao_pay = Record<string, any>;

export type payment_method_klarna = {
  'dob'?: Record<string, any>;
};

export type payment_method_konbini = Record<string, any>;

export type payment_method_kr_card = {
  'brand'?: string;
  'last4'?: string;
};

export type payment_method_link = {
  'email'?: string;
};

export type payment_method_mb_way = Record<string, any>;

export type payment_method_mobilepay = Record<string, any>;

export type payment_method_multibanco = Record<string, any>;

export type payment_method_naver_pay = {
  'buyer_id'?: string;
  'funding': string;
};

export type payment_method_nz_bank_account = {
  'account_holder_name'?: string;
  'bank_code': string;
  'bank_name': string;
  'branch_code': string;
  'last4': string;
  'suffix'?: string;
};

export type payment_method_options_affirm = {
  'capture_method'?: string;
  'preferred_locale'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_afterpay_clearpay = {
  'capture_method'?: string;
  'reference'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_alipay = {
  'setup_future_usage'?: string;
};

export type payment_method_options_alma = {
  'capture_method'?: string;
};

export type payment_method_options_amazon_pay = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_bancontact = {
  'preferred_language': string;
  'setup_future_usage'?: string;
};

export type payment_method_options_billie = {
  'capture_method'?: string;
};

export type payment_method_options_bizum = Record<string, any>;

export type payment_method_options_boleto = {
  'expires_after_days': number;
  'setup_future_usage'?: string;
};

export type payment_method_options_card_installments = {
  'available_plans'?: payment_method_details_card_installments_plan[];
  'enabled': boolean;
  'plan'?: Record<string, any>;
};

export type payment_method_options_card_mandate_options = {
  'amount': number;
  'amount_type': string;
  'description'?: string;
  'end_date'?: number;
  'interval': string;
  'interval_count'?: number;
  'reference': string;
  'start_date': number;
  'supported_types'?: string[];
};

export type payment_method_options_card_present = {
  'capture_method'?: string;
  'request_extended_authorization'?: boolean;
  'request_incremental_authorization_support'?: boolean;
  'routing'?: payment_method_options_card_present_routing;
};

export type payment_method_options_card_present_routing = {
  'requested_priority'?: string;
};

export type payment_method_options_cashapp = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_crypto = {
  'setup_future_usage'?: string;
};

export type payment_method_options_customer_balance = {
  'bank_transfer'?: payment_method_options_customer_balance_bank_transfer;
  'funding_type'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_customer_balance_bank_transfer = {
  'eu_bank_transfer'?: payment_method_options_customer_balance_eu_bank_account;
  'requested_address_types'?: string[];
  'type'?: string;
};

export type payment_method_options_customer_balance_eu_bank_account = {
  'country': string;
};

export type payment_method_options_fpx = {
  'setup_future_usage'?: string;
};

export type payment_method_options_giropay = {
  'setup_future_usage'?: string;
};

export type payment_method_options_grabpay = {
  'setup_future_usage'?: string;
};

export type payment_method_options_ideal = {
  'setup_future_usage'?: string;
};

export type payment_method_options_interac_present = Record<string, any>;

export type payment_method_options_klarna = {
  'capture_method'?: string;
  'preferred_locale'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_konbini = {
  'confirmation_number'?: string;
  'expires_after_days'?: number;
  'expires_at'?: number;
  'product_description'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_kr_card = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_mandate_options_pix = {
  'amount'?: number;
  'amount_includes_iof'?: string;
  'amount_type'?: string;
  'currency'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
  'reference'?: string;
  'start_date'?: string;
};

export type payment_method_options_mandate_options_upi = {
  'amount'?: number;
  'amount_type'?: string;
  'description'?: string;
  'end_date'?: number;
};

export type payment_method_options_mb_way = {
  'setup_future_usage'?: string;
};

export type payment_method_options_multibanco = {
  'setup_future_usage'?: string;
};

export type payment_method_options_oxxo = {
  'expires_after_days': number;
  'setup_future_usage'?: string;
};

export type payment_method_options_p24 = {
  'setup_future_usage'?: string;
};

export type payment_method_options_pay_by_bank = Record<string, any>;

export type payment_method_options_paynow = {
  'setup_future_usage'?: string;
};

export type payment_method_options_paypal = {
  'capture_method'?: string;
  'preferred_locale'?: string;
  'reference'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_pix = {
  'amount_includes_iof'?: string;
  'expires_after_seconds'?: number;
  'expires_at'?: number;
  'mandate_options'?: payment_method_options_mandate_options_pix;
  'setup_future_usage'?: string;
};

export type payment_method_options_promptpay = {
  'setup_future_usage'?: string;
};

export type payment_method_options_revolut_pay = {
  'capture_method'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_satispay = {
  'capture_method'?: string;
};

export type payment_method_options_scalapay = {
  'capture_method'?: string;
};

export type payment_method_options_sofort = {
  'preferred_language'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_twint = {
  'setup_future_usage'?: string;
};

export type payment_method_options_upi = {
  'setup_future_usage'?: string;
};

export type payment_method_options_us_bank_account_mandate_options = {
  'collection_method'?: string;
};

export type payment_method_options_wechat_pay = {
  'app_id'?: string;
  'client'?: string;
  'setup_future_usage'?: string;
};

export type payment_method_options_zip = {
  'setup_future_usage'?: string;
};

export type payment_method_oxxo = Record<string, any>;

export type payment_method_p24 = {
  'bank'?: string;
};

export type payment_method_pay_by_bank = Record<string, any>;

export type payment_method_payco = Record<string, any>;

export type payment_method_paynow = Record<string, any>;

export type payment_method_paypal = {
  'country'?: string;
  'payer_email'?: string;
  'payer_id'?: string;
};

export type payment_method_payto = {
  'bsb_number'?: string;
  'last4'?: string;
  'pay_id'?: string;
};

export type payment_method_pix = Record<string, any>;

export type payment_method_promptpay = Record<string, any>;

export type payment_method_revolut_pay = Record<string, any>;

export type payment_method_samsung_pay = Record<string, any>;

export type payment_method_satispay = Record<string, any>;

export type payment_method_scalapay = Record<string, any>;

export type payment_method_sepa_debit = {
  'bank_code'?: string;
  'branch_code'?: string;
  'country'?: string;
  'fingerprint'?: string;
  'generated_from'?: Record<string, any>;
  'last4'?: string;
};

export type payment_method_sofort = {
  'country'?: string;
};

export type payment_method_sunbit = Record<string, any>;

export type payment_method_swish = Record<string, any>;

export type payment_method_twint = Record<string, any>;

export type payment_method_upi = {
  'vpa'?: string;
};

export type payment_method_us_bank_account = {
  'account_holder_type'?: string;
  'account_type'?: string;
  'bank_name'?: string;
  'financial_connections_account'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'networks'?: Record<string, any>;
  'routing_number'?: string;
  'status_details'?: Record<string, any>;
};

export type payment_method_us_bank_account_blocked = {
  'network_code'?: string;
  'reason'?: string;
};

export type payment_method_us_bank_account_status_details = {
  'blocked'?: payment_method_us_bank_account_blocked;
};

export type payment_method_wechat_pay = Record<string, any>;

export type payment_method_zip = Record<string, any>;

export type payment_pages_checkout_session_adaptive_pricing = {
  'enabled': boolean;
};

export type payment_pages_checkout_session_after_expiration = {
  'recovery'?: Record<string, any>;
};

export type payment_pages_checkout_session_after_expiration_recovery = {
  'allow_promotion_codes': boolean;
  'enabled': boolean;
  'expires_at'?: number;
  'url'?: string;
};

export type payment_pages_checkout_session_automatic_tax = {
  'enabled': boolean;
  'liability'?: Record<string, any>;
  'provider'?: string;
  'status'?: string;
};

export type payment_pages_checkout_session_branding_settings = {
  'background_color': string;
  'border_style': string;
  'button_color': string;
  'display_name': string;
  'font_family': string;
  'icon'?: Record<string, any>;
  'logo'?: Record<string, any>;
};

export type payment_pages_checkout_session_branding_settings_icon = {
  'file'?: string;
  'type': string;
  'url'?: string;
};

export type payment_pages_checkout_session_branding_settings_logo = {
  'file'?: string;
  'type': string;
  'url'?: string;
};

export type payment_pages_checkout_session_business_name = {
  'enabled': boolean;
  'optional': boolean;
};

export type payment_pages_checkout_session_checkout_address_details = {
  'address': address;
  'name': string;
};

export type payment_pages_checkout_session_collected_information = {
  'business_name'?: string;
  'individual_name'?: string;
  'shipping_details'?: Record<string, any>;
};

export type payment_pages_checkout_session_consent = {
  'promotions'?: string;
  'terms_of_service'?: string;
};

export type payment_pages_checkout_session_consent_collection = {
  'payment_method_reuse_agreement'?: Record<string, any>;
  'promotions'?: string;
  'terms_of_service'?: string;
};

export type payment_pages_checkout_session_currency_conversion = {
  'amount_subtotal': number;
  'amount_total': number;
  'fx_rate': string;
  'source_currency': string;
};

export type payment_pages_checkout_session_custom_fields = {
  'dropdown'?: payment_pages_checkout_session_custom_fields_dropdown;
  'key': string;
  'label': payment_pages_checkout_session_custom_fields_label;
  'numeric'?: payment_pages_checkout_session_custom_fields_numeric;
  'optional': boolean;
  'text'?: payment_pages_checkout_session_custom_fields_text;
  'type': string;
};

export type payment_pages_checkout_session_custom_fields_dropdown = {
  'default_value'?: string;
  'options': payment_pages_checkout_session_custom_fields_option[];
  'value'?: string;
};

export type payment_pages_checkout_session_custom_fields_label = {
  'custom'?: string;
  'type': string;
};

export type payment_pages_checkout_session_custom_fields_numeric = {
  'default_value'?: string;
  'maximum_length'?: number;
  'minimum_length'?: number;
  'value'?: string;
};

export type payment_pages_checkout_session_custom_fields_option = {
  'label': string;
  'value': string;
};

export type payment_pages_checkout_session_custom_fields_text = {
  'default_value'?: string;
  'maximum_length'?: number;
  'minimum_length'?: number;
  'value'?: string;
};

export type payment_pages_checkout_session_custom_text = {
  'after_submit'?: Record<string, any>;
  'shipping_address'?: Record<string, any>;
  'submit'?: Record<string, any>;
  'terms_of_service_acceptance'?: Record<string, any>;
};

export type payment_pages_checkout_session_custom_text_position = {
  'message': string;
};

export type payment_pages_checkout_session_customer_details = {
  'address'?: Record<string, any>;
  'business_name'?: string;
  'email'?: string;
  'individual_name'?: string;
  'name'?: string;
  'phone'?: string;
  'tax_exempt'?: string;
  'tax_ids'?: payment_pages_checkout_session_tax_id[];
};

export type payment_pages_checkout_session_discount = {
  'coupon'?: Record<string, any>;
  'promotion_code'?: Record<string, any>;
};

export type payment_pages_checkout_session_individual_name = {
  'enabled': boolean;
  'optional': boolean;
};

export type payment_pages_checkout_session_invoice_creation = {
  'enabled': boolean;
  'invoice_data': payment_pages_checkout_session_invoice_settings;
};

export type payment_pages_checkout_session_invoice_settings = {
  'account_tax_ids'?: Record<string, any>[];
  'custom_fields'?: invoice_setting_custom_field[];
  'description'?: string;
  'footer'?: string;
  'issuer'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'rendering_options'?: Record<string, any>;
};

export type payment_pages_checkout_session_managed_payments = {
  'enabled': boolean;
};

export type payment_pages_checkout_session_name_collection = {
  'business'?: payment_pages_checkout_session_business_name;
  'individual'?: payment_pages_checkout_session_individual_name;
};

export type payment_pages_checkout_session_optional_item = {
  'adjustable_quantity'?: Record<string, any>;
  'price': string;
  'quantity': number;
};

export type payment_pages_checkout_session_optional_item_adjustable_quantity = {
  'enabled': boolean;
  'maximum'?: number;
  'minimum'?: number;
};

export type payment_pages_checkout_session_payment_method_reuse_agreement = {
  'position': string;
};

export type payment_pages_checkout_session_permissions = {
  'update_shipping_details'?: string;
};

export type payment_pages_checkout_session_phone_number_collection = {
  'enabled': boolean;
};

export type payment_pages_checkout_session_saved_payment_method_options = {
  'allow_redisplay_filters'?: string[];
  'payment_method_remove'?: string;
  'payment_method_save'?: string;
};

export type payment_pages_checkout_session_shipping_address_collection = {
  'allowed_countries': string[];
};

export type payment_pages_checkout_session_shipping_cost = {
  'amount_subtotal': number;
  'amount_tax': number;
  'amount_total': number;
  'shipping_rate'?: Record<string, any>;
  'taxes'?: line_items_tax_amount[];
};

export type payment_pages_checkout_session_shipping_option = {
  'shipping_amount': number;
  'shipping_rate': Record<string, any>;
};

export type payment_pages_checkout_session_tax_id = {
  'type': string;
  'value'?: string;
};

export type payment_pages_checkout_session_tax_id_collection = {
  'enabled': boolean;
  'required': string;
};

export type payment_pages_checkout_session_total_details = {
  'amount_discount': number;
  'amount_shipping'?: number;
  'amount_tax': number;
  'breakdown'?: payment_pages_checkout_session_total_details_resource_breakdown;
};

export type payment_pages_checkout_session_total_details_resource_breakdown = {
  'discounts': line_items_discount_amount[];
  'taxes': line_items_tax_amount[];
};

export type payment_pages_private_card_payment_method_options_resource_restrictions = {
  'brands_blocked'?: string[];
};

export type payment_record = {
  'amount': payments_primitives_payment_records_resource_amount;
  'amount_authorized': payments_primitives_payment_records_resource_amount;
  'amount_canceled': payments_primitives_payment_records_resource_amount;
  'amount_failed': payments_primitives_payment_records_resource_amount;
  'amount_guaranteed': payments_primitives_payment_records_resource_amount;
  'amount_refunded': payments_primitives_payment_records_resource_amount;
  'amount_requested': payments_primitives_payment_records_resource_amount;
  'application'?: string;
  'created': number;
  'customer_details'?: Record<string, any>;
  'customer_presence'?: string;
  'description'?: string;
  'id': string;
  'latest_payment_attempt_record'?: string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'payment_method_details'?: Record<string, any>;
  'processor_details': payments_primitives_payment_records_resource_processor_details;
  'reported_by': string;
  'shipping_details'?: Record<string, any>;
};

export type payment_source = Record<string, any>;

export type payments_primitives_payment_records_resource_address = {
  'city'?: string;
  'country'?: string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
};

export type payments_primitives_payment_records_resource_amount = {
  'currency': string;
  'value': number;
};

export type payments_primitives_payment_records_resource_billing_details = {
  'address': payments_primitives_payment_records_resource_address;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
};

export type payments_primitives_payment_records_resource_customer_details = {
  'customer'?: string;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_alma_details_resource_installments = {
  'count': number;
};

export type payments_primitives_payment_records_resource_payment_method_amazon_pay_details_resource_funding = {
  'card'?: payments_primitives_payment_records_resource_payment_method_amazon_pay_details_resource_funding_resource_funding_card;
  'type'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_amazon_pay_details_resource_funding_resource_funding_card = {
  'brand'?: string;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'funding'?: string;
  'last4'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details = {
  'authorization_code'?: string;
  'brand'?: string;
  'capture_before'?: number;
  'checks'?: Record<string, any>;
  'country'?: string;
  'description'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'fingerprint'?: string;
  'funding'?: string;
  'iin'?: string;
  'installments'?: Record<string, any>;
  'issuer'?: string;
  'last4'?: string;
  'network'?: string;
  'network_advice_code'?: string;
  'network_decline_code'?: string;
  'network_token'?: Record<string, any>;
  'network_transaction_id'?: string;
  'stored_credential_usage'?: string;
  'three_d_secure'?: Record<string, any>;
  'wallet'?: Record<string, any>;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_checks = {
  'address_line1_check'?: string;
  'address_postal_code_check'?: string;
  'cvc_check'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_installment_plan = {
  'count'?: number;
  'interval'?: string;
  'type': string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_installments = {
  'plan'?: Record<string, any>;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_network_token = {
  'used': boolean;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_three_d_secure = {
  'authentication_flow'?: string;
  'cryptogram'?: string;
  'electronic_commerce_indicator'?: string;
  'exemption_indicator'?: string;
  'exemption_indicator_applied'?: boolean;
  'result'?: string;
  'result_reason'?: string;
  'version'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_wallet = {
  'apple_pay'?: payments_primitives_payment_records_resource_payment_method_card_details_resource_wallet_resource_apple_pay;
  'dynamic_last4'?: string;
  'google_pay'?: payments_primitives_payment_records_resource_payment_method_card_details_resource_wallet_resource_google_pay;
  'type': string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_wallet_resource_apple_pay = {
  'type': string;
};

export type payments_primitives_payment_records_resource_payment_method_card_details_resource_wallet_resource_google_pay = Record<string, any>;

export type payments_primitives_payment_records_resource_payment_method_custom_details = {
  'display_name': string;
  'type'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_details = {
  'ach_credit_transfer'?: payment_method_details_ach_credit_transfer;
  'ach_debit'?: payment_method_details_ach_debit;
  'acss_debit'?: payment_method_details_payment_record_acss_debit;
  'affirm'?: payment_method_details_payment_record_affirm;
  'afterpay_clearpay'?: payment_method_details_payment_record_afterpay_clearpay;
  'alipay'?: payment_flows_private_payment_methods_alipay_details;
  'alma'?: payment_method_details_payment_record_alma;
  'amazon_pay'?: payment_method_details_payment_record_amazon_pay;
  'au_becs_debit'?: payment_method_details_au_becs_debit;
  'bacs_debit'?: payment_method_details_bacs_debit;
  'bancontact'?: payment_method_details_payment_record_bancontact;
  'billie'?: payment_method_details_payment_record_billie;
  'billing_details'?: Record<string, any>;
  'bizum'?: payment_method_details_payment_record_bizum;
  'blik'?: payment_method_details_payment_record_blik;
  'boleto'?: payment_method_details_payment_record_boleto;
  'card'?: payments_primitives_payment_records_resource_payment_method_card_details;
  'card_present'?: payment_method_details_card_present;
  'cashapp'?: payment_method_details_payment_record_cashapp;
  'crypto'?: payment_method_details_crypto;
  'custom'?: payments_primitives_payment_records_resource_payment_method_custom_details;
  'customer_balance'?: payment_method_details_customer_balance;
  'eps'?: payment_method_details_payment_record_eps;
  'fpx'?: payment_method_details_fpx;
  'giropay'?: payment_method_details_payment_record_giropay;
  'grabpay'?: payment_method_details_grabpay;
  'ideal'?: payment_method_details_payment_record_ideal;
  'interac_present'?: payment_method_details_interac_present;
  'kakao_pay'?: payment_method_details_payment_record_kakao_pay;
  'klarna'?: payment_method_details_payment_record_klarna;
  'konbini'?: payment_method_details_payment_record_konbini;
  'kr_card'?: payment_method_details_kr_card;
  'link'?: payment_method_details_payment_record_link;
  'mb_way'?: payment_method_details_payment_record_mb_way;
  'mobilepay'?: payment_method_details_payment_record_mobilepay;
  'multibanco'?: payment_method_details_payment_record_multibanco;
  'naver_pay'?: payment_method_details_payment_record_naver_pay;
  'nz_bank_account'?: payment_method_details_nz_bank_account;
  'oxxo'?: payment_method_details_payment_record_oxxo;
  'p24'?: payment_method_details_payment_record_p24;
  'pay_by_bank'?: payment_method_details_payment_record_pay_by_bank;
  'payco'?: payment_method_details_payment_record_payco;
  'payment_method'?: string;
  'paynow'?: payment_method_details_payment_record_paynow;
  'paypal'?: payment_method_details_paypal;
  'payto'?: payment_method_details_payment_record_payto;
  'pix'?: payment_method_details_payment_record_pix;
  'promptpay'?: payment_method_details_payment_record_promptpay;
  'revolut_pay'?: payment_method_details_payment_record_revolut_pay;
  'samsung_pay'?: payment_method_details_payment_record_samsung_pay;
  'satispay'?: payment_method_details_payment_record_satispay;
  'scalapay'?: payment_method_details_payment_record_scalapay;
  'sepa_debit'?: payment_method_details_payment_record_sepa_debit;
  'sofort'?: payment_method_details_payment_record_sofort;
  'stripe_account'?: payment_method_details_stripe_account;
  'sunbit'?: payment_method_details_sunbit;
  'swish'?: payment_method_details_payment_record_swish;
  'twint'?: payment_method_details_payment_record_twint;
  'type': string;
  'upi'?: payment_method_details_payment_record_upi;
  'us_bank_account'?: payment_method_details_payment_record_us_bank_account;
  'wechat'?: payment_method_details_wechat;
  'wechat_pay'?: payment_method_details_payment_record_wechat_pay;
  'zip'?: payment_method_details_payment_record_zip;
};

export type payments_primitives_payment_records_resource_payment_method_klarna_details_resource_payer_details = {
  'address'?: Record<string, any>;
};

export type payments_primitives_payment_records_resource_payment_method_klarna_details_resource_payer_details_resource_payer_details_address = {
  'country'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_konbini_details_resource_store = {
  'chain'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_mobilepay_details_resource_card = {
  'brand'?: string;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'last4'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_revolut_pay_details_resource_funding = {
  'card'?: payments_primitives_payment_records_resource_payment_method_revolut_pay_details_resource_funding_resource_funding_card;
  'type'?: string;
};

export type payments_primitives_payment_records_resource_payment_method_revolut_pay_details_resource_funding_resource_funding_card = {
  'brand'?: string;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'funding'?: string;
  'last4'?: string;
};

export type payments_primitives_payment_records_resource_processor_details = {
  'custom'?: payments_primitives_payment_records_resource_processor_details_resource_custom_details;
  'type': string;
};

export type payments_primitives_payment_records_resource_processor_details_resource_custom_details = {
  'payment_reference'?: string;
};

export type payments_primitives_payment_records_resource_shipping_details = {
  'address': payments_primitives_payment_records_resource_address;
  'name'?: string;
  'phone'?: string;
};

export type payout = {
  'amount': number;
  'application_fee'?: Record<string, any>;
  'application_fee_amount'?: number;
  'arrival_date': number;
  'automatic': boolean;
  'balance_transaction'?: Record<string, any>;
  'created': number;
  'currency': string;
  'description'?: string;
  'destination'?: Record<string, any>;
  'failure_balance_transaction'?: Record<string, any>;
  'failure_code'?: string;
  'failure_message'?: string;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'method': string;
  'object': string;
  'original_payout'?: Record<string, any>;
  'payout_method'?: string;
  'reconciliation_status': string;
  'reversed_by'?: Record<string, any>;
  'source_type': string;
  'statement_descriptor'?: string;
  'status': string;
  'trace_id'?: Record<string, any>;
  'type': string;
};

export type payouts_trace_id = {
  'status': string;
  'value'?: string;
};

export type paypal_seller_protection = {
  'dispute_categories'?: string[];
  'status': string;
};

export type person = {
  'account': string;
  'additional_tos_acceptances'?: person_additional_tos_acceptances;
  'address'?: address;
  'address_kana'?: Record<string, any>;
  'address_kanji'?: Record<string, any>;
  'created': number;
  'dob'?: legal_entity_dob;
  'email'?: string;
  'first_name'?: string;
  'first_name_kana'?: string;
  'first_name_kanji'?: string;
  'full_name_aliases'?: string[];
  'future_requirements'?: Record<string, any>;
  'gender'?: string;
  'id': string;
  'id_number_provided'?: boolean;
  'id_number_secondary_provided'?: boolean;
  'last_name'?: string;
  'last_name_kana'?: string;
  'last_name_kanji'?: string;
  'maiden_name'?: string;
  'metadata'?: Record<string, any>;
  'nationality'?: string;
  'object': string;
  'phone'?: string;
  'political_exposure'?: string;
  'registered_address'?: address;
  'relationship'?: person_relationship;
  'requirements'?: Record<string, any>;
  'ssn_last_4_provided'?: boolean;
  'us_cfpb_data'?: Record<string, any>;
  'verification'?: legal_entity_person_verification;
};

export type person_additional_tos_acceptance = {
  'date'?: number;
  'ip'?: string;
  'user_agent'?: string;
};

export type person_additional_tos_acceptances = {
  'account'?: Record<string, any>;
};

export type person_ethnicity_details = {
  'ethnicity'?: string[];
  'ethnicity_other'?: string;
};

export type person_future_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'currently_due': string[];
  'errors': account_requirements_error[];
  'eventually_due': string[];
  'past_due': string[];
  'pending_verification': string[];
};

export type person_race_details = {
  'race'?: string[];
  'race_other'?: string;
};

export type person_relationship = {
  'authorizer'?: boolean;
  'director'?: boolean;
  'executive'?: boolean;
  'legal_guardian'?: boolean;
  'owner'?: boolean;
  'percent_ownership'?: number;
  'representative'?: boolean;
  'title'?: string;
};

export type person_requirements = {
  'alternatives'?: account_requirements_alternative[];
  'currently_due': string[];
  'errors': account_requirements_error[];
  'eventually_due': string[];
  'past_due': string[];
  'pending_verification': string[];
};

export type person_us_cfpb_data = {
  'ethnicity_details'?: Record<string, any>;
  'race_details'?: Record<string, any>;
  'self_identified_gender'?: string;
};

export type plan = {
  'active': boolean;
  'amount'?: number;
  'amount_decimal'?: string;
  'billing_scheme': string;
  'created': number;
  'currency': string;
  'id': string;
  'interval': string;
  'interval_count': number;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'meter'?: string;
  'nickname'?: string;
  'object': string;
  'product'?: Record<string, any>;
  'tiers'?: plan_tier[];
  'tiers_mode'?: string;
  'transform_usage'?: Record<string, any>;
  'trial_period_days'?: number;
  'usage_type': string;
};

export type plan_tier = {
  'flat_amount'?: number;
  'flat_amount_decimal'?: string;
  'unit_amount'?: number;
  'unit_amount_decimal'?: string;
  'up_to'?: number;
};

export type platform_earning_fee_source = {
  'charge'?: string;
  'payout'?: string;
  'type': string;
};

export type portal_business_profile = {
  'headline'?: string;
  'privacy_policy_url'?: string;
  'terms_of_service_url'?: string;
};

export type portal_customer_update = {
  'allowed_updates': string[];
  'enabled': boolean;
};

export type portal_features = {
  'customer_update': portal_customer_update;
  'invoice_history': portal_invoice_list;
  'payment_method_update': portal_payment_method_update;
  'subscription_cancel': portal_subscription_cancel;
  'subscription_update': portal_subscription_update;
};

export type portal_flows_after_completion_hosted_confirmation = {
  'custom_message'?: string;
};

export type portal_flows_after_completion_redirect = {
  'return_url': string;
};

export type portal_flows_coupon_offer = {
  'coupon': string;
};

export type portal_flows_flow = {
  'after_completion': portal_flows_flow_after_completion;
  'subscription_cancel'?: Record<string, any>;
  'subscription_update'?: Record<string, any>;
  'subscription_update_confirm'?: Record<string, any>;
  'type': string;
};

export type portal_flows_flow_after_completion = {
  'hosted_confirmation'?: Record<string, any>;
  'redirect'?: Record<string, any>;
  'type': string;
};

export type portal_flows_flow_subscription_cancel = {
  'retention'?: Record<string, any>;
  'subscription': string;
};

export type portal_flows_flow_subscription_update = {
  'subscription': string;
};

export type portal_flows_flow_subscription_update_confirm = {
  'discounts'?: portal_flows_subscription_update_confirm_discount[];
  'items': portal_flows_subscription_update_confirm_item[];
  'subscription': string;
};

export type portal_flows_retention = {
  'coupon_offer'?: Record<string, any>;
  'type': string;
};

export type portal_flows_subscription_update_confirm_discount = {
  'coupon'?: string;
  'promotion_code'?: string;
};

export type portal_flows_subscription_update_confirm_item = {
  'id'?: string;
  'price'?: string;
  'quantity'?: number;
};

export type portal_invoice_list = {
  'enabled': boolean;
};

export type portal_login_page = {
  'enabled': boolean;
  'url'?: string;
};

export type portal_payment_method_update = {
  'enabled': boolean;
  'payment_method_configuration'?: string;
};

export type portal_resource_schedule_update_at_period_end = {
  'conditions': portal_resource_schedule_update_at_period_end_condition[];
};

export type portal_resource_schedule_update_at_period_end_condition = {
  'type': string;
};

export type portal_subscription_cancel = {
  'cancellation_reason': portal_subscription_cancellation_reason;
  'enabled': boolean;
  'mode': string;
  'proration_behavior': string;
};

export type portal_subscription_cancellation_reason = {
  'enabled': boolean;
  'options': string[];
};

export type portal_subscription_update = {
  'billing_cycle_anchor'?: string;
  'default_allowed_updates': string[];
  'enabled': boolean;
  'products'?: portal_subscription_update_product[];
  'proration_behavior': string;
  'schedule_at_period_end': portal_resource_schedule_update_at_period_end;
  'trial_update_behavior': string;
};

export type portal_subscription_update_product = {
  'adjustable_quantity': portal_subscription_update_product_adjustable_quantity;
  'prices': string[];
  'product': string;
};

export type portal_subscription_update_product_adjustable_quantity = {
  'enabled': boolean;
  'maximum'?: number;
  'minimum': number;
};

export type price = {
  'active': boolean;
  'billing_scheme': string;
  'created': number;
  'currency': string;
  'currency_options'?: Record<string, any>;
  'custom_unit_amount'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'lookup_key'?: string;
  'metadata': Record<string, any>;
  'nickname'?: string;
  'object': string;
  'product': Record<string, any>;
  'recurring'?: Record<string, any>;
  'tax_behavior'?: string;
  'tiers'?: price_tier[];
  'tiers_mode'?: string;
  'transform_quantity'?: Record<string, any>;
  'type': string;
  'unit_amount'?: number;
  'unit_amount_decimal'?: string;
};

export type price_tier = {
  'flat_amount'?: number;
  'flat_amount_decimal'?: string;
  'unit_amount'?: number;
  'unit_amount_decimal'?: string;
  'up_to'?: number;
};

export type product = {
  'active': boolean;
  'created': number;
  'default_price'?: Record<string, any>;
  'description'?: string;
  'id': string;
  'images': string[];
  'livemode': boolean;
  'marketing_features': product_marketing_feature[];
  'metadata': Record<string, any>;
  'name': string;
  'object': string;
  'package_dimensions'?: Record<string, any>;
  'shippable'?: boolean;
  'statement_descriptor'?: string;
  'tax_code'?: Record<string, any>;
  'unit_label'?: string;
  'updated': number;
  'url'?: string;
};

export type product_feature = {
  'entitlement_feature': entitlements.feature;
  'id': string;
  'livemode': boolean;
  'object': string;
};

export type product_marketing_feature = {
  'name'?: string;
};

export type promotion_code = {
  'active': boolean;
  'code': string;
  'created': number;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'expires_at'?: number;
  'id': string;
  'livemode': boolean;
  'max_redemptions'?: number;
  'metadata'?: Record<string, any>;
  'object': string;
  'promotion': promotion_codes_resource_promotion;
  'restrictions': promotion_codes_resource_restrictions;
  'times_redeemed': number;
};

export type promotion_code_currency_option = {
  'minimum_amount': number;
};

export type promotion_codes_resource_promotion = {
  'coupon'?: Record<string, any>;
  'type': string;
};

export type promotion_codes_resource_restrictions = {
  'currency_options'?: Record<string, any>;
  'first_time_transaction': boolean;
  'minimum_amount'?: number;
  'minimum_amount_currency'?: string;
};

export type proration_details = {
  'credited_items'?: Record<string, any>;
  'discount_amounts': discounts_resource_discount_amount[];
};

export type quote = {
  'amount_subtotal': number;
  'amount_total': number;
  'application'?: Record<string, any>;
  'application_fee_amount'?: number;
  'application_fee_percent'?: number;
  'automatic_tax': quotes_resource_automatic_tax;
  'collection_method': string;
  'computed': quotes_resource_computed;
  'created': number;
  'currency'?: string;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'default_tax_rates'?: Record<string, any>[];
  'description'?: string;
  'discounts': Record<string, any>[];
  'expires_at': number;
  'footer'?: string;
  'from_quote'?: Record<string, any>;
  'header'?: string;
  'id': string;
  'invoice'?: Record<string, any>;
  'invoice_settings': invoice_setting_quote_setting;
  'line_items'?: {
    'data': item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'metadata': Record<string, any>;
  'number'?: string;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'status': string;
  'status_transitions': quotes_resource_status_transitions;
  'subscription'?: Record<string, any>;
  'subscription_data': quotes_resource_subscription_data_subscription_data;
  'subscription_schedule'?: Record<string, any>;
  'test_clock'?: Record<string, any>;
  'total_details': quotes_resource_total_details;
  'transfer_data'?: Record<string, any>;
};

export type quotes_resource_automatic_tax = {
  'enabled': boolean;
  'liability'?: Record<string, any>;
  'provider'?: string;
  'status'?: string;
};

export type quotes_resource_computed = {
  'recurring'?: Record<string, any>;
  'upfront': quotes_resource_upfront;
};

export type quotes_resource_from_quote = {
  'is_revision': boolean;
  'quote': Record<string, any>;
};

export type quotes_resource_recurring = {
  'amount_subtotal': number;
  'amount_total': number;
  'interval': string;
  'interval_count': number;
  'total_details': quotes_resource_total_details;
};

export type quotes_resource_status_transitions = {
  'accepted_at'?: number;
  'canceled_at'?: number;
  'finalized_at'?: number;
};

export type quotes_resource_subscription_data_billing_mode = {
  'flexible'?: subscriptions_resource_billing_mode_flexible;
  'type': string;
};

export type quotes_resource_subscription_data_subscription_data = {
  'billing_mode': quotes_resource_subscription_data_billing_mode;
  'description'?: string;
  'effective_date'?: number;
  'metadata'?: Record<string, any>;
  'trial_period_days'?: number;
};

export type quotes_resource_total_details = {
  'amount_discount': number;
  'amount_shipping'?: number;
  'amount_tax': number;
  'breakdown'?: quotes_resource_total_details_resource_breakdown;
};

export type quotes_resource_total_details_resource_breakdown = {
  'discounts': line_items_discount_amount[];
  'taxes': line_items_tax_amount[];
};

export type quotes_resource_transfer_data = {
  'amount'?: number;
  'amount_percent'?: number;
  'destination': Record<string, any>;
};

export type quotes_resource_upfront = {
  'amount_subtotal': number;
  'amount_total': number;
  'line_items'?: {
    'data': item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'total_details': quotes_resource_total_details;
};

export type radar.early_fraud_warning = {
  'actionable': boolean;
  'charge': Record<string, any>;
  'created': number;
  'fraud_type': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'payment_intent'?: Record<string, any>;
};

export type radar.payment_evaluation = {
  'client_device_metadata_details'?: insights_resources_payment_evaluation_client_device_metadata;
  'created_at': number;
  'customer_details'?: insights_resources_payment_evaluation_customer_details;
  'events': insights_resources_payment_evaluation_event[];
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'outcome'?: Record<string, any>;
  'payment_details'?: insights_resources_payment_evaluation_payment_details;
  'recommended_action': string;
  'signals': insights_resources_payment_evaluation_signals;
};

export type radar.value_list = {
  'alias': string;
  'created': number;
  'created_by': string;
  'id': string;
  'item_type': string;
  'list_items': {
    'data': radar.value_list_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'metadata': Record<string, any>;
  'name': string;
  'object': string;
};

export type radar.value_list_item = {
  'created': number;
  'created_by': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'value': string;
  'value_list': string;
};

export type radar_radar_options = {
  'session'?: string;
};

export type radar_review_resource_location = {
  'city'?: string;
  'country'?: string;
  'latitude'?: number;
  'longitude'?: number;
  'region'?: string;
};

export type radar_review_resource_session = {
  'browser'?: string;
  'device'?: string;
  'platform'?: string;
  'version'?: string;
};

export type received_payment_method_details_financial_account = {
  'id': string;
  'network': string;
};

export type recurring = {
  'interval': string;
  'interval_count': number;
  'meter'?: string;
  'usage_type': string;
};

export type refund = {
  'amount': number;
  'balance_transaction'?: Record<string, any>;
  'charge'?: Record<string, any>;
  'created': number;
  'currency': string;
  'description'?: string;
  'destination_details'?: refund_destination_details;
  'failure_balance_transaction'?: Record<string, any>;
  'failure_reason'?: string;
  'id': string;
  'instructions_email'?: string;
  'metadata'?: Record<string, any>;
  'next_action'?: refund_next_action;
  'object': string;
  'payment_intent'?: Record<string, any>;
  'pending_reason'?: string;
  'presentment_details'?: payment_flows_payment_intent_presentment_details;
  'reason'?: string;
  'receipt_number'?: string;
  'source_transfer_reversal'?: Record<string, any>;
  'status'?: string;
  'transfer_reversal'?: Record<string, any>;
};

export type refund_destination_details = {
  'affirm'?: destination_details_unimplemented;
  'afterpay_clearpay'?: destination_details_unimplemented;
  'alipay'?: destination_details_unimplemented;
  'alma'?: destination_details_unimplemented;
  'amazon_pay'?: destination_details_unimplemented;
  'au_bank_transfer'?: destination_details_unimplemented;
  'blik'?: refund_destination_details_blik;
  'br_bank_transfer'?: refund_destination_details_br_bank_transfer;
  'card'?: refund_destination_details_card;
  'cashapp'?: destination_details_unimplemented;
  'crypto'?: refund_destination_details_crypto;
  'customer_cash_balance'?: destination_details_unimplemented;
  'eps'?: destination_details_unimplemented;
  'eu_bank_transfer'?: refund_destination_details_eu_bank_transfer;
  'gb_bank_transfer'?: refund_destination_details_gb_bank_transfer;
  'giropay'?: destination_details_unimplemented;
  'grabpay'?: destination_details_unimplemented;
  'jp_bank_transfer'?: refund_destination_details_jp_bank_transfer;
  'klarna'?: destination_details_unimplemented;
  'mb_way'?: refund_destination_details_mb_way;
  'multibanco'?: refund_destination_details_multibanco;
  'mx_bank_transfer'?: refund_destination_details_mx_bank_transfer;
  'nz_bank_transfer'?: destination_details_unimplemented;
  'p24'?: refund_destination_details_p24;
  'paynow'?: destination_details_unimplemented;
  'paypal'?: refund_destination_details_paypal;
  'pix'?: destination_details_unimplemented;
  'revolut'?: destination_details_unimplemented;
  'scalapay'?: destination_details_unimplemented;
  'sofort'?: destination_details_unimplemented;
  'swish'?: refund_destination_details_swish;
  'th_bank_transfer'?: refund_destination_details_th_bank_transfer;
  'twint'?: destination_details_unimplemented;
  'type': string;
  'us_bank_transfer'?: refund_destination_details_us_bank_transfer;
  'wechat_pay'?: destination_details_unimplemented;
  'zip'?: destination_details_unimplemented;
};

export type refund_destination_details_blik = {
  'network_decline_code'?: string;
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_br_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_card = {
  'reference'?: string;
  'reference_status'?: string;
  'reference_type'?: string;
  'type': string;
};

export type refund_destination_details_crypto = {
  'reference'?: string;
};

export type refund_destination_details_eu_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_gb_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_jp_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_mb_way = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_multibanco = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_mx_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_p24 = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_paypal = {
  'network_decline_code'?: string;
};

export type refund_destination_details_swish = {
  'network_decline_code'?: string;
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_th_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_destination_details_us_bank_transfer = {
  'reference'?: string;
  'reference_status'?: string;
};

export type refund_next_action = {
  'display_details'?: refund_next_action_display_details;
  'type': string;
};

export type refund_next_action_display_details = {
  'email_sent': email_sent;
  'expires_at': number;
};

export type reporting.report_run = {
  'created': number;
  'error'?: string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'parameters': financial_reporting_finance_report_run_run_parameters;
  'report_type': string;
  'result'?: Record<string, any>;
  'status': string;
  'succeeded_at'?: number;
};

export type reporting.report_type = {
  'data_available_end': number;
  'data_available_start': number;
  'default_columns'?: string[];
  'id': string;
  'livemode': boolean;
  'name': string;
  'object': string;
  'updated': number;
  'version': number;
};

export type reserve_transaction = {
  'amount': number;
  'currency': string;
  'description'?: string;
  'id': string;
  'object': string;
};

export type review = {
  'billing_zip'?: string;
  'charge'?: Record<string, any>;
  'closed_reason'?: string;
  'created': number;
  'id': string;
  'ip_address'?: string;
  'ip_address_location'?: Record<string, any>;
  'livemode': boolean;
  'object': string;
  'open': boolean;
  'opened_reason': string;
  'payment_intent'?: Record<string, any>;
  'reason': string;
  'session'?: Record<string, any>;
};

export type revolut_pay_underlying_payment_method_funding_details = {
  'card'?: payment_method_details_passthrough_card;
  'type'?: string;
};

export type rule = {
  'action': string;
  'id': string;
  'predicate': string;
};

export type scheduled_query_run = {
  'created': number;
  'data_load_time': number;
  'error'?: sigma_scheduled_query_run_error;
  'file'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'object': string;
  'result_available_until': number;
  'sql': string;
  'status': string;
  'title': string;
};

export type schedules_phase_automatic_tax = {
  'disabled_reason'?: string;
  'enabled': boolean;
  'liability'?: Record<string, any>;
};

export type secret_service_resource_scope = {
  'type': string;
  'user'?: string;
};

export type sepa_debit_generated_from = {
  'charge'?: Record<string, any>;
  'setup_attempt'?: Record<string, any>;
};

export type setup_attempt = {
  'application'?: Record<string, any>;
  'attach_to_self'?: boolean;
  'created': number;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'flow_directions'?: string[];
  'id': string;
  'livemode': boolean;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'payment_method': Record<string, any>;
  'payment_method_details': setup_attempt_payment_method_details;
  'setup_error'?: Record<string, any>;
  'setup_intent': Record<string, any>;
  'status': string;
  'usage': string;
};

export type setup_attempt_payment_method_details = {
  'acss_debit'?: setup_attempt_payment_method_details_acss_debit;
  'amazon_pay'?: setup_attempt_payment_method_details_amazon_pay;
  'au_becs_debit'?: setup_attempt_payment_method_details_au_becs_debit;
  'bacs_debit'?: setup_attempt_payment_method_details_bacs_debit;
  'bancontact'?: setup_attempt_payment_method_details_bancontact;
  'boleto'?: setup_attempt_payment_method_details_boleto;
  'card'?: setup_attempt_payment_method_details_card;
  'card_present'?: setup_attempt_payment_method_details_card_present;
  'cashapp'?: setup_attempt_payment_method_details_cashapp;
  'ideal'?: setup_attempt_payment_method_details_ideal;
  'kakao_pay'?: setup_attempt_payment_method_details_kakao_pay;
  'klarna'?: setup_attempt_payment_method_details_klarna;
  'kr_card'?: setup_attempt_payment_method_details_kr_card;
  'link'?: setup_attempt_payment_method_details_link;
  'naver_pay'?: setup_attempt_payment_method_details_naver_pay;
  'nz_bank_account'?: setup_attempt_payment_method_details_nz_bank_account;
  'paypal'?: setup_attempt_payment_method_details_paypal;
  'payto'?: setup_attempt_payment_method_details_payto;
  'pix'?: setup_attempt_payment_method_details_pix;
  'revolut_pay'?: setup_attempt_payment_method_details_revolut_pay;
  'sepa_debit'?: setup_attempt_payment_method_details_sepa_debit;
  'sofort'?: setup_attempt_payment_method_details_sofort;
  'twint'?: setup_attempt_payment_method_details_twint;
  'type': string;
  'upi'?: setup_attempt_payment_method_details_upi;
  'us_bank_account'?: setup_attempt_payment_method_details_us_bank_account;
};

export type setup_attempt_payment_method_details_acss_debit = Record<string, any>;

export type setup_attempt_payment_method_details_amazon_pay = Record<string, any>;

export type setup_attempt_payment_method_details_au_becs_debit = Record<string, any>;

export type setup_attempt_payment_method_details_bacs_debit = Record<string, any>;

export type setup_attempt_payment_method_details_bancontact = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type setup_attempt_payment_method_details_boleto = Record<string, any>;

export type setup_attempt_payment_method_details_card = {
  'brand'?: string;
  'checks'?: Record<string, any>;
  'country'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'fingerprint'?: string;
  'funding'?: string;
  'last4'?: string;
  'network'?: string;
  'three_d_secure'?: Record<string, any>;
  'wallet'?: Record<string, any>;
};

export type setup_attempt_payment_method_details_card_checks = {
  'address_line1_check'?: string;
  'address_postal_code_check'?: string;
  'cvc_check'?: string;
};

export type setup_attempt_payment_method_details_card_present = {
  'generated_card'?: Record<string, any>;
  'offline'?: Record<string, any>;
};

export type setup_attempt_payment_method_details_card_wallet = {
  'apple_pay'?: payment_method_details_card_wallet_apple_pay;
  'google_pay'?: payment_method_details_card_wallet_google_pay;
  'type': string;
};

export type setup_attempt_payment_method_details_cashapp = Record<string, any>;

export type setup_attempt_payment_method_details_ideal = {
  'bank'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'verified_name'?: string;
};

export type setup_attempt_payment_method_details_kakao_pay = Record<string, any>;

export type setup_attempt_payment_method_details_klarna = Record<string, any>;

export type setup_attempt_payment_method_details_kr_card = Record<string, any>;

export type setup_attempt_payment_method_details_link = Record<string, any>;

export type setup_attempt_payment_method_details_naver_pay = {
  'buyer_id'?: string;
};

export type setup_attempt_payment_method_details_nz_bank_account = Record<string, any>;

export type setup_attempt_payment_method_details_paypal = Record<string, any>;

export type setup_attempt_payment_method_details_payto = Record<string, any>;

export type setup_attempt_payment_method_details_pix = Record<string, any>;

export type setup_attempt_payment_method_details_revolut_pay = Record<string, any>;

export type setup_attempt_payment_method_details_sepa_debit = Record<string, any>;

export type setup_attempt_payment_method_details_sofort = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'generated_sepa_debit'?: Record<string, any>;
  'generated_sepa_debit_mandate'?: Record<string, any>;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'verified_name'?: string;
};

export type setup_attempt_payment_method_details_twint = Record<string, any>;

export type setup_attempt_payment_method_details_upi = Record<string, any>;

export type setup_attempt_payment_method_details_us_bank_account = Record<string, any>;

export type setup_intent = {
  'application'?: Record<string, any>;
  'attach_to_self'?: boolean;
  'automatic_payment_methods'?: Record<string, any>;
  'cancellation_reason'?: string;
  'client_secret'?: string;
  'created': number;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'description'?: string;
  'excluded_payment_method_types'?: string[];
  'flow_directions'?: string[];
  'id': string;
  'last_setup_error'?: Record<string, any>;
  'latest_attempt'?: Record<string, any>;
  'livemode': boolean;
  'managed_payments'?: Record<string, any>;
  'mandate'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'next_action'?: Record<string, any>;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'payment_method'?: Record<string, any>;
  'payment_method_configuration_details'?: Record<string, any>;
  'payment_method_options'?: Record<string, any>;
  'payment_method_types': string[];
  'single_use_mandate'?: Record<string, any>;
  'status': string;
  'usage': string;
};

export type setup_intent_next_action = {
  'blik_authorize'?: payment_intent_next_action_blik_authorize;
  'cashapp_handle_redirect_or_display_qr_code'?: payment_intent_next_action_cashapp_handle_redirect_or_display_qr_code;
  'pix_display_qr_code'?: setup_intent_next_action_pix_display_qr_code;
  'redirect_to_url'?: setup_intent_next_action_redirect_to_url;
  'type': string;
  'upi_handle_redirect_or_display_qr_code'?: payment_intent_next_action_upi_handle_redirect_or_display_qr_code;
  'use_stripe_sdk'?: Record<string, any>;
  'verify_with_microdeposits'?: setup_intent_next_action_verify_with_microdeposits;
};

export type setup_intent_next_action_pix_display_qr_code = {
  'data': string;
  'expires_at': number;
  'hosted_instructions_url': string;
  'image_url_png': string;
  'image_url_svg': string;
};

export type setup_intent_next_action_redirect_to_url = {
  'return_url'?: string;
  'url'?: string;
};

export type setup_intent_next_action_verify_with_microdeposits = {
  'arrival_date': number;
  'hosted_verification_url': string;
  'microdeposit_type'?: string;
};

export type setup_intent_payment_method_options = {
  'acss_debit'?: Record<string, any>;
  'amazon_pay'?: Record<string, any>;
  'bacs_debit'?: Record<string, any>;
  'bizum'?: Record<string, any>;
  'card'?: Record<string, any>;
  'card_present'?: Record<string, any>;
  'klarna'?: Record<string, any>;
  'link'?: Record<string, any>;
  'paypal'?: Record<string, any>;
  'payto'?: Record<string, any>;
  'pix'?: Record<string, any>;
  'sepa_debit'?: Record<string, any>;
  'upi'?: Record<string, any>;
  'us_bank_account'?: Record<string, any>;
};

export type setup_intent_payment_method_options_acss_debit = {
  'currency'?: string;
  'mandate_options'?: setup_intent_payment_method_options_mandate_options_acss_debit;
  'verification_method'?: string;
};

export type setup_intent_payment_method_options_amazon_pay = Record<string, any>;

export type setup_intent_payment_method_options_bacs_debit = {
  'mandate_options'?: setup_intent_payment_method_options_mandate_options_bacs_debit;
};

export type setup_intent_payment_method_options_bizum = Record<string, any>;

export type setup_intent_payment_method_options_card = {
  'mandate_options'?: Record<string, any>;
  'network'?: string;
  'request_three_d_secure'?: string;
};

export type setup_intent_payment_method_options_card_mandate_options = {
  'amount': number;
  'amount_type': string;
  'currency': string;
  'description'?: string;
  'end_date'?: number;
  'interval': string;
  'interval_count'?: number;
  'reference': string;
  'start_date': number;
  'supported_types'?: string[];
};

export type setup_intent_payment_method_options_card_present = Record<string, any>;

export type setup_intent_payment_method_options_klarna = {
  'currency'?: string;
  'preferred_locale'?: string;
};

export type setup_intent_payment_method_options_link = Record<string, any>;

export type setup_intent_payment_method_options_mandate_options_acss_debit = {
  'custom_mandate_url'?: string;
  'default_for'?: string[];
  'interval_description'?: string;
  'payment_schedule'?: string;
  'transaction_type'?: string;
};

export type setup_intent_payment_method_options_mandate_options_bacs_debit = {
  'reference_prefix'?: string;
};

export type setup_intent_payment_method_options_mandate_options_payto = {
  'amount'?: number;
  'amount_type'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
  'payments_per_period'?: number;
  'purpose'?: string;
  'start_date'?: string;
};

export type setup_intent_payment_method_options_mandate_options_sepa_debit = {
  'reference_prefix'?: string;
};

export type setup_intent_payment_method_options_paypal = {
  'billing_agreement_id'?: string;
};

export type setup_intent_payment_method_options_payto = {
  'mandate_options'?: setup_intent_payment_method_options_mandate_options_payto;
};

export type setup_intent_payment_method_options_pix = {
  'mandate_options'?: payment_method_options_mandate_options_pix;
};

export type setup_intent_payment_method_options_sepa_debit = {
  'mandate_options'?: setup_intent_payment_method_options_mandate_options_sepa_debit;
};

export type setup_intent_payment_method_options_upi = {
  'mandate_options'?: payment_method_options_mandate_options_upi;
};

export type setup_intent_payment_method_options_us_bank_account = {
  'financial_connections'?: linked_account_options_common;
  'mandate_options'?: payment_method_options_us_bank_account_mandate_options;
  'verification_method'?: string;
};

export type setup_intent_type_specific_payment_method_options_client = {
  'mandate_options'?: setup_intent_payment_method_options_mandate_options_payto;
  'verification_method'?: string;
};

export type shipping = {
  'address'?: address;
  'carrier'?: string;
  'name'?: string;
  'phone'?: string;
  'tracking_number'?: string;
};

export type shipping_rate = {
  'active': boolean;
  'created': number;
  'delivery_estimate'?: Record<string, any>;
  'display_name'?: string;
  'fixed_amount'?: shipping_rate_fixed_amount;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'tax_behavior'?: string;
  'tax_code'?: Record<string, any>;
  'type': string;
};

export type shipping_rate_currency_option = {
  'amount': number;
  'tax_behavior': string;
};

export type shipping_rate_delivery_estimate = {
  'maximum'?: Record<string, any>;
  'minimum'?: Record<string, any>;
};

export type shipping_rate_delivery_estimate_bound = {
  'unit': string;
  'value': number;
};

export type shipping_rate_fixed_amount = {
  'amount': number;
  'currency': string;
  'currency_options'?: Record<string, any>;
};

export type sigma.sigma_api_query = {
  'created': number;
  'id': string;
  'livemode': boolean;
  'name': string;
  'object': string;
  'sql': string;
};

export type sigma_scheduled_query_run_error = {
  'message': string;
};

export type smor_resource_managed_payments = {
  'enabled': boolean;
};

export type source = {
  'ach_credit_transfer'?: source_type_ach_credit_transfer;
  'ach_debit'?: source_type_ach_debit;
  'acss_debit'?: source_type_acss_debit;
  'alipay'?: source_type_alipay;
  'allow_redisplay'?: string;
  'amount'?: number;
  'au_becs_debit'?: source_type_au_becs_debit;
  'bancontact'?: source_type_bancontact;
  'card'?: source_type_card;
  'card_present'?: source_type_card_present;
  'client_secret': string;
  'code_verification'?: source_code_verification_flow;
  'created': number;
  'currency'?: string;
  'customer'?: string;
  'eps'?: source_type_eps;
  'flow': string;
  'giropay'?: source_type_giropay;
  'id': string;
  'ideal'?: source_type_ideal;
  'klarna'?: source_type_klarna;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'multibanco'?: source_type_multibanco;
  'object': string;
  'owner'?: Record<string, any>;
  'p24'?: source_type_p24;
  'receiver'?: source_receiver_flow;
  'redirect'?: source_redirect_flow;
  'sepa_debit'?: source_type_sepa_debit;
  'sofort'?: source_type_sofort;
  'source_order'?: source_order;
  'statement_descriptor'?: string;
  'status': string;
  'three_d_secure'?: source_type_three_d_secure;
  'type': string;
  'usage'?: string;
  'wechat'?: source_type_wechat;
};

export type source_code_verification_flow = {
  'attempts_remaining': number;
  'status': string;
};

export type source_mandate_notification = {
  'acss_debit'?: source_mandate_notification_acss_debit_data;
  'amount'?: number;
  'bacs_debit'?: source_mandate_notification_bacs_debit_data;
  'created': number;
  'id': string;
  'livemode': boolean;
  'object': string;
  'reason': string;
  'sepa_debit'?: source_mandate_notification_sepa_debit_data;
  'source': source;
  'status': string;
  'type': string;
};

export type source_mandate_notification_acss_debit_data = {
  'statement_descriptor'?: string;
};

export type source_mandate_notification_bacs_debit_data = {
  'last4'?: string;
};

export type source_mandate_notification_sepa_debit_data = {
  'creditor_identifier'?: string;
  'last4'?: string;
  'mandate_reference'?: string;
};

export type source_order = {
  'amount': number;
  'currency': string;
  'email'?: string;
  'items'?: source_order_item[];
  'shipping'?: shipping;
};

export type source_order_item = {
  'amount'?: number;
  'currency'?: string;
  'description'?: string;
  'parent'?: string;
  'quantity'?: number;
  'type'?: string;
};

export type source_owner = {
  'address'?: Record<string, any>;
  'email'?: string;
  'name'?: string;
  'phone'?: string;
  'verified_address'?: Record<string, any>;
  'verified_email'?: string;
  'verified_name'?: string;
  'verified_phone'?: string;
};

export type source_receiver_flow = {
  'address'?: string;
  'amount_charged': number;
  'amount_received': number;
  'amount_returned': number;
  'refund_attributes_method': string;
  'refund_attributes_status': string;
};

export type source_redirect_flow = {
  'failure_reason'?: string;
  'return_url': string;
  'status': string;
  'url': string;
};

export type source_transaction = {
  'ach_credit_transfer'?: source_transaction_ach_credit_transfer_data;
  'amount': number;
  'chf_credit_transfer'?: source_transaction_chf_credit_transfer_data;
  'created': number;
  'currency': string;
  'gbp_credit_transfer'?: source_transaction_gbp_credit_transfer_data;
  'id': string;
  'livemode': boolean;
  'object': string;
  'paper_check'?: source_transaction_paper_check_data;
  'sepa_credit_transfer'?: source_transaction_sepa_credit_transfer_data;
  'source': string;
  'status': string;
  'type': string;
};

export type source_transaction_ach_credit_transfer_data = {
  'customer_data'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'routing_number'?: string;
};

export type source_transaction_chf_credit_transfer_data = {
  'reference'?: string;
  'sender_address_country'?: string;
  'sender_address_line1'?: string;
  'sender_iban'?: string;
  'sender_name'?: string;
};

export type source_transaction_gbp_credit_transfer_data = {
  'fingerprint'?: string;
  'funding_method'?: string;
  'last4'?: string;
  'reference'?: string;
  'sender_account_number'?: string;
  'sender_name'?: string;
  'sender_sort_code'?: string;
};

export type source_transaction_paper_check_data = {
  'available_at'?: string;
  'invoices'?: string;
};

export type source_transaction_sepa_credit_transfer_data = {
  'reference'?: string;
  'sender_iban'?: string;
  'sender_name'?: string;
};

export type source_type_ach_credit_transfer = {
  'account_number'?: string;
  'bank_name'?: string;
  'fingerprint'?: string;
  'refund_account_holder_name'?: string;
  'refund_account_holder_type'?: string;
  'refund_routing_number'?: string;
  'routing_number'?: string;
  'swift_code'?: string;
};

export type source_type_ach_debit = {
  'bank_name'?: string;
  'country'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'routing_number'?: string;
  'type'?: string;
};

export type source_type_acss_debit = {
  'bank_address_city'?: string;
  'bank_address_line_1'?: string;
  'bank_address_line_2'?: string;
  'bank_address_postal_code'?: string;
  'bank_name'?: string;
  'category'?: string;
  'country'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'routing_number'?: string;
};

export type source_type_alipay = {
  'data_string'?: string;
  'native_url'?: string;
  'statement_descriptor'?: string;
};

export type source_type_au_becs_debit = {
  'bsb_number'?: string;
  'fingerprint'?: string;
  'last4'?: string;
};

export type source_type_bancontact = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'statement_descriptor'?: string;
};

export type source_type_card = {
  'address_line1_check'?: string;
  'address_zip_check'?: string;
  'brand'?: string;
  'country'?: string;
  'cvc_check'?: string;
  'dynamic_last4'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'fingerprint'?: string;
  'funding'?: string;
  'last4'?: string;
  'name'?: string;
  'three_d_secure'?: string;
  'tokenization_method'?: string;
};

export type source_type_card_present = {
  'application_cryptogram'?: string;
  'application_preferred_name'?: string;
  'authorization_code'?: string;
  'authorization_response_code'?: string;
  'brand'?: string;
  'country'?: string;
  'cvm_type'?: string;
  'data_type'?: string;
  'dedicated_file_name'?: string;
  'emv_auth_data'?: string;
  'evidence_customer_signature'?: string;
  'evidence_transaction_certificate'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'fingerprint'?: string;
  'funding'?: string;
  'last4'?: string;
  'pos_device_id'?: string;
  'pos_entry_mode'?: string;
  'read_method'?: string;
  'reader'?: string;
  'terminal_verification_results'?: string;
  'transaction_status_information'?: string;
};

export type source_type_eps = {
  'reference'?: string;
  'statement_descriptor'?: string;
};

export type source_type_giropay = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'statement_descriptor'?: string;
};

export type source_type_ideal = {
  'bank'?: string;
  'bic'?: string;
  'iban_last4'?: string;
  'statement_descriptor'?: string;
};

export type source_type_klarna = {
  'background_image_url'?: string;
  'client_token'?: string;
  'first_name'?: string;
  'last_name'?: string;
  'locale'?: string;
  'logo_url'?: string;
  'page_title'?: string;
  'pay_later_asset_urls_descriptive'?: string;
  'pay_later_asset_urls_standard'?: string;
  'pay_later_name'?: string;
  'pay_later_redirect_url'?: string;
  'pay_now_asset_urls_descriptive'?: string;
  'pay_now_asset_urls_standard'?: string;
  'pay_now_name'?: string;
  'pay_now_redirect_url'?: string;
  'pay_over_time_asset_urls_descriptive'?: string;
  'pay_over_time_asset_urls_standard'?: string;
  'pay_over_time_name'?: string;
  'pay_over_time_redirect_url'?: string;
  'payment_method_categories'?: string;
  'purchase_country'?: string;
  'purchase_type'?: string;
  'redirect_url'?: string;
  'shipping_delay'?: number;
  'shipping_first_name'?: string;
  'shipping_last_name'?: string;
};

export type source_type_multibanco = {
  'entity'?: string;
  'reference'?: string;
  'refund_account_holder_address_city'?: string;
  'refund_account_holder_address_country'?: string;
  'refund_account_holder_address_line1'?: string;
  'refund_account_holder_address_line2'?: string;
  'refund_account_holder_address_postal_code'?: string;
  'refund_account_holder_address_state'?: string;
  'refund_account_holder_name'?: string;
  'refund_iban'?: string;
};

export type source_type_p24 = {
  'reference'?: string;
};

export type source_type_sepa_debit = {
  'bank_code'?: string;
  'branch_code'?: string;
  'country'?: string;
  'fingerprint'?: string;
  'last4'?: string;
  'mandate_reference'?: string;
  'mandate_url'?: string;
};

export type source_type_sofort = {
  'bank_code'?: string;
  'bank_name'?: string;
  'bic'?: string;
  'country'?: string;
  'iban_last4'?: string;
  'preferred_language'?: string;
  'statement_descriptor'?: string;
};

export type source_type_three_d_secure = {
  'address_line1_check'?: string;
  'address_zip_check'?: string;
  'authenticated'?: boolean;
  'brand'?: string;
  'card'?: string;
  'country'?: string;
  'customer'?: string;
  'cvc_check'?: string;
  'dynamic_last4'?: string;
  'exp_month'?: number;
  'exp_year'?: number;
  'fingerprint'?: string;
  'funding'?: string;
  'last4'?: string;
  'name'?: string;
  'three_d_secure'?: string;
  'tokenization_method'?: string;
};

export type source_type_wechat = {
  'prepay_id'?: string;
  'qr_code_url'?: string;
  'statement_descriptor'?: string;
};

export type stackable_discount_with_discount_settings = {
  'coupon'?: Record<string, any>;
  'discount'?: Record<string, any>;
  'promotion_code'?: Record<string, any>;
};

export type stackable_discount_with_discount_settings_and_discount_end = {
  'coupon'?: Record<string, any>;
  'discount'?: Record<string, any>;
  'promotion_code'?: Record<string, any>;
};

export type subscription = {
  'application'?: Record<string, any>;
  'application_fee_percent'?: number;
  'automatic_tax': subscription_automatic_tax;
  'billing_cycle_anchor': number;
  'billing_cycle_anchor_config'?: Record<string, any>;
  'billing_mode': subscriptions_resource_billing_mode;
  'billing_schedules': subscriptions_resource_billing_schedules[];
  'billing_thresholds'?: Record<string, any>;
  'cancel_at'?: number;
  'cancel_at_period_end': boolean;
  'canceled_at'?: number;
  'cancellation_details'?: Record<string, any>;
  'collection_method': string;
  'created': number;
  'currency': string;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'days_until_due'?: number;
  'default_payment_method'?: Record<string, any>;
  'default_source'?: Record<string, any>;
  'default_tax_rates'?: tax_rate[];
  'description'?: string;
  'discounts': Record<string, any>[];
  'ended_at'?: number;
  'id': string;
  'invoice_settings': subscriptions_resource_subscription_invoice_settings;
  'items': {
    'data': subscription_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'latest_invoice'?: Record<string, any>;
  'livemode': boolean;
  'managed_payments'?: Record<string, any>;
  'metadata': Record<string, any>;
  'next_pending_invoice_item_invoice'?: number;
  'object': string;
  'on_behalf_of'?: Record<string, any>;
  'pause_collection'?: Record<string, any>;
  'payment_settings'?: Record<string, any>;
  'pending_invoice_item_interval'?: Record<string, any>;
  'pending_setup_intent'?: Record<string, any>;
  'pending_update'?: Record<string, any>;
  'presentment_details'?: subscriptions_resource_subscription_presentment_details;
  'schedule'?: Record<string, any>;
  'start_date': number;
  'status': string;
  'test_clock'?: Record<string, any>;
  'transfer_data'?: Record<string, any>;
  'trial_end'?: number;
  'trial_settings'?: Record<string, any>;
  'trial_start'?: number;
};

export type subscription_automatic_tax = {
  'disabled_reason'?: string;
  'enabled': boolean;
  'liability'?: Record<string, any>;
};

export type subscription_billing_thresholds = {
  'amount_gte'?: number;
  'reset_billing_cycle_anchor'?: boolean;
};

export type subscription_item = {
  'billed_until'?: number;
  'billing_thresholds'?: Record<string, any>;
  'created': number;
  'current_period_end': number;
  'current_period_start': number;
  'discounts': Record<string, any>[];
  'id': string;
  'metadata': Record<string, any>;
  'object': string;
  'price': price;
  'quantity'?: number;
  'subscription': string;
  'tax_rates'?: tax_rate[];
};

export type subscription_item_billing_thresholds = {
  'usage_gte'?: number;
};

export type subscription_payment_method_options_card = {
  'mandate_options'?: invoice_mandate_options_card;
  'network'?: string;
  'request_three_d_secure'?: string;
};

export type subscription_payment_method_options_mandate_options_pix = {
  'amount'?: number;
  'amount_includes_iof'?: string;
  'end_date'?: string;
  'payment_schedule'?: string;
};

export type subscription_payment_method_options_pix = {
  'expires_after_seconds'?: number;
  'mandate_options'?: subscription_payment_method_options_mandate_options_pix;
};

export type subscription_pending_invoice_item_interval = {
  'interval': string;
  'interval_count': number;
};

export type subscription_schedule = {
  'application'?: Record<string, any>;
  'billing_mode': subscriptions_resource_billing_mode;
  'canceled_at'?: number;
  'completed_at'?: number;
  'created': number;
  'current_phase'?: Record<string, any>;
  'customer': Record<string, any>;
  'customer_account'?: string;
  'default_settings': subscription_schedules_resource_default_settings;
  'end_behavior': string;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'phases': subscription_schedule_phase_configuration[];
  'released_at'?: number;
  'released_subscription'?: string;
  'status': string;
  'subscription'?: Record<string, any>;
  'test_clock'?: Record<string, any>;
};

export type subscription_schedule_add_invoice_item = {
  'discountable'?: boolean;
  'discounts': discounts_resource_stackable_discount_with_discount_end[];
  'metadata'?: Record<string, any>;
  'period': subscription_schedule_add_invoice_item_period;
  'price': Record<string, any>;
  'quantity'?: number;
  'tax_rates'?: tax_rate[];
};

export type subscription_schedule_add_invoice_item_period = {
  'end': subscription_schedules_resource_invoice_item_period_resource_period_end;
  'start': subscription_schedules_resource_invoice_item_period_resource_period_start;
};

export type subscription_schedule_configuration_item = {
  'billing_thresholds'?: Record<string, any>;
  'discounts': stackable_discount_with_discount_settings[];
  'metadata'?: Record<string, any>;
  'price': Record<string, any>;
  'quantity'?: number;
  'tax_rates'?: tax_rate[];
};

export type subscription_schedule_current_phase = {
  'end_date': number;
  'start_date': number;
};

export type subscription_schedule_phase_configuration = {
  'add_invoice_items': subscription_schedule_add_invoice_item[];
  'application_fee_percent'?: number;
  'automatic_tax'?: schedules_phase_automatic_tax;
  'billing_cycle_anchor'?: string;
  'billing_thresholds'?: Record<string, any>;
  'collection_method'?: string;
  'currency': string;
  'default_payment_method'?: Record<string, any>;
  'default_tax_rates'?: tax_rate[];
  'description'?: string;
  'discounts': stackable_discount_with_discount_settings_and_discount_end[];
  'end_date': number;
  'invoice_settings'?: Record<string, any>;
  'items': subscription_schedule_configuration_item[];
  'metadata'?: Record<string, any>;
  'on_behalf_of'?: Record<string, any>;
  'proration_behavior': string;
  'start_date': number;
  'transfer_data'?: Record<string, any>;
  'trial_end'?: number;
};

export type subscription_schedules_resource_default_settings = {
  'application_fee_percent'?: number;
  'automatic_tax'?: subscription_schedules_resource_default_settings_automatic_tax;
  'billing_cycle_anchor': string;
  'billing_thresholds'?: Record<string, any>;
  'collection_method'?: string;
  'default_payment_method'?: Record<string, any>;
  'description'?: string;
  'invoice_settings': invoice_setting_subscription_schedule_setting;
  'on_behalf_of'?: Record<string, any>;
  'transfer_data'?: Record<string, any>;
};

export type subscription_schedules_resource_default_settings_automatic_tax = {
  'disabled_reason'?: string;
  'enabled': boolean;
  'liability'?: Record<string, any>;
};

export type subscription_schedules_resource_invoice_item_period_resource_period_end = {
  'timestamp'?: number;
  'type': string;
};

export type subscription_schedules_resource_invoice_item_period_resource_period_start = {
  'timestamp'?: number;
  'type': string;
};

export type subscription_transfer_data = {
  'amount_percent'?: number;
  'destination': Record<string, any>;
};

export type subscriptions_resource_billing_cycle_anchor_config = {
  'day_of_month': number;
  'hour'?: number;
  'minute'?: number;
  'month'?: number;
  'second'?: number;
};

export type subscriptions_resource_billing_mode = {
  'flexible'?: Record<string, any>;
  'type': string;
  'updated_at'?: number;
};

export type subscriptions_resource_billing_mode_flexible = {
  'proration_discounts'?: string;
};

export type subscriptions_resource_billing_schedules = {
  'applies_to'?: subscriptions_resource_billing_schedules_applies_to[];
  'bill_until': subscriptions_resource_billing_schedules_bill_until;
  'key': string;
};

export type subscriptions_resource_billing_schedules_applies_to = {
  'price'?: Record<string, any>;
  'type': string;
};

export type subscriptions_resource_billing_schedules_bill_until = {
  'computed_timestamp': number;
  'duration'?: Record<string, any>;
  'timestamp'?: number;
  'type': string;
};

export type subscriptions_resource_billing_schedules_bill_until_duration = {
  'interval': string;
  'interval_count'?: number;
};

export type subscriptions_resource_pause_collection = {
  'behavior': string;
  'resumes_at'?: number;
};

export type subscriptions_resource_payment_method_options = {
  'acss_debit'?: Record<string, any>;
  'bancontact'?: Record<string, any>;
  'card'?: Record<string, any>;
  'customer_balance'?: Record<string, any>;
  'konbini'?: Record<string, any>;
  'payto'?: Record<string, any>;
  'pix'?: Record<string, any>;
  'sepa_debit'?: Record<string, any>;
  'upi'?: Record<string, any>;
  'us_bank_account'?: Record<string, any>;
};

export type subscriptions_resource_payment_settings = {
  'payment_method_options'?: Record<string, any>;
  'payment_method_types'?: string[];
  'save_default_payment_method'?: string;
};

export type subscriptions_resource_pending_update = {
  'billing_cycle_anchor'?: number;
  'discount'?: Record<string, any>;
  'discounts'?: Record<string, any>[];
  'expires_at': number;
  'metadata'?: Record<string, any>;
  'subscription_items'?: subscription_item[];
  'trial_end'?: number;
  'trial_from_plan'?: boolean;
};

export type subscriptions_resource_subscription_invoice_settings = {
  'account_tax_ids'?: Record<string, any>[];
  'issuer': connect_account_reference;
};

export type subscriptions_resource_subscription_presentment_details = {
  'presentment_currency': string;
};

export type subscriptions_resource_trial_settings_end_behavior = {
  'missing_payment_method': string;
};

export type subscriptions_resource_trial_settings_trial_settings = {
  'end_behavior': subscriptions_resource_trial_settings_end_behavior;
};

export type subscriptions_trials_resource_end_behavior = {
  'missing_payment_method': string;
};

export type subscriptions_trials_resource_trial_settings = {
  'end_behavior': subscriptions_trials_resource_end_behavior;
};

export type tax.association = {
  'calculation': string;
  'id': string;
  'object': string;
  'payment_intent': string;
  'tax_transaction_attempts'?: tax_product_resource_tax_association_transaction_attempts[];
};

export type tax.calculation = {
  'amount_total': number;
  'currency': string;
  'customer'?: string;
  'customer_details': tax_product_resource_customer_details;
  'expires_at'?: number;
  'id'?: string;
  'line_items'?: {
    'data': tax.calculation_line_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'object': string;
  'ship_from_details'?: Record<string, any>;
  'shipping_cost'?: Record<string, any>;
  'tax_amount_exclusive': number;
  'tax_amount_inclusive': number;
  'tax_breakdown': tax_product_resource_tax_breakdown[];
  'tax_date': number;
};

export type tax.calculation_line_item = {
  'amount': number;
  'amount_tax': number;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'product'?: string;
  'quantity': number;
  'reference': string;
  'tax_behavior': string;
  'tax_breakdown'?: tax_product_resource_line_item_tax_breakdown[];
  'tax_code': string;
};

export type tax.registration = {
  'active_from': number;
  'country': string;
  'country_options': tax_product_registrations_resource_country_options;
  'created': number;
  'expires_at'?: number;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status': string;
};

export type tax.settings = {
  'defaults': tax_product_resource_tax_settings_defaults;
  'head_office'?: Record<string, any>;
  'livemode': boolean;
  'object': string;
  'status': string;
  'status_details': tax_product_resource_tax_settings_status_details;
};

export type tax.transaction = {
  'created': number;
  'currency': string;
  'customer'?: string;
  'customer_details': tax_product_resource_customer_details;
  'id': string;
  'line_items'?: {
    'data': tax.transaction_line_item[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'posted_at': number;
  'reference': string;
  'reversal'?: Record<string, any>;
  'ship_from_details'?: Record<string, any>;
  'shipping_cost'?: Record<string, any>;
  'tax_date': number;
  'type': string;
};

export type tax.transaction_line_item = {
  'amount': number;
  'amount_tax': number;
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'product'?: string;
  'quantity': number;
  'reference': string;
  'reversal'?: Record<string, any>;
  'tax_behavior': string;
  'tax_code': string;
  'type': string;
};

export type tax_code = {
  'description': string;
  'id': string;
  'name': string;
  'object': string;
};

export type tax_deducted_at_source = {
  'id': string;
  'object': string;
  'period_end': number;
  'period_start': number;
  'tax_deduction_account_number': string;
};

export type tax_i_ds_owner = {
  'account'?: Record<string, any>;
  'application'?: Record<string, any>;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'type': string;
};

export type tax_id = {
  'country'?: string;
  'created': number;
  'customer'?: Record<string, any>;
  'customer_account'?: string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'owner'?: Record<string, any>;
  'type': string;
  'value': string;
  'verification'?: Record<string, any>;
};

export type tax_id_verification = {
  'status': string;
  'verified_address'?: string;
  'verified_name'?: string;
};

export type tax_product_registrations_resource_country_options = {
  'ae'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'al'?: tax_product_registrations_resource_country_options_default;
  'am'?: tax_product_registrations_resource_country_options_simplified;
  'ao'?: tax_product_registrations_resource_country_options_default;
  'at'?: tax_product_registrations_resource_country_options_europe;
  'au'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'aw'?: tax_product_registrations_resource_country_options_default;
  'az'?: tax_product_registrations_resource_country_options_simplified;
  'ba'?: tax_product_registrations_resource_country_options_default;
  'bb'?: tax_product_registrations_resource_country_options_default;
  'bd'?: tax_product_registrations_resource_country_options_default;
  'be'?: tax_product_registrations_resource_country_options_europe;
  'bf'?: tax_product_registrations_resource_country_options_default;
  'bg'?: tax_product_registrations_resource_country_options_europe;
  'bh'?: tax_product_registrations_resource_country_options_default;
  'bj'?: tax_product_registrations_resource_country_options_simplified;
  'bs'?: tax_product_registrations_resource_country_options_default;
  'by'?: tax_product_registrations_resource_country_options_simplified;
  'ca'?: tax_product_registrations_resource_country_options_canada;
  'cd'?: tax_product_registrations_resource_country_options_default;
  'ch'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'cl'?: tax_product_registrations_resource_country_options_simplified;
  'cm'?: tax_product_registrations_resource_country_options_simplified;
  'co'?: tax_product_registrations_resource_country_options_simplified;
  'cr'?: tax_product_registrations_resource_country_options_simplified;
  'cv'?: tax_product_registrations_resource_country_options_simplified;
  'cy'?: tax_product_registrations_resource_country_options_europe;
  'cz'?: tax_product_registrations_resource_country_options_europe;
  'de'?: tax_product_registrations_resource_country_options_europe;
  'dk'?: tax_product_registrations_resource_country_options_europe;
  'ec'?: tax_product_registrations_resource_country_options_simplified;
  'ee'?: tax_product_registrations_resource_country_options_europe;
  'eg'?: tax_product_registrations_resource_country_options_simplified;
  'es'?: tax_product_registrations_resource_country_options_europe;
  'et'?: tax_product_registrations_resource_country_options_default;
  'fi'?: tax_product_registrations_resource_country_options_europe;
  'fr'?: tax_product_registrations_resource_country_options_europe;
  'gb'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'ge'?: tax_product_registrations_resource_country_options_simplified;
  'gn'?: tax_product_registrations_resource_country_options_default;
  'gr'?: tax_product_registrations_resource_country_options_europe;
  'hr'?: tax_product_registrations_resource_country_options_europe;
  'hu'?: tax_product_registrations_resource_country_options_europe;
  'id'?: tax_product_registrations_resource_country_options_simplified;
  'ie'?: tax_product_registrations_resource_country_options_europe;
  'in'?: tax_product_registrations_resource_country_options_simplified;
  'is'?: tax_product_registrations_resource_country_options_default;
  'it'?: tax_product_registrations_resource_country_options_europe;
  'jp'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'ke'?: tax_product_registrations_resource_country_options_simplified;
  'kg'?: tax_product_registrations_resource_country_options_simplified;
  'kh'?: tax_product_registrations_resource_country_options_simplified;
  'kr'?: tax_product_registrations_resource_country_options_simplified;
  'kz'?: tax_product_registrations_resource_country_options_simplified;
  'la'?: tax_product_registrations_resource_country_options_simplified;
  'lk'?: tax_product_registrations_resource_country_options_simplified;
  'lt'?: tax_product_registrations_resource_country_options_europe;
  'lu'?: tax_product_registrations_resource_country_options_europe;
  'lv'?: tax_product_registrations_resource_country_options_europe;
  'ma'?: tax_product_registrations_resource_country_options_simplified;
  'md'?: tax_product_registrations_resource_country_options_simplified;
  'me'?: tax_product_registrations_resource_country_options_default;
  'mk'?: tax_product_registrations_resource_country_options_default;
  'mr'?: tax_product_registrations_resource_country_options_default;
  'mt'?: tax_product_registrations_resource_country_options_europe;
  'mx'?: tax_product_registrations_resource_country_options_simplified;
  'my'?: tax_product_registrations_resource_country_options_simplified;
  'ng'?: tax_product_registrations_resource_country_options_simplified;
  'nl'?: tax_product_registrations_resource_country_options_europe;
  'no'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'np'?: tax_product_registrations_resource_country_options_simplified;
  'nz'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'om'?: tax_product_registrations_resource_country_options_default;
  'pe'?: tax_product_registrations_resource_country_options_simplified;
  'ph'?: tax_product_registrations_resource_country_options_simplified;
  'pl'?: tax_product_registrations_resource_country_options_europe;
  'pt'?: tax_product_registrations_resource_country_options_europe;
  'ro'?: tax_product_registrations_resource_country_options_europe;
  'rs'?: tax_product_registrations_resource_country_options_default;
  'ru'?: tax_product_registrations_resource_country_options_simplified;
  'sa'?: tax_product_registrations_resource_country_options_simplified;
  'se'?: tax_product_registrations_resource_country_options_europe;
  'sg'?: tax_product_registrations_resource_country_options_default_inbound_goods;
  'si'?: tax_product_registrations_resource_country_options_europe;
  'sk'?: tax_product_registrations_resource_country_options_europe;
  'sn'?: tax_product_registrations_resource_country_options_simplified;
  'sr'?: tax_product_registrations_resource_country_options_default;
  'th'?: tax_product_registrations_resource_country_options_thailand;
  'tj'?: tax_product_registrations_resource_country_options_simplified;
  'tr'?: tax_product_registrations_resource_country_options_simplified;
  'tw'?: tax_product_registrations_resource_country_options_simplified;
  'tz'?: tax_product_registrations_resource_country_options_simplified;
  'ua'?: tax_product_registrations_resource_country_options_simplified;
  'ug'?: tax_product_registrations_resource_country_options_simplified;
  'us'?: tax_product_registrations_resource_country_options_united_states;
  'uy'?: tax_product_registrations_resource_country_options_default;
  'uz'?: tax_product_registrations_resource_country_options_simplified;
  'vn'?: tax_product_registrations_resource_country_options_simplified;
  'za'?: tax_product_registrations_resource_country_options_default;
  'zm'?: tax_product_registrations_resource_country_options_simplified;
  'zw'?: tax_product_registrations_resource_country_options_default;
};

export type tax_product_registrations_resource_country_options_ca_province_standard = {
  'province': string;
};

export type tax_product_registrations_resource_country_options_canada = {
  'province_standard'?: tax_product_registrations_resource_country_options_ca_province_standard;
  'type': string;
};

export type tax_product_registrations_resource_country_options_default = {
  'type': string;
};

export type tax_product_registrations_resource_country_options_default_inbound_goods = {
  'standard'?: tax_product_registrations_resource_country_options_default_standard;
  'type': string;
};

export type tax_product_registrations_resource_country_options_default_standard = {
  'place_of_supply_scheme': string;
};

export type tax_product_registrations_resource_country_options_eu_standard = {
  'place_of_supply_scheme': string;
};

export type tax_product_registrations_resource_country_options_europe = {
  'standard'?: tax_product_registrations_resource_country_options_eu_standard;
  'type': string;
};

export type tax_product_registrations_resource_country_options_simplified = {
  'type': string;
};

export type tax_product_registrations_resource_country_options_thailand = {
  'type': string;
};

export type tax_product_registrations_resource_country_options_united_states = {
  'local_amusement_tax'?: tax_product_registrations_resource_country_options_us_local_amusement_tax;
  'local_lease_tax'?: tax_product_registrations_resource_country_options_us_local_lease_tax;
  'state': string;
  'state_sales_tax'?: tax_product_registrations_resource_country_options_us_state_sales_tax;
  'type': string;
};

export type tax_product_registrations_resource_country_options_us_local_amusement_tax = {
  'jurisdiction': string;
};

export type tax_product_registrations_resource_country_options_us_local_lease_tax = {
  'jurisdiction': string;
};

export type tax_product_registrations_resource_country_options_us_state_sales_tax = {
  'elections'?: tax_product_registrations_resource_country_options_us_state_sales_tax_election[];
};

export type tax_product_registrations_resource_country_options_us_state_sales_tax_election = {
  'jurisdiction'?: string;
  'type': string;
};

export type tax_product_resource_customer_details = {
  'address'?: Record<string, any>;
  'address_source'?: string;
  'ip_address'?: string;
  'tax_ids': tax_product_resource_customer_details_resource_tax_id[];
  'taxability_override': string;
};

export type tax_product_resource_customer_details_resource_tax_id = {
  'type': string;
  'value': string;
};

export type tax_product_resource_jurisdiction = {
  'country': string;
  'display_name': string;
  'level': string;
  'state'?: string;
};

export type tax_product_resource_line_item_tax_breakdown = {
  'amount': number;
  'jurisdiction': tax_product_resource_jurisdiction;
  'sourcing': string;
  'tax_rate_details'?: Record<string, any>;
  'taxability_reason': string;
  'taxable_amount': number;
};

export type tax_product_resource_line_item_tax_rate_details = {
  'display_name': string;
  'percentage_decimal': string;
  'tax_type': string;
};

export type tax_product_resource_postal_address = {
  'city'?: string;
  'country': string;
  'line1'?: string;
  'line2'?: string;
  'postal_code'?: string;
  'state'?: string;
};

export type tax_product_resource_ship_from_details = {
  'address': tax_product_resource_postal_address;
};

export type tax_product_resource_tax_association_transaction_attempts = {
  'committed'?: tax_product_resource_tax_association_transaction_attempts_resource_committed;
  'errored'?: tax_product_resource_tax_association_transaction_attempts_resource_errored;
  'source': string;
  'status': string;
};

export type tax_product_resource_tax_association_transaction_attempts_resource_committed = {
  'transaction': string;
};

export type tax_product_resource_tax_association_transaction_attempts_resource_errored = {
  'reason': string;
};

export type tax_product_resource_tax_breakdown = {
  'amount': number;
  'inclusive': boolean;
  'tax_rate_details': tax_product_resource_tax_rate_details;
  'taxability_reason': string;
  'taxable_amount': number;
};

export type tax_product_resource_tax_calculation_shipping_cost = {
  'amount': number;
  'amount_tax': number;
  'shipping_rate'?: string;
  'tax_behavior': string;
  'tax_breakdown'?: tax_product_resource_line_item_tax_breakdown[];
  'tax_code': string;
};

export type tax_product_resource_tax_rate_details = {
  'country'?: string;
  'flat_amount'?: Record<string, any>;
  'percentage_decimal': string;
  'rate_type'?: string;
  'state'?: string;
  'tax_type'?: string;
};

export type tax_product_resource_tax_settings_defaults = {
  'provider': string;
  'tax_behavior'?: string;
  'tax_code'?: string;
};

export type tax_product_resource_tax_settings_head_office = {
  'address': address;
};

export type tax_product_resource_tax_settings_status_details = {
  'active'?: tax_product_resource_tax_settings_status_details_resource_active;
  'pending'?: tax_product_resource_tax_settings_status_details_resource_pending;
};

export type tax_product_resource_tax_settings_status_details_resource_active = Record<string, any>;

export type tax_product_resource_tax_settings_status_details_resource_pending = {
  'missing_fields'?: string[];
};

export type tax_product_resource_tax_transaction_line_item_resource_reversal = {
  'original_line_item': string;
};

export type tax_product_resource_tax_transaction_resource_reversal = {
  'original_transaction'?: string;
};

export type tax_product_resource_tax_transaction_shipping_cost = {
  'amount': number;
  'amount_tax': number;
  'shipping_rate'?: string;
  'tax_behavior': string;
  'tax_code': string;
};

export type tax_rate = {
  'active': boolean;
  'country'?: string;
  'created': number;
  'description'?: string;
  'display_name': string;
  'effective_percentage'?: number;
  'flat_amount'?: Record<string, any>;
  'id': string;
  'inclusive': boolean;
  'jurisdiction'?: string;
  'jurisdiction_level'?: string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'percentage': number;
  'rate_type'?: string;
  'state'?: string;
  'tax_type'?: string;
};

export type tax_rate_flat_amount = {
  'amount': number;
  'currency': string;
};

export type terminal.configuration = {
  'bbpos_wisepad3'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'bbpos_wisepos_e'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'cellular'?: terminal_configuration_configuration_resource_cellular_config;
  'id': string;
  'is_account_default'?: boolean;
  'livemode': boolean;
  'name'?: string;
  'object': string;
  'offline'?: terminal_configuration_configuration_resource_offline_config;
  'reboot_window'?: terminal_configuration_configuration_resource_reboot_window;
  'stripe_s700'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'stripe_s710'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'tipping'?: terminal_configuration_configuration_resource_tipping;
  'verifone_m425'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'verifone_p400'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'verifone_p630'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'verifone_ux700'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'verifone_v660p'?: terminal_configuration_configuration_resource_device_type_specific_config;
  'wifi'?: terminal_configuration_configuration_resource_wifi_config;
};

export type terminal.connection_token = {
  'location'?: string;
  'object': string;
  'secret': string;
};

export type terminal.location = {
  'address': address;
  'address_kana'?: legal_entity_japan_address;
  'address_kanji'?: legal_entity_japan_address;
  'configuration_overrides'?: string;
  'display_name': string;
  'display_name_kana'?: string;
  'display_name_kanji'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'phone'?: string;
};

export type terminal.onboarding_link = {
  'link_options': terminal_onboarding_link_link_options;
  'link_type': string;
  'object': string;
  'on_behalf_of'?: string;
  'redirect_url': string;
};

export type terminal.reader = {
  'action'?: Record<string, any>;
  'device_sw_version'?: string;
  'device_type': string;
  'id': string;
  'ip_address'?: string;
  'label': string;
  'last_seen_at'?: number;
  'livemode': boolean;
  'location'?: Record<string, any>;
  'metadata': Record<string, any>;
  'object': string;
  'serial_number': string;
  'status'?: string;
};

export type terminal.refund = Record<string, any>;

export type terminal_configuration_configuration_resource_cellular_config = {
  'enabled': boolean;
};

export type terminal_configuration_configuration_resource_currency_specific_config = {
  'fixed_amounts'?: number[];
  'percentages'?: number[];
  'smart_tip_threshold'?: number;
};

export type terminal_configuration_configuration_resource_device_type_specific_config = {
  'splashscreen'?: Record<string, any>;
};

export type terminal_configuration_configuration_resource_enterprise_peap_wifi = {
  'ca_certificate_file'?: string;
  'password': string;
  'ssid': string;
  'username': string;
};

export type terminal_configuration_configuration_resource_enterprise_tls_wifi = {
  'ca_certificate_file'?: string;
  'client_certificate_file': string;
  'private_key_file': string;
  'private_key_file_password'?: string;
  'ssid': string;
};

export type terminal_configuration_configuration_resource_offline_config = {
  'enabled'?: boolean;
};

export type terminal_configuration_configuration_resource_personal_psk_wifi = {
  'password': string;
  'ssid': string;
};

export type terminal_configuration_configuration_resource_reboot_window = {
  'end_hour': number;
  'start_hour': number;
};

export type terminal_configuration_configuration_resource_tipping = {
  'aed'?: terminal_configuration_configuration_resource_currency_specific_config;
  'aud'?: terminal_configuration_configuration_resource_currency_specific_config;
  'cad'?: terminal_configuration_configuration_resource_currency_specific_config;
  'chf'?: terminal_configuration_configuration_resource_currency_specific_config;
  'czk'?: terminal_configuration_configuration_resource_currency_specific_config;
  'dkk'?: terminal_configuration_configuration_resource_currency_specific_config;
  'eur'?: terminal_configuration_configuration_resource_currency_specific_config;
  'gbp'?: terminal_configuration_configuration_resource_currency_specific_config;
  'gip'?: terminal_configuration_configuration_resource_currency_specific_config;
  'hkd'?: terminal_configuration_configuration_resource_currency_specific_config;
  'huf'?: terminal_configuration_configuration_resource_currency_specific_config;
  'jpy'?: terminal_configuration_configuration_resource_currency_specific_config;
  'mxn'?: terminal_configuration_configuration_resource_currency_specific_config;
  'myr'?: terminal_configuration_configuration_resource_currency_specific_config;
  'nok'?: terminal_configuration_configuration_resource_currency_specific_config;
  'nzd'?: terminal_configuration_configuration_resource_currency_specific_config;
  'pln'?: terminal_configuration_configuration_resource_currency_specific_config;
  'ron'?: terminal_configuration_configuration_resource_currency_specific_config;
  'sek'?: terminal_configuration_configuration_resource_currency_specific_config;
  'sgd'?: terminal_configuration_configuration_resource_currency_specific_config;
  'usd'?: terminal_configuration_configuration_resource_currency_specific_config;
};

export type terminal_configuration_configuration_resource_wifi_config = {
  'enterprise_eap_peap'?: terminal_configuration_configuration_resource_enterprise_peap_wifi;
  'enterprise_eap_tls'?: terminal_configuration_configuration_resource_enterprise_tls_wifi;
  'personal_psk'?: terminal_configuration_configuration_resource_personal_psk_wifi;
  'type': string;
};

export type terminal_onboarding_link_apple_terms_and_conditions = {
  'allow_relinking'?: boolean;
  'merchant_display_name': string;
};

export type terminal_onboarding_link_link_options = {
  'apple_terms_and_conditions'?: Record<string, any>;
};

export type terminal_reader_reader_resource_cart = {
  'currency': string;
  'line_items': terminal_reader_reader_resource_line_item[];
  'tax'?: number;
  'total': number;
};

export type terminal_reader_reader_resource_choice = {
  'id'?: string;
  'style'?: string;
  'text': string;
};

export type terminal_reader_reader_resource_collect_config = {
  'enable_customer_cancellation'?: boolean;
  'skip_tipping'?: boolean;
  'tipping'?: terminal_reader_reader_resource_tipping_config;
};

export type terminal_reader_reader_resource_collect_inputs_action = {
  'inputs': terminal_reader_reader_resource_input[];
  'metadata'?: Record<string, any>;
};

export type terminal_reader_reader_resource_collect_payment_method_action = {
  'collect_config'?: terminal_reader_reader_resource_collect_config;
  'payment_intent': Record<string, any>;
  'payment_method'?: payment_method;
};

export type terminal_reader_reader_resource_confirm_config = {
  'return_url'?: string;
};

export type terminal_reader_reader_resource_confirm_payment_intent_action = {
  'confirm_config'?: terminal_reader_reader_resource_confirm_config;
  'payment_intent': Record<string, any>;
};

export type terminal_reader_reader_resource_custom_text = {
  'description'?: string;
  'skip_button'?: string;
  'submit_button'?: string;
  'title'?: string;
};

export type terminal_reader_reader_resource_email = {
  'value'?: string;
};

export type terminal_reader_reader_resource_file_metadata = {
  'created_at': number;
  'filename': string;
  'size': number;
  'type': string;
};

export type terminal_reader_reader_resource_input = {
  'custom_text'?: Record<string, any>;
  'email'?: terminal_reader_reader_resource_email;
  'numeric'?: terminal_reader_reader_resource_numeric;
  'phone'?: terminal_reader_reader_resource_phone;
  'required'?: boolean;
  'selection'?: terminal_reader_reader_resource_selection;
  'signature'?: terminal_reader_reader_resource_signature;
  'skipped'?: boolean;
  'text'?: terminal_reader_reader_resource_text;
  'toggles'?: terminal_reader_reader_resource_toggle[];
  'type': string;
};

export type terminal_reader_reader_resource_line_item = {
  'amount': number;
  'description': string;
  'quantity': number;
};

export type terminal_reader_reader_resource_numeric = {
  'value'?: string;
};

export type terminal_reader_reader_resource_phone = {
  'value'?: string;
};

export type terminal_reader_reader_resource_print_content = {
  'image'?: terminal_reader_reader_resource_file_metadata;
  'type': string;
};

export type terminal_reader_reader_resource_process_config = {
  'enable_customer_cancellation'?: boolean;
  'return_url'?: string;
  'skip_tipping'?: boolean;
  'tipping'?: terminal_reader_reader_resource_tipping_config;
};

export type terminal_reader_reader_resource_process_payment_intent_action = {
  'payment_intent': Record<string, any>;
  'process_config'?: terminal_reader_reader_resource_process_config;
};

export type terminal_reader_reader_resource_process_setup_config = {
  'enable_customer_cancellation'?: boolean;
};

export type terminal_reader_reader_resource_process_setup_intent_action = {
  'generated_card'?: string;
  'process_config'?: terminal_reader_reader_resource_process_setup_config;
  'setup_intent': Record<string, any>;
};

export type terminal_reader_reader_resource_reader_action = {
  'api_error'?: Record<string, any>;
  'collect_inputs'?: terminal_reader_reader_resource_collect_inputs_action;
  'collect_payment_method'?: terminal_reader_reader_resource_collect_payment_method_action;
  'confirm_payment_intent'?: terminal_reader_reader_resource_confirm_payment_intent_action;
  'failure_code'?: string;
  'failure_message'?: string;
  'print_content'?: terminal_reader_reader_resource_print_content;
  'process_payment_intent'?: terminal_reader_reader_resource_process_payment_intent_action;
  'process_setup_intent'?: terminal_reader_reader_resource_process_setup_intent_action;
  'refund_payment'?: terminal_reader_reader_resource_refund_payment_action;
  'set_reader_display'?: terminal_reader_reader_resource_set_reader_display_action;
  'status': string;
  'type': string;
};

export type terminal_reader_reader_resource_refund_payment_action = {
  'amount'?: number;
  'charge'?: Record<string, any>;
  'metadata'?: Record<string, any>;
  'payment_intent'?: Record<string, any>;
  'reason'?: string;
  'refund'?: Record<string, any>;
  'refund_application_fee'?: boolean;
  'refund_payment_config'?: terminal_reader_reader_resource_refund_payment_config;
  'reverse_transfer'?: boolean;
};

export type terminal_reader_reader_resource_refund_payment_config = {
  'enable_customer_cancellation'?: boolean;
};

export type terminal_reader_reader_resource_selection = {
  'choices': terminal_reader_reader_resource_choice[];
  'id'?: string;
  'text'?: string;
};

export type terminal_reader_reader_resource_set_reader_display_action = {
  'cart'?: Record<string, any>;
  'type': string;
};

export type terminal_reader_reader_resource_signature = {
  'value'?: string;
};

export type terminal_reader_reader_resource_text = {
  'value'?: string;
};

export type terminal_reader_reader_resource_tipping_config = {
  'amount_eligible'?: number;
};

export type terminal_reader_reader_resource_toggle = {
  'default_value'?: string;
  'description'?: string;
  'title'?: string;
  'value'?: string;
};

export type test_helpers.test_clock = {
  'created': number;
  'deletes_after': number;
  'frozen_time': number;
  'id': string;
  'livemode': boolean;
  'name'?: string;
  'object': string;
  'status': string;
  'status_details': billing_clocks_resource_status_details_status_details;
};

export type three_d_secure_details = {
  'authentication_flow'?: string;
  'electronic_commerce_indicator'?: string;
  'result'?: string;
  'result_reason'?: string;
  'transaction_id'?: string;
  'version'?: string;
};

export type three_d_secure_details_charge = {
  'authentication_flow'?: string;
  'electronic_commerce_indicator'?: string;
  'exemption_indicator'?: string;
  'exemption_indicator_applied'?: boolean;
  'result'?: string;
  'result_reason'?: string;
  'transaction_id'?: string;
  'version'?: string;
};

export type three_d_secure_usage = {
  'supported': boolean;
};

export type thresholds_resource_usage_alert_filter = {
  'customer'?: Record<string, any>;
  'type': string;
};

export type thresholds_resource_usage_threshold_config = {
  'filters'?: thresholds_resource_usage_alert_filter[];
  'gte': number;
  'meter': Record<string, any>;
  'recurrence': string;
};

export type token = {
  'bank_account'?: bank_account;
  'card'?: card;
  'client_ip'?: string;
  'created': number;
  'id': string;
  'livemode': boolean;
  'object': string;
  'type': string;
  'used': boolean;
};

export type token_card_networks = {
  'preferred'?: string;
};

export type topup = {
  'amount': number;
  'balance_transaction'?: Record<string, any>;
  'created': number;
  'currency': string;
  'description'?: string;
  'expected_availability_date'?: number;
  'failure_code'?: string;
  'failure_message'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'source'?: Record<string, any>;
  'statement_descriptor'?: string;
  'status': string;
  'transfer_group'?: string;
};

export type transfer = {
  'amount': number;
  'amount_reversed': number;
  'balance_transaction'?: Record<string, any>;
  'created': number;
  'currency': string;
  'description'?: string;
  'destination'?: Record<string, any>;
  'destination_payment'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'reversals': {
    'data': transfer_reversal[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'reversed': boolean;
  'source_transaction'?: Record<string, any>;
  'source_type'?: string;
  'transfer_group'?: string;
};

export type transfer_data = {
  'amount'?: number;
  'description'?: string;
  'destination': Record<string, any>;
  'metadata'?: Record<string, any>;
  'payment_data'?: payment_data;
};

export type transfer_reversal = {
  'amount': number;
  'balance_transaction'?: Record<string, any>;
  'created': number;
  'currency': string;
  'destination_payment_refund'?: Record<string, any>;
  'id': string;
  'metadata'?: Record<string, any>;
  'object': string;
  'source_refund'?: Record<string, any>;
  'transfer': Record<string, any>;
};

export type transfer_schedule = {
  'delay_days': number;
  'interval': string;
  'monthly_anchor'?: number;
  'monthly_payout_days'?: number[];
  'weekly_anchor'?: string;
  'weekly_payout_days'?: string[];
};

export type transform_quantity = {
  'divide_by': number;
  'round': string;
};

export type transform_usage = {
  'divide_by': number;
  'round': string;
};

export type treasury.credit_reversal = {
  'amount': number;
  'created': number;
  'currency': string;
  'financial_account': string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'network': string;
  'object': string;
  'received_credit': string;
  'status': string;
  'status_transitions': treasury_received_credits_resource_status_transitions;
  'transaction'?: Record<string, any>;
};

export type treasury.debit_reversal = {
  'amount': number;
  'created': number;
  'currency': string;
  'financial_account'?: string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'linked_flows'?: Record<string, any>;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'network': string;
  'object': string;
  'received_debit': string;
  'status': string;
  'status_transitions': treasury_received_debits_resource_status_transitions;
  'transaction'?: Record<string, any>;
};

export type treasury.financial_account = {
  'active_features'?: string[];
  'balance': treasury_financial_accounts_resource_balance;
  'country': string;
  'created': number;
  'features'?: treasury.financial_account_features;
  'financial_addresses': treasury_financial_accounts_resource_financial_address[];
  'id': string;
  'is_default'?: boolean;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'nickname'?: string;
  'object': string;
  'pending_features'?: string[];
  'platform_restrictions'?: Record<string, any>;
  'restricted_features'?: string[];
  'status': string;
  'status_details': treasury_financial_accounts_resource_status_details;
  'supported_currencies': string[];
};

export type treasury.financial_account_features = {
  'card_issuing'?: treasury_financial_accounts_resource_toggle_settings;
  'deposit_insurance'?: treasury_financial_accounts_resource_toggle_settings;
  'financial_addresses'?: treasury_financial_accounts_resource_financial_addresses_features;
  'inbound_transfers'?: treasury_financial_accounts_resource_inbound_transfers;
  'intra_stripe_flows'?: treasury_financial_accounts_resource_toggle_settings;
  'object': string;
  'outbound_payments'?: treasury_financial_accounts_resource_outbound_payments;
  'outbound_transfers'?: treasury_financial_accounts_resource_outbound_transfers;
};

export type treasury.inbound_transfer = {
  'amount': number;
  'cancelable': boolean;
  'created': number;
  'currency': string;
  'description'?: string;
  'failure_details'?: Record<string, any>;
  'financial_account': string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'linked_flows': treasury_inbound_transfers_resource_inbound_transfer_resource_linked_flows;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'origin_payment_method'?: string;
  'origin_payment_method_details'?: Record<string, any>;
  'returned'?: boolean;
  'statement_descriptor': string;
  'status': string;
  'status_transitions': treasury_inbound_transfers_resource_inbound_transfer_resource_status_transitions;
  'transaction'?: Record<string, any>;
};

export type treasury.outbound_payment = {
  'amount': number;
  'cancelable': boolean;
  'created': number;
  'currency': string;
  'customer'?: string;
  'description'?: string;
  'destination_payment_method'?: string;
  'destination_payment_method_details'?: Record<string, any>;
  'end_user_details'?: Record<string, any>;
  'expected_arrival_date': number;
  'financial_account': string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'returned_details'?: Record<string, any>;
  'statement_descriptor': string;
  'status': string;
  'status_transitions': treasury_outbound_payments_resource_outbound_payment_resource_status_transitions;
  'tracking_details'?: Record<string, any>;
  'transaction': Record<string, any>;
};

export type treasury.outbound_transfer = {
  'amount': number;
  'cancelable': boolean;
  'created': number;
  'currency': string;
  'description'?: string;
  'destination_payment_method'?: string;
  'destination_payment_method_details': outbound_transfers_payment_method_details;
  'expected_arrival_date': number;
  'financial_account': string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'returned_details'?: Record<string, any>;
  'statement_descriptor': string;
  'status': string;
  'status_transitions': treasury_outbound_transfers_resource_status_transitions;
  'tracking_details'?: Record<string, any>;
  'transaction': Record<string, any>;
};

export type treasury.received_credit = {
  'amount': number;
  'created': number;
  'currency': string;
  'description': string;
  'failure_code'?: string;
  'financial_account'?: string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'initiating_payment_method_details': treasury_shared_resource_initiating_payment_method_details_initiating_payment_method_details;
  'linked_flows': treasury_received_credits_resource_linked_flows;
  'livemode': boolean;
  'network': string;
  'object': string;
  'reversal_details'?: Record<string, any>;
  'status': string;
  'transaction'?: Record<string, any>;
};

export type treasury.received_debit = {
  'amount': number;
  'created': number;
  'currency': string;
  'description': string;
  'failure_code'?: string;
  'financial_account'?: string;
  'hosted_regulatory_receipt_url'?: string;
  'id': string;
  'initiating_payment_method_details'?: treasury_shared_resource_initiating_payment_method_details_initiating_payment_method_details;
  'linked_flows': treasury_received_debits_resource_linked_flows;
  'livemode': boolean;
  'network': string;
  'object': string;
  'reversal_details'?: Record<string, any>;
  'status': string;
  'transaction'?: Record<string, any>;
};

export type treasury.transaction = {
  'amount': number;
  'balance_impact': treasury_transactions_resource_balance_impact;
  'created': number;
  'currency': string;
  'description': string;
  'entries'?: {
    'data': treasury.transaction_entry[];
    'has_more': boolean;
    'object': string;
    'url': string;
  };
  'financial_account': string;
  'flow'?: string;
  'flow_details'?: Record<string, any>;
  'flow_type': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status': string;
  'status_transitions': treasury_transactions_resource_abstract_transaction_resource_status_transitions;
};

export type treasury.transaction_entry = {
  'balance_impact': treasury_transactions_resource_balance_impact;
  'created': number;
  'currency': string;
  'effective_at': number;
  'financial_account': string;
  'flow'?: string;
  'flow_details'?: Record<string, any>;
  'flow_type': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'transaction': Record<string, any>;
  'type': string;
};

export type treasury_financial_accounts_resource_aba_record = {
  'account_holder_name': string;
  'account_number'?: string;
  'account_number_last4': string;
  'bank_name': string;
  'routing_number': string;
};

export type treasury_financial_accounts_resource_aba_toggle_settings = {
  'requested': boolean;
  'status': string;
  'status_details': treasury_financial_accounts_resource_toggles_setting_status_details[];
};

export type treasury_financial_accounts_resource_balance = {
  'cash': Record<string, any>;
  'inbound_pending': Record<string, any>;
  'outbound_pending': Record<string, any>;
};

export type treasury_financial_accounts_resource_closed_status_details = {
  'reasons': string[];
};

export type treasury_financial_accounts_resource_financial_address = {
  'aba'?: treasury_financial_accounts_resource_aba_record;
  'supported_networks'?: string[];
  'type': string;
};

export type treasury_financial_accounts_resource_financial_addresses_features = {
  'aba'?: treasury_financial_accounts_resource_aba_toggle_settings;
};

export type treasury_financial_accounts_resource_inbound_ach_toggle_settings = {
  'requested': boolean;
  'status': string;
  'status_details': treasury_financial_accounts_resource_toggles_setting_status_details[];
};

export type treasury_financial_accounts_resource_inbound_transfers = {
  'ach'?: treasury_financial_accounts_resource_inbound_ach_toggle_settings;
};

export type treasury_financial_accounts_resource_outbound_ach_toggle_settings = {
  'requested': boolean;
  'status': string;
  'status_details': treasury_financial_accounts_resource_toggles_setting_status_details[];
};

export type treasury_financial_accounts_resource_outbound_payments = {
  'ach'?: treasury_financial_accounts_resource_outbound_ach_toggle_settings;
  'us_domestic_wire'?: treasury_financial_accounts_resource_toggle_settings;
};

export type treasury_financial_accounts_resource_outbound_transfers = {
  'ach'?: treasury_financial_accounts_resource_outbound_ach_toggle_settings;
  'us_domestic_wire'?: treasury_financial_accounts_resource_toggle_settings;
};

export type treasury_financial_accounts_resource_platform_restrictions = {
  'inbound_flows'?: string;
  'outbound_flows'?: string;
};

export type treasury_financial_accounts_resource_status_details = {
  'closed'?: Record<string, any>;
};

export type treasury_financial_accounts_resource_toggle_settings = {
  'requested': boolean;
  'status': string;
  'status_details': treasury_financial_accounts_resource_toggles_setting_status_details[];
};

export type treasury_financial_accounts_resource_toggles_setting_status_details = {
  'code': string;
  'resolution'?: string;
  'restriction'?: string;
};

export type treasury_inbound_transfers_resource_failure_details = {
  'code': string;
};

export type treasury_inbound_transfers_resource_inbound_transfer_resource_linked_flows = {
  'received_debit'?: string;
};

export type treasury_inbound_transfers_resource_inbound_transfer_resource_status_transitions = {
  'canceled_at'?: number;
  'failed_at'?: number;
  'succeeded_at'?: number;
};

export type treasury_outbound_payments_resource_ach_tracking_details = {
  'trace_id': string;
};

export type treasury_outbound_payments_resource_outbound_payment_resource_end_user_details = {
  'ip_address'?: string;
  'present': boolean;
};

export type treasury_outbound_payments_resource_outbound_payment_resource_status_transitions = {
  'canceled_at'?: number;
  'failed_at'?: number;
  'posted_at'?: number;
  'returned_at'?: number;
};

export type treasury_outbound_payments_resource_outbound_payment_resource_tracking_details = {
  'ach'?: treasury_outbound_payments_resource_ach_tracking_details;
  'type': string;
  'us_domestic_wire'?: treasury_outbound_payments_resource_us_domestic_wire_tracking_details;
};

export type treasury_outbound_payments_resource_returned_status = {
  'code': string;
  'transaction': Record<string, any>;
};

export type treasury_outbound_payments_resource_us_domestic_wire_tracking_details = {
  'chips'?: string;
  'imad'?: string;
  'omad'?: string;
};

export type treasury_outbound_transfers_resource_ach_tracking_details = {
  'trace_id': string;
};

export type treasury_outbound_transfers_resource_outbound_transfer_resource_tracking_details = {
  'ach'?: treasury_outbound_transfers_resource_ach_tracking_details;
  'type': string;
  'us_domestic_wire'?: treasury_outbound_transfers_resource_us_domestic_wire_tracking_details;
};

export type treasury_outbound_transfers_resource_returned_details = {
  'code': string;
  'transaction': Record<string, any>;
};

export type treasury_outbound_transfers_resource_status_transitions = {
  'canceled_at'?: number;
  'failed_at'?: number;
  'posted_at'?: number;
  'returned_at'?: number;
};

export type treasury_outbound_transfers_resource_us_domestic_wire_tracking_details = {
  'chips'?: string;
  'imad'?: string;
  'omad'?: string;
};

export type treasury_received_credits_resource_linked_flows = {
  'credit_reversal'?: string;
  'issuing_authorization'?: string;
  'issuing_transaction'?: string;
  'source_flow'?: string;
  'source_flow_details'?: Record<string, any>;
  'source_flow_type'?: string;
};

export type treasury_received_credits_resource_reversal_details = {
  'deadline'?: number;
  'restricted_reason'?: string;
};

export type treasury_received_credits_resource_source_flows_details = {
  'credit_reversal'?: treasury.credit_reversal;
  'outbound_payment'?: treasury.outbound_payment;
  'outbound_transfer'?: treasury.outbound_transfer;
  'payout'?: payout;
  'type': string;
};

export type treasury_received_credits_resource_status_transitions = {
  'posted_at'?: number;
};

export type treasury_received_debits_resource_debit_reversal_linked_flows = {
  'issuing_dispute'?: string;
};

export type treasury_received_debits_resource_linked_flows = {
  'debit_reversal'?: string;
  'inbound_transfer'?: string;
  'issuing_authorization'?: string;
  'issuing_transaction'?: string;
  'payout'?: string;
  'topup'?: string;
};

export type treasury_received_debits_resource_reversal_details = {
  'deadline'?: number;
  'restricted_reason'?: string;
};

export type treasury_received_debits_resource_status_transitions = {
  'completed_at'?: number;
};

export type treasury_shared_resource_billing_details = {
  'address': address;
  'email'?: string;
  'name'?: string;
};

export type treasury_shared_resource_initiating_payment_method_details_initiating_payment_method_details = {
  'balance'?: string;
  'billing_details': treasury_shared_resource_billing_details;
  'financial_account'?: received_payment_method_details_financial_account;
  'issuing_card'?: string;
  'type': string;
  'us_bank_account'?: treasury_shared_resource_initiating_payment_method_details_us_bank_account;
};

export type treasury_shared_resource_initiating_payment_method_details_us_bank_account = {
  'bank_name'?: string;
  'last4'?: string;
  'routing_number'?: string;
};

export type treasury_transactions_resource_abstract_transaction_resource_status_transitions = {
  'posted_at'?: number;
  'void_at'?: number;
};

export type treasury_transactions_resource_balance_impact = {
  'cash': number;
  'inbound_pending': number;
  'outbound_pending': number;
};

export type treasury_transactions_resource_flow_details = {
  'credit_reversal'?: treasury.credit_reversal;
  'debit_reversal'?: treasury.debit_reversal;
  'inbound_transfer'?: treasury.inbound_transfer;
  'issuing_authorization'?: issuing.authorization;
  'outbound_payment'?: treasury.outbound_payment;
  'outbound_transfer'?: treasury.outbound_transfer;
  'received_credit'?: treasury.received_credit;
  'received_debit'?: treasury.received_debit;
  'type': string;
};

export type us_bank_account_networks = {
  'preferred'?: string;
  'supported': string[];
};

export type v2.billing.meter_event = {
  'created': string;
  'event_name': string;
  'identifier': string;
  'livemode': boolean;
  'object': string;
  'payload': Record<string, any>;
  'timestamp': string;
};

export type v2.billing.meter_event_adjustment = {
  'cancel': {
    'identifier': string;
  };
  'created': string;
  'event_name': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'status': string;
  'type': string;
};

export type v2.billing.meter_event_session = {
  'authentication_token': string;
  'created': string;
  'expires_at': string;
  'id': string;
  'livemode': boolean;
  'object': string;
};

export type v2.commerce.product_catalog_import = {
  'created': string;
  'feed_type': string;
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'status': string;
  'status_details'?: {
    'awaiting_upload'?: {
      'upload_url': {
        'expires_at': string;
        'url': string;
      };
    };
    'failed'?: {
      'code': string;
      'failure_message': string;
      'type': string;
    };
    'processing'?: {
      'error_count': string;
      'success_count': string;
    };
    'succeeded'?: {
      'success_count': string;
    };
    'succeeded_with_errors'?: {
      'error_count': string;
      'error_file': {
        'content_type': string;
        'download_url': {
          'expires_at': string;
          'url': string;
        };
        'size': string;
      };
      'samples': {
        'error_message': string;
        'field': string;
        'id': string;
        'row': string;
      }[];
      'success_count': string;
    };
  };
};

export type v2.core.account = {
  'applied_configurations': string[];
  'closed'?: boolean;
  'configuration'?: {
    'customer'?: {
      'applied': boolean;
      'automatic_indirect_tax'?: {
        'exempt'?: string;
        'ip_address'?: string;
        'location'?: {
          'country'?: string;
          'state'?: string;
        };
        'location_source'?: string;
      };
      'billing'?: {
        'default_payment_method'?: string;
        'invoice'?: {
          'custom_fields': {
            'name': string;
            'value': string;
          }[];
          'footer'?: string;
          'next_sequence'?: number;
          'prefix'?: string;
          'rendering'?: {
            'amount_tax_display'?: string;
            'template'?: string;
          };
        };
      };
      'capabilities'?: {
        'automatic_indirect_tax'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
      };
      'shipping'?: {
        'address'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
        };
        'name'?: string;
        'phone'?: string;
      };
      'test_clock'?: string;
    };
    'merchant'?: {
      'applied': boolean;
      'bacs_debit_payments'?: {
        'display_name'?: string;
        'service_user_number'?: string;
      };
      'branding'?: {
        'icon'?: string;
        'logo'?: string;
        'primary_color'?: string;
        'secondary_color'?: string;
      };
      'capabilities'?: {
        'ach_debit_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'acss_debit_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'affirm_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'afterpay_clearpay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'alma_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'amazon_pay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'au_becs_debit_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'bacs_debit_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'bancontact_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'blik_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'boleto_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'card_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'cartes_bancaires_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'cashapp_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'eps_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'fpx_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'gb_bank_transfer_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'grabpay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'ideal_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'jcb_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'jp_bank_transfer_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'kakao_pay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'klarna_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'konbini_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'kr_card_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'link_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'mobilepay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'multibanco_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'mx_bank_transfer_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'naver_pay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'oxxo_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'p24_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'pay_by_bank_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'payco_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'paynow_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'promptpay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'revolut_pay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'samsung_pay_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'sepa_bank_transfer_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'sepa_debit_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'stripe_balance'?: {
          'payouts'?: {
            'status': string;
            'status_details': {
              'code': string;
              'resolution': string;
            }[];
          };
        };
        'swish_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'twint_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'us_bank_transfer_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
        'zip_payments'?: {
          'status': string;
          'status_details': {
            'code': string;
            'resolution': string;
          }[];
        };
      };
      'card_payments'?: {
        'decline_on'?: {
          'avs_failure'?: boolean;
          'cvc_failure'?: boolean;
        };
      };
      'konbini_payments'?: {
        'support'?: {
          'email'?: string;
          'hours'?: {
            'end_time'?: string;
            'start_time'?: string;
          };
          'phone'?: string;
        };
      };
      'mcc'?: string;
      'script_statement_descriptor'?: {
        'kana'?: {
          'descriptor'?: string;
          'prefix'?: string;
        };
        'kanji'?: {
          'descriptor'?: string;
          'prefix'?: string;
        };
      };
      'sepa_debit_payments'?: {
        'creditor_id'?: string;
      };
      'statement_descriptor'?: {
        'descriptor'?: string;
        'prefix'?: string;
      };
      'support'?: {
        'address'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
          'town'?: string;
        };
        'email'?: string;
        'phone'?: string;
        'url'?: string;
      };
    };
    'recipient'?: {
      'applied': boolean;
      'capabilities'?: {
        'stripe_balance'?: {
          'payouts'?: {
            'status': string;
            'status_details': {
              'code': string;
              'resolution': string;
            }[];
          };
          'stripe_transfers'?: {
            'status': string;
            'status_details': {
              'code': string;
              'resolution': string;
            }[];
          };
        };
      };
    };
  };
  'contact_email'?: string;
  'contact_phone'?: string;
  'created': string;
  'dashboard'?: string;
  'defaults'?: {
    'currency'?: string;
    'locales'?: string[];
    'profile'?: {
      'business_url'?: string;
      'doing_business_as'?: string;
      'product_description'?: string;
    };
    'responsibilities': {
      'fees_collector'?: string;
      'losses_collector'?: string;
      'requirements_collector': string;
    };
  };
  'display_name'?: string;
  'future_requirements'?: {
    'entries'?: {
      'awaiting_action_from': string;
      'description': string;
      'errors': {
        'code': string;
        'description': string;
      }[];
      'impact': {
        'restricts_capabilities'?: {
          'capability': string;
          'configuration': string;
          'deadline': {
            'status': string;
          };
        }[];
      };
      'minimum_deadline': {
        'status': string;
      };
      'reference'?: {
        'inquiry'?: string;
        'resource'?: string;
        'type': string;
      };
      'requested_reasons': {
        'code': string;
      }[];
    }[];
    'minimum_transition_date'?: string;
    'summary'?: {
      'minimum_deadline'?: {
        'status': string;
        'time'?: string;
      };
    };
  };
  'id': string;
  'identity'?: {
    'attestations'?: {
      'directorship_declaration'?: {
        'date'?: string;
        'ip'?: string;
        'user_agent'?: string;
      };
      'ownership_declaration'?: {
        'date'?: string;
        'ip'?: string;
        'user_agent'?: string;
      };
      'persons_provided'?: {
        'directors'?: boolean;
        'executives'?: boolean;
        'owners'?: boolean;
        'ownership_exemption_reason'?: string;
      };
      'representative_declaration'?: {
        'date'?: string;
        'ip'?: string;
        'user_agent'?: string;
      };
      'terms_of_service'?: {
        'account'?: {
          'date'?: string;
          'ip'?: string;
          'user_agent'?: string;
        };
      };
    };
    'business_details'?: {
      'address'?: {
        'city'?: string;
        'country'?: string;
        'line1'?: string;
        'line2'?: string;
        'postal_code'?: string;
        'state'?: string;
        'town'?: string;
      };
      'annual_revenue'?: {
        'amount'?: {
          'currency': string;
          'value': number;
        };
        'fiscal_year_end'?: string;
      };
      'documents'?: {
        'bank_account_ownership_verification'?: {
          'files': string[];
          'type': string;
        };
        'company_license'?: {
          'files': string[];
          'type': string;
        };
        'company_memorandum_of_association'?: {
          'files': string[];
          'type': string;
        };
        'company_ministerial_decree'?: {
          'files': string[];
          'type': string;
        };
        'company_registration_verification'?: {
          'files': string[];
          'type': string;
        };
        'company_tax_id_verification'?: {
          'files': string[];
          'type': string;
        };
        'primary_verification'?: {
          'front_back': {
            'back'?: string;
            'front': string;
          };
          'type': string;
        };
        'proof_of_address'?: {
          'files': string[];
          'type': string;
        };
        'proof_of_registration'?: {
          'files': string[];
          'signer'?: {
            'person': string;
          };
          'type': string;
        };
        'proof_of_ultimate_beneficial_ownership'?: {
          'files': string[];
          'signer'?: {
            'person': string;
          };
          'type': string;
        };
      };
      'estimated_worker_count'?: number;
      'id_numbers'?: {
        'registrar'?: string;
        'type': string;
      }[];
      'monthly_estimated_revenue'?: {
        'amount'?: {
          'currency': string;
          'value': number;
        };
      };
      'phone'?: string;
      'registered_name'?: string;
      'registration_date'?: {
        'day': number;
        'month': number;
        'year': number;
      };
      'script_addresses'?: {
        'kana'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
          'town'?: string;
        };
        'kanji'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
          'town'?: string;
        };
      };
      'script_names'?: {
        'kana'?: {
          'registered_name'?: string;
        };
        'kanji'?: {
          'registered_name'?: string;
        };
      };
      'structure'?: string;
    };
    'country'?: string;
    'entity_type'?: string;
    'individual'?: {
      'account': string;
      'additional_addresses'?: {
        'city'?: string;
        'country'?: string;
        'line1'?: string;
        'line2'?: string;
        'postal_code'?: string;
        'purpose': string;
        'state'?: string;
        'town'?: string;
      }[];
      'additional_names'?: {
        'full_name'?: string;
        'given_name'?: string;
        'purpose': string;
        'surname'?: string;
      }[];
      'additional_terms_of_service'?: {
        'account'?: {
          'date'?: string;
          'ip'?: string;
          'user_agent'?: string;
        };
      };
      'address'?: {
        'city'?: string;
        'country'?: string;
        'line1'?: string;
        'line2'?: string;
        'postal_code'?: string;
        'state'?: string;
        'town'?: string;
      };
      'created': string;
      'date_of_birth'?: {
        'day': number;
        'month': number;
        'year': number;
      };
      'documents'?: {
        'company_authorization'?: {
          'files': string[];
          'type': string;
        };
        'passport'?: {
          'files': string[];
          'type': string;
        };
        'primary_verification'?: {
          'front_back': {
            'back'?: string;
            'front': string;
          };
          'type': string;
        };
        'secondary_verification'?: {
          'front_back': {
            'back'?: string;
            'front': string;
          };
          'type': string;
        };
        'visa'?: {
          'files': string[];
          'type': string;
        };
      };
      'email'?: string;
      'given_name'?: string;
      'id': string;
      'id_numbers'?: {
        'type': string;
      }[];
      'legal_gender'?: string;
      'metadata'?: Record<string, any>;
      'nationalities'?: string[];
      'object': string;
      'phone'?: string;
      'political_exposure'?: string;
      'relationship'?: {
        'authorizer'?: boolean;
        'director'?: boolean;
        'executive'?: boolean;
        'legal_guardian'?: boolean;
        'owner'?: boolean;
        'percent_ownership'?: string;
        'representative'?: boolean;
        'title'?: string;
      };
      'script_addresses'?: {
        'kana'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
          'town'?: string;
        };
        'kanji'?: {
          'city'?: string;
          'country'?: string;
          'line1'?: string;
          'line2'?: string;
          'postal_code'?: string;
          'state'?: string;
          'town'?: string;
        };
      };
      'script_names'?: {
        'kana'?: {
          'given_name'?: string;
          'surname'?: string;
        };
        'kanji'?: {
          'given_name'?: string;
          'surname'?: string;
        };
      };
      'surname'?: string;
      'updated': string;
    };
  };
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'object': string;
  'requirements'?: {
    'entries'?: {
      'awaiting_action_from': string;
      'description': string;
      'errors': {
        'code': string;
        'description': string;
      }[];
      'impact': {
        'restricts_capabilities'?: {
          'capability': string;
          'configuration': string;
          'deadline': {
            'status': string;
          };
        }[];
      };
      'minimum_deadline': {
        'status': string;
      };
      'reference'?: {
        'inquiry'?: string;
        'resource'?: string;
        'type': string;
      };
      'requested_reasons': {
        'code': string;
      }[];
    }[];
    'summary'?: {
      'minimum_deadline'?: {
        'status': string;
        'time'?: string;
      };
    };
  };
};

export type v2.core.account_link = {
  'account': string;
  'created': string;
  'expires_at': string;
  'livemode': boolean;
  'object': string;
  'url': string;
  'use_case': {
    'account_onboarding'?: {
      'collection_options'?: {
        'fields'?: string;
        'future_requirements'?: string;
      };
      'configurations': string[];
      'refresh_url': string;
      'return_url'?: string;
    };
    'account_update'?: {
      'collection_options'?: {
        'fields'?: string;
        'future_requirements'?: string;
      };
      'configurations': string[];
      'refresh_url': string;
      'return_url'?: string;
    };
    'type': string;
  };
};

export type v2.core.account_person = {
  'account': string;
  'additional_addresses'?: {
    'city'?: string;
    'country'?: string;
    'line1'?: string;
    'line2'?: string;
    'postal_code'?: string;
    'purpose': string;
    'state'?: string;
    'town'?: string;
  }[];
  'additional_names'?: {
    'full_name'?: string;
    'given_name'?: string;
    'purpose': string;
    'surname'?: string;
  }[];
  'additional_terms_of_service'?: {
    'account'?: {
      'date'?: string;
      'ip'?: string;
      'user_agent'?: string;
    };
  };
  'address'?: {
    'city'?: string;
    'country'?: string;
    'line1'?: string;
    'line2'?: string;
    'postal_code'?: string;
    'state'?: string;
    'town'?: string;
  };
  'created': string;
  'date_of_birth'?: {
    'day': number;
    'month': number;
    'year': number;
  };
  'documents'?: {
    'company_authorization'?: {
      'files': string[];
      'type': string;
    };
    'passport'?: {
      'files': string[];
      'type': string;
    };
    'primary_verification'?: {
      'front_back': {
        'back'?: string;
        'front': string;
      };
      'type': string;
    };
    'secondary_verification'?: {
      'front_back': {
        'back'?: string;
        'front': string;
      };
      'type': string;
    };
    'visa'?: {
      'files': string[];
      'type': string;
    };
  };
  'email'?: string;
  'given_name'?: string;
  'id': string;
  'id_numbers'?: {
    'type': string;
  }[];
  'legal_gender'?: string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'nationalities'?: string[];
  'object': string;
  'phone'?: string;
  'political_exposure'?: string;
  'relationship'?: {
    'authorizer'?: boolean;
    'director'?: boolean;
    'executive'?: boolean;
    'legal_guardian'?: boolean;
    'owner'?: boolean;
    'percent_ownership'?: string;
    'representative'?: boolean;
    'title'?: string;
  };
  'script_addresses'?: {
    'kana'?: {
      'city'?: string;
      'country'?: string;
      'line1'?: string;
      'line2'?: string;
      'postal_code'?: string;
      'state'?: string;
      'town'?: string;
    };
    'kanji'?: {
      'city'?: string;
      'country'?: string;
      'line1'?: string;
      'line2'?: string;
      'postal_code'?: string;
      'state'?: string;
      'town'?: string;
    };
  };
  'script_names'?: {
    'kana'?: {
      'given_name'?: string;
      'surname'?: string;
    };
    'kanji'?: {
      'given_name'?: string;
      'surname'?: string;
    };
  };
  'surname'?: string;
  'updated': string;
};

export type v2.core.account_person_token = {
  'created': string;
  'expires_at': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'used': boolean;
};

export type v2.core.account_token = {
  'created': string;
  'expires_at': string;
  'id': string;
  'livemode': boolean;
  'object': string;
  'used': boolean;
};

export type v2.core.event = {
  'changes'?: Record<string, any>;
  'context'?: string;
  'created': string;
  'data'?: Record<string, any>;
  'id': string;
  'livemode': boolean;
  'object': string;
  'reason'?: {
    'request'?: {
      'id': string;
      'idempotency_key': string;
    };
    'type': string;
  };
  'related_object'?: {
    'id': string;
    'type': string;
    'url': string;
  };
  'type': string;
};

export type v2.core.event_destination = {
  'amazon_eventbridge'?: {
    'aws_account_id': string;
    'aws_event_source_arn': string;
    'aws_event_source_status': string;
  };
  'azure_event_grid'?: {
    'azure_partner_topic_name': string;
    'azure_partner_topic_status': string;
    'azure_region': string;
    'azure_resource_group_name': string;
    'azure_subscription_id': string;
  };
  'created': string;
  'description': string;
  'enabled_events': string[];
  'event_payload': string;
  'events_from'?: string[];
  'id': string;
  'livemode': boolean;
  'metadata'?: Record<string, any>;
  'name': string;
  'object': string;
  'snapshot_api_version'?: string;
  'status': string;
  'status_details'?: {
    'disabled'?: {
      'reason': string;
    };
  };
  'type': string;
  'updated': string;
  'webhook_endpoint'?: {
    'signing_secret'?: string;
    'url'?: string;
  };
};

export type v2.deleted_object = {
  'id': string;
  'object'?: string;
};

export type v2.error = {
  'error': {
    'code': string;
    'doc_url'?: string;
    'message': string;
    'type'?: string;
    'user_message'?: string;
  };
};

export type v2.error.account_capability_not_supported = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.account_configuration_not_supported = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_controller_express_dash_without_application_losses_or_fees = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_controller_stripe_pricing_platform_liable = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_controller_ua_unsupported_configuration = {
  'error': {
    'code': string;
    'doc_url': string;
    'invalid_permutation': {
      'dashboard': string;
      'fees_collector': string;
      'losses_collector': string;
    };
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_controller_unsupported_configuration = {
  'error': {
    'code': string;
    'doc_url': string;
    'invalid_permutation': {
      'dashboard': string;
      'fees_collector': string;
      'losses_collector': string;
    };
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_controller_unsupported_configuration_private_preview = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_country_unsupported_currency = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.account_create_activation_required = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.account_creation_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.account_creation_liability_unacknowledged = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.account_creation_requirement_collection_and_liability_unacknowledged = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.account_creation_requirement_collection_unacknowledged = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.account_not_yet_compatible_with_v2 = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.account_rate_limit_exceeded = {
  'error': {
    'code': string;
    'message': string;
    'type': string;
  };
};

export type v2.error.account_terms_of_service_not_accepted = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.account_token_required = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.accounts_v2_access_blocked = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.additional_legal_guardian_not_allowed = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.additional_representative_not_allowed = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.additional_tos_only_allowed_for_legal_guardian = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.address_characters_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.address_country_identity_country_mismatch = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.address_country_mismatch = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.address_country_required = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.address_postal_code_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.address_state_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.address_town_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.archived_meter = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.attach_payment_method_to_customer = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.authorizer_duplicate = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.authorizer_relationship_invalid_for_representative = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.bgn_bank_accounts_unsupported = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.billing_meter_event_session_expired = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'type': string;
  };
};

export type v2.error.can_create_platform_owned_onboarding_accounts_required = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.cannot_create_connected_account = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.cannot_create_new_account_rejected = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.cannot_delete_account_with_balance = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.cannot_delete_customer_with_available_cash_balance = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.cannot_use_validate_location_on_customer_create = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.capability_cannot_be_unrequested_due_to_other_capability_requirement = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.capability_not_available_for_dashboard_type = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.capability_not_available_for_entity_type_in_country = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.capability_not_available_for_loss_collector = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.capability_not_available_in_country = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.capability_not_available_in_platform_country = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.capability_not_available_without_other_capability = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.capability_not_available_without_other_capability_in_country = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.configs_must_match_to_close = {
  'error': {
    'applied_configurations': string[];
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.configs_must_match_to_use_account_links = {
  'error': {
    'applied_configurations': string[];
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.configuration_cannot_be_deactivated = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.configuration_cannot_be_deactivated_due_to_other_capability_requirement = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.configuration_cannot_be_deactivated_due_to_other_configuration = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.configuration_cannot_be_updated_while_deactivated = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.configuration_creation_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.connect_identity_not_verified = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.connect_profile_not_submitted = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.cross_border_connected_account_creation_not_allowed = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.custom_account_beta = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.customer_invalid_tax_location = {
  'error': {
    'code': string;
    'incorrect_fields': {
      'field': string;
      'type': string;
    }[];
    'message': string;
    'validate_location': string;
  };
};

export type v2.error.date_of_birth_age_restriction = {
  'error': {
    'age_limit': string;
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.date_of_birth_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.default_currency_immutable = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.default_outbound_destination_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.default_payment_method_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.default_payment_method_invalid_type = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.directorship_declaration_not_allowed_during_account_creation = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.document_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.document_purpose_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.duplicate_meter_event = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.duplicate_person_not_allowed = {
  'error': {
    'code': string;
    'duplicate_person_id': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.email_domain_invalid_for_recipient = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.email_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.entity_type_not_supported_in_country = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.expired_azure_partner_authorization = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.high_risk_activities_none_cant_be_combined_with_other_options = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.id_number_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.idempotency_error = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.identity_country_required = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.immutable_identity_param = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.incorrect_account_for_person_token = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.incorrect_id_number_for_country = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.incorrect_token_wrong_type = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.individual_additional_person_not_allowed = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_account_token = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_azure_partner_authorization = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_azure_partner_configuration = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_cancel_configuration = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_id_number_for_structure = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.invalid_id_number_registrar = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
  };
};

export type v2.error.invalid_konbini_payments_support_hours = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_konbini_payments_support_phone_number = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.invalid_person_token = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invalid_relationship_for_identity_type_structure_and_country = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.invalid_timezone = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.invoice_rendering_template_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.ip_address_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.legal_guardian_representative_not_allowed = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.legal_guardian_requires_existing_representative = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.mcc_invalid = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.no_meter = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.non_connect_platform_accounts_v2_access_blocked = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.non_jp_kana_kanji_address = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.not_found = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.ownership_declaration_not_allowed_during_account_creation = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.param_alongside_account_token = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.param_alongside_person_token = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.payload_invalid_value = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.payload_no_customer_defined = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.payload_no_value_defined = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.pending_transactions_cannot_be_deleted = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.person_percent_ownership_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.person_token_required = {
  'error': {
    'code': string;
    'doc_url': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.phone_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.platform_registration_required = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.postal_code_required_for_jp_address = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.purpose_of_funds_description_must_be_empty_for_non_other_purpose_of_funds = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.registration_date_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.resource_missing = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.script_characters_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.shipping_address_required = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.shipping_name_required = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.statement_descriptor_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.stripe_loss_liable_cannot_be_deleted = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.structure_incompatible_for_entity_type_country = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.test_clock_disallowed_on_live_mode = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.test_clock_invalid = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.test_clocks_advance_in_progress = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.test_clocks_customer_limit_reached = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.token_already_used = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.token_expired = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.token_must_be_created_with_publishable_key = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.too_many_concurrent_requests = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.tos_acceptance_on_behalf_not_allowed = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.total_person_ownership_exceeded = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.unsupported_field_for_configs = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.unsupported_identity_field_for_configs = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.unsupported_postal_code = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.unsupported_state = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.url_invalid = {
  'error': {
    'code': string;
    'message': string;
    'user_message': string;
  };
};

export type v2.error.v1_account_instead_of_v2_account = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.v1_customer_instead_of_v2_account = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type v2.error.v1_token_invalid_in_v2 = {
  'error': {
    'code': string;
    'message': string;
  };
};

export type verification_session_redaction = {
  'status': string;
};

export type webhook_endpoint = {
  'api_version'?: string;
  'application'?: string;
  'created': number;
  'description'?: string;
  'enabled_events': string[];
  'id': string;
  'livemode': boolean;
  'metadata': Record<string, any>;
  'object': string;
  'secret'?: string;
  'status': string;
  'url': string;
};


  