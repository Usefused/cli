// Auto-generated. Do not edit manually.
// Powered by Fused - API integration infrastructure for teams that want control.
// Custom SDKs, native webhooks, and MCP servers from APIs you use.
// Learn more at: https://usefused.com

import { NoRetry } from './core';
import { NoRateLimit } from './core';
import { BaseClient } from './core';
import { normaliseError, buildGraphQLSelection } from './core';
// Auth providers are imported as values (they are instantiated with `new`).
import { HttpProvider } from './core';
import type { SDKConfig, AuthProvider, HttpRequest } from './core';
import type { payment_link, error, invoice, treasury.outbound_payment, payment_intent, terminal.reader, payment_method, invoice_payment, radar.payment_evaluation } from './types';


export interface GetPaymentLinksOptions {
  'active'?: string;
  'ending_before'?: string;
  'expand'?: string;
  'limit'?: number;
  'starting_after'?: string;
  headers?: Record<string, string>;
}
export interface GetPaymentLinksSuccessResult {
  'data': payment_link[];
  'has_more': boolean;
  'object': string;
  'url': string;
}
export type GetPaymentLinksErrorResult = error;
export type GetPaymentLinksResponse =
  | { ok: true; status: number; data: GetPaymentLinksSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: GetPaymentLinksErrorResult };

export interface PostInvoicesInvoicePayOptions {
  'invoice': string;
  headers?: Record<string, string>;
}
export type PostInvoicesInvoicePaySuccessResult = invoice;
export type PostInvoicesInvoicePayErrorResult = error;
export type PostInvoicesInvoicePayResponse =
  | { ok: true; status: number; data: PostInvoicesInvoicePaySuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostInvoicesInvoicePayErrorResult };

export interface PostTreasuryOutboundPaymentsOptions {
  headers?: Record<string, string>;
}
export type PostTreasuryOutboundPaymentsSuccessResult = treasury.outbound_payment;
export type PostTreasuryOutboundPaymentsErrorResult = error;
export type PostTreasuryOutboundPaymentsResponse =
  | { ok: true; status: number; data: PostTreasuryOutboundPaymentsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostTreasuryOutboundPaymentsErrorResult };

export interface PostPaymentIntentsIntentConfirmOptions {
  'intent': string;
  headers?: Record<string, string>;
}
export type PostPaymentIntentsIntentConfirmSuccessResult = payment_intent;
export type PostPaymentIntentsIntentConfirmErrorResult = error;
export type PostPaymentIntentsIntentConfirmResponse =
  | { ok: true; status: number; data: PostPaymentIntentsIntentConfirmSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostPaymentIntentsIntentConfirmErrorResult };

export interface PostPaymentIntentsOptions {
  headers?: Record<string, string>;
}
export type PostPaymentIntentsSuccessResult = payment_intent;
export type PostPaymentIntentsErrorResult = error;
export type PostPaymentIntentsResponse =
  | { ok: true; status: number; data: PostPaymentIntentsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostPaymentIntentsErrorResult };

export interface GetPaymentIntentsOptions {
  'created'?: string;
  'customer'?: string;
  'customer_account'?: string;
  'ending_before'?: string;
  'expand'?: string;
  'limit'?: number;
  'starting_after'?: string;
  headers?: Record<string, string>;
}
export interface GetPaymentIntentsSuccessResult {
  'data': payment_intent[];
  'has_more': boolean;
  'object': string;
  'url': string;
}
export type GetPaymentIntentsErrorResult = error;
export type GetPaymentIntentsResponse =
  | { ok: true; status: number; data: GetPaymentIntentsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: GetPaymentIntentsErrorResult };

export interface PostInvoicesInvoiceSendOptions {
  'invoice': string;
  headers?: Record<string, string>;
}
export type PostInvoicesInvoiceSendSuccessResult = invoice;
export type PostInvoicesInvoiceSendErrorResult = error;
export type PostInvoicesInvoiceSendResponse =
  | { ok: true; status: number; data: PostInvoicesInvoiceSendSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostInvoicesInvoiceSendErrorResult };

export interface PostTerminalReadersReaderConfirmPaymentIntentOptions {
  'reader': string;
  headers?: Record<string, string>;
}
export type PostTerminalReadersReaderConfirmPaymentIntentSuccessResult = terminal.reader;
export type PostTerminalReadersReaderConfirmPaymentIntentErrorResult = error;
export type PostTerminalReadersReaderConfirmPaymentIntentResponse =
  | { ok: true; status: number; data: PostTerminalReadersReaderConfirmPaymentIntentSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostTerminalReadersReaderConfirmPaymentIntentErrorResult };

export interface GetPaymentMethodsOptions {
  'allow_redisplay'?: string;
  'customer'?: string;
  'customer_account'?: string;
  'ending_before'?: string;
  'expand'?: string;
  'limit'?: number;
  'starting_after'?: string;
  'type'?: string;
  headers?: Record<string, string>;
}
export interface GetPaymentMethodsSuccessResult {
  'data': payment_method[];
  'has_more': boolean;
  'object': string;
  'url': string;
}
export type GetPaymentMethodsErrorResult = error;
export type GetPaymentMethodsResponse =
  | { ok: true; status: number; data: GetPaymentMethodsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: GetPaymentMethodsErrorResult };

export interface GetInvoicePaymentsOptions {
  'created'?: string;
  'ending_before'?: string;
  'expand'?: string;
  'invoice'?: string;
  'limit'?: number;
  'payment'?: string;
  'starting_after'?: string;
  'status'?: string;
  headers?: Record<string, string>;
}
export interface GetInvoicePaymentsSuccessResult {
  'data': invoice_payment[];
  'has_more': boolean;
  'object': string;
  'url': string;
}
export type GetInvoicePaymentsErrorResult = error;
export type GetInvoicePaymentsResponse =
  | { ok: true; status: number; data: GetInvoicePaymentsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: GetInvoicePaymentsErrorResult };

export interface PostRadarPaymentEvaluationsOptions {
  headers?: Record<string, string>;
}
export type PostRadarPaymentEvaluationsSuccessResult = radar.payment_evaluation;
export type PostRadarPaymentEvaluationsErrorResult = error;
export type PostRadarPaymentEvaluationsResponse =
  | { ok: true; status: number; data: PostRadarPaymentEvaluationsSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostRadarPaymentEvaluationsErrorResult };

export interface PostTestHelpersTreasuryOutboundPaymentsIdPostOptions {
  'id': string;
  headers?: Record<string, string>;
}
export type PostTestHelpersTreasuryOutboundPaymentsIdPostSuccessResult = treasury.outbound_payment;
export type PostTestHelpersTreasuryOutboundPaymentsIdPostErrorResult = error;
export type PostTestHelpersTreasuryOutboundPaymentsIdPostResponse =
  | { ok: true; status: number; data: PostTestHelpersTreasuryOutboundPaymentsIdPostSuccessResult; error: null }
  | { ok: false; status: number; data: null; error: PostTestHelpersTreasuryOutboundPaymentsIdPostErrorResult };

export interface StripeIntegrationAuth {
  username?: string;
  password?: string;
  token?: string;
}
export interface StripeIntegrationConfig extends SDKConfig {

}

export class StripeClient {
  private _auths: AuthProvider[] = [];
  
  private readonly _retry: NoRetry;
  private readonly _rateLimit: NoRateLimit;
  private readonly _http: BaseClient;
  private readonly _timeoutMs: number;

  constructor(config: StripeIntegrationConfig = {}) {
    
    this._retry = new NoRetry();
    this._rateLimit = new NoRateLimit();
    this._http = new BaseClient('Stripe', config.baseUrl || 'https://api.stripe.com/', config.timeoutMs ?? 30000, config.debug ?? false, { ...{}, ...config.headers });
    this._timeoutMs = config.timeoutMs ?? 30000;
  }

  public setAuth(credentials: StripeIntegrationAuth) {
    this._auths = [];
    if (credentials.username || credentials.password) { this._auths.push(new HttpProvider('basic', credentials.username || '', credentials.password || '')); }
    if (credentials.token) { this._auths.push(new HttpProvider('bearer', credentials.token)); }
  }


  private _buildUrl(path: string, pathParams: Record<string, any>, queryParams: Record<string, any>): string {
    let url = path;
    const qs = new URLSearchParams();
    
    // Loop: Replace path params safely
    for (const [key, value] of Object.entries(pathParams)) {
      // Condition: Ignore undefined keys
      if (value !== undefined) {
        url = url.replace(`{${key}}`, encodeURIComponent(String(value)));
      }
    }
    
    // Loop: Populate query params
    for (const [key, value] of Object.entries(queryParams)) {
      // Condition: Ignore undefined query items
      if (value !== undefined) {
        qs.append(key, String(value));
      }
    }
    
    const qsStr = qs.toString();
    // Condition: Append querystring safely
    if (qsStr) {
      // Ternary: Determine if '?' or '&' should be appended
      url += (url.includes('?') ? '&' : '?') + qsStr;
    }
    
    return url;
  }
  




  public readonly paymentLinks = {

  /**
   * List all payment links
   */
  getPaymentLinks: async (options?: GetPaymentLinksOptions): Promise<GetPaymentLinksResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'active': _active, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/payment_links', {}, { 'active': _active, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter });
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'GET',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'GetPaymentLinks', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as GetPaymentLinksSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as GetPaymentLinksErrorResult };
    }
  }
  };

  public readonly invoices = {

  /**
   * Pay an invoice
   */
  postInvoicesInvoicePay: async (options: PostInvoicesInvoicePayOptions): Promise<PostInvoicesInvoicePayResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'invoice': _invoice, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/invoices/{invoice}/pay', { 'invoice': _invoice }, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostInvoicesInvoicePay', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostInvoicesInvoicePaySuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostInvoicesInvoicePayErrorResult };
    }
  },

  /**
   * Send an invoice for manual payment
   */
  postInvoicesInvoiceSend: async (options: PostInvoicesInvoiceSendOptions): Promise<PostInvoicesInvoiceSendResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'invoice': _invoice, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/invoices/{invoice}/send', { 'invoice': _invoice }, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostInvoicesInvoiceSend', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostInvoicesInvoiceSendSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostInvoicesInvoiceSendErrorResult };
    }
  }
  };

  public readonly treasury = {

  /**
   * Create an OutboundPayment
   */
  postTreasuryOutboundPayments: async (options?: PostTreasuryOutboundPaymentsOptions): Promise<PostTreasuryOutboundPaymentsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/treasury/outbound_payments', {}, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostTreasuryOutboundPayments', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostTreasuryOutboundPaymentsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostTreasuryOutboundPaymentsErrorResult };
    }
  }
  };

  public readonly paymentIntents = {

  /**
   * Confirm a PaymentIntent
   */
  postPaymentIntentsIntentConfirm: async (options: PostPaymentIntentsIntentConfirmOptions): Promise<PostPaymentIntentsIntentConfirmResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'intent': _intent, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/payment_intents/{intent}/confirm', { 'intent': _intent }, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostPaymentIntentsIntentConfirm', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostPaymentIntentsIntentConfirmSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostPaymentIntentsIntentConfirmErrorResult };
    }
  },

  /**
   * Create a PaymentIntent
   */
  postPaymentIntents: async (options?: PostPaymentIntentsOptions): Promise<PostPaymentIntentsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/payment_intents', {}, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostPaymentIntents', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostPaymentIntentsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostPaymentIntentsErrorResult };
    }
  },

  /**
   * List all PaymentIntents
   */
  getPaymentIntents: async (options?: GetPaymentIntentsOptions): Promise<GetPaymentIntentsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'created': _created, 'customer': _customer, 'customer_account': _customerAccount, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/payment_intents', {}, { 'created': _created, 'customer': _customer, 'customer_account': _customerAccount, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter });
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'GET',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'GetPaymentIntents', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as GetPaymentIntentsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as GetPaymentIntentsErrorResult };
    }
  }
  };

  public readonly terminal = {

  /**
   * Confirm a PaymentIntent on the Reader
   */
  postTerminalReadersReaderConfirmPaymentIntent: async (options: PostTerminalReadersReaderConfirmPaymentIntentOptions): Promise<PostTerminalReadersReaderConfirmPaymentIntentResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'reader': _reader, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/terminal/readers/{reader}/confirm_payment_intent', { 'reader': _reader }, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostTerminalReadersReaderConfirmPaymentIntent', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostTerminalReadersReaderConfirmPaymentIntentSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostTerminalReadersReaderConfirmPaymentIntentErrorResult };
    }
  }
  };

  public readonly paymentMethods = {

  /**
   * List PaymentMethods
   */
  getPaymentMethods: async (options?: GetPaymentMethodsOptions): Promise<GetPaymentMethodsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'allow_redisplay': _allowRedisplay, 'customer': _customer, 'customer_account': _customerAccount, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter, 'type': _type, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/payment_methods', {}, { 'allow_redisplay': _allowRedisplay, 'customer': _customer, 'customer_account': _customerAccount, 'ending_before': _endingBefore, 'expand': _expand, 'limit': _limit, 'starting_after': _startingAfter, 'type': _type });
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'GET',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'GetPaymentMethods', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as GetPaymentMethodsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as GetPaymentMethodsErrorResult };
    }
  }
  };

  public readonly invoicePayments = {

  /**
   * List all payments for an invoice
   */
  getInvoicePayments: async (options?: GetInvoicePaymentsOptions): Promise<GetInvoicePaymentsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'created': _created, 'ending_before': _endingBefore, 'expand': _expand, 'invoice': _invoice, 'limit': _limit, 'payment': _payment, 'starting_after': _startingAfter, 'status': _status, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/invoice_payments', {}, { 'created': _created, 'ending_before': _endingBefore, 'expand': _expand, 'invoice': _invoice, 'limit': _limit, 'payment': _payment, 'starting_after': _startingAfter, 'status': _status });
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'GET',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'GetInvoicePayments', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as GetInvoicePaymentsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as GetInvoicePaymentsErrorResult };
    }
  }
  };

  public readonly radar = {

  /**
   * Create a Payment Evaluation
   */
  postRadarPaymentEvaluations: async (options?: PostRadarPaymentEvaluationsOptions): Promise<PostRadarPaymentEvaluationsResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/radar/payment_evaluations', {}, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostRadarPaymentEvaluations', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostRadarPaymentEvaluationsSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostRadarPaymentEvaluationsErrorResult };
    }
  }
  };

  public readonly testHelpers = {

  /**
   * Test mode: Post an OutboundPayment
   */
  postTestHelpersTreasuryOutboundPaymentsIdPost: async (options: PostTestHelpersTreasuryOutboundPaymentsIdPostOptions): Promise<PostTestHelpersTreasuryOutboundPaymentsIdPostResponse> => {
    await this._rateLimit.acquire();
    const opts = options || {} as any;
    const { 'id': _id, 'headers': _headers } = opts;

    const url = this._buildUrl('/v1/test_helpers/treasury/outbound_payments/{id}/post', { 'id': _id }, {});
    
    const requestHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (_headers) {
      for (const [k, v] of Object.entries(_headers as Record<string, string>)) {
        if (v !== undefined) requestHeaders[k] = String(v);
      }
    }

    
    let reqObj: HttpRequest = {
      method: 'POST',
      url,
      headers: requestHeaders,
      body: undefined,
      timeoutMs: this._timeoutMs
    };
    
    if (this._auths && this._auths.length > 0) {
      for (const auth of this._auths) {
        reqObj = await auth.apply(reqObj);
      }
    }
    
    const response = await this._retry.execute((attempt) => {
      reqObj.retryAttempt = attempt;
      return this._http.request<any>(reqObj);
    });
    
    if (response.status === 401 || response.status === 403 || response.status === 429) {
      normaliseError('Stripe', 'PostTestHelpersTreasuryOutboundPaymentsIdPost', response);
    }

    if (response.ok) {
      return { ok: true, status: response.status, data: response.body as PostTestHelpersTreasuryOutboundPaymentsIdPostSuccessResult, error: null };
    } else {
      return { ok: false, status: response.status, data: null, error: response.body as PostTestHelpersTreasuryOutboundPaymentsIdPostErrorResult };
    }
  }
  };
}
